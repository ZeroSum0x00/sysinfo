use std::fs;
use std::path::{Path, PathBuf};
use std::time::{Duration, Instant};
use std::thread::sleep;

use serde::Serialize;
use crate::utils::helper::is_jetson;


fn read_f64(path: &Path) -> Option<f64> {
    fs::read_to_string(path).ok()?.trim().parse().ok()
}

trait PowerSensor {
    fn init(&mut self) -> bool;
    fn read_watts(&mut self) -> Option<f64>;
}


#[derive(Serialize, Debug)]
pub struct PowerInfo {
    pub power_in: f64,
    pub power_consum: f64,
}

pub fn get_all_power_info() -> PowerInfo {
    let power_in = if is_jetson() {
        get_jetpack_power()
    } else {
        get_server_power()
    };

    PowerInfo {
        power_in,
        power_consum: 0.0,
    }
}


fn get_jetpack_power() -> f64 {
    let mut total = 0.0;

    let Ok(hwmons) = fs::read_dir("/sys/class/hwmon") else {
        return 0.0;
    };

    for hwmon in hwmons.flatten() {
        let base = hwmon.path();
        let name = fs::read_to_string(base.join("name"))
            .unwrap_or_default()
            .to_lowercase();

        if !name.contains("ina") {
            continue;
        }

        let Ok(entries) = fs::read_dir(&base) else {
            continue;
        };

        let mut volts = Vec::new();
        let mut amps = Vec::new();

        for e in entries.flatten() {
            let p = e.path();
            let f = p.file_name().and_then(|v| v.to_str()).unwrap_or("");

            if f.starts_with("in") && f.ends_with("_input") && let Some(v) = read_f64(&p) {
                volts.push(v / 1000.0);
            }

            if f.starts_with("curr") && f.ends_with("_input") && let Some(i) = read_f64(&p) {
                amps.push(i / 1000.0);
            }
        }

        for (v, i) in volts.iter().zip(amps.iter()) {
            total += v * i;
        }
    }

    total.max(0.0)
}


struct Ina3221 {
    v_path: PathBuf,
    i_path: PathBuf,
}

impl Ina3221 {
    fn probe() -> Option<Self> {
        let pattern = "/sys/bus/i2c/drivers/ina*/1-0040/hwmon";

        let mut v = None;
        let mut i = None;

        for entry in glob::glob(pattern).ok()? {
            let dir = entry.ok()?;
            for h in fs::read_dir(dir).ok()? {
                let p = h.ok()?.path();
                let vp = p.join("in1_input");
                let ip = p.join("curr4_input");

                if vp.exists() && ip.exists() {
                    v = Some(vp);
                    i = Some(ip);
                    break;
                }
            }
        }

        Some(Self {
            v_path: v?,
            i_path: i?,
        })
    }
}

impl PowerSensor for Ina3221 {
    fn init(&mut self) -> bool { true }

    fn read_watts(&mut self) -> Option<f64> {
        let v: f64 = fs::read_to_string(&self.v_path).ok()?.trim().parse().ok()?;
        let i: f64 = fs::read_to_string(&self.i_path).ok()?.trim().parse().ok()?;
        Some(v * i / 1_000_000.0)
    }
}


struct Rapl {
    paths: Vec<PathBuf>,
    last_energy: f64,
    last_time: Instant,
}

impl Rapl {
    fn probe() -> Option<Self> {
        let base = Path::new("/sys/class/powercap");
        if !base.exists() {
            return None;
        }

        let mut paths = Vec::new();

        for e in fs::read_dir(base).ok()? {
            let p = e.ok()?.path();
            let name = p.file_name()?.to_string_lossy();

            if name.contains("rapl") {
                let energy = p.join("energy_uj");
                if energy.exists() {
                    paths.push(energy);
                }
            }
        }

        if paths.is_empty() {
            None
        } else {
            Some(Self {
                paths,
                last_energy: 0.0,
                last_time: Instant::now(),
            })
        }
    }

    fn read_energy(&self) -> Option<f64> {
        let mut total = 0.0;
        let mut ok = false;

        for p in &self.paths {
            let v: f64 = fs::read_to_string(p).ok()?.trim().parse().ok()?;
            total += v;
            ok = true;
        }

        if ok { Some(total) } else { None }
    }
}

impl PowerSensor for Rapl {
    fn init(&mut self) -> bool {
        if let Some(e) = self.read_energy() {
            self.last_energy = e;
            self.last_time = Instant::now();
            true
        } else {
            false
        }
    }

    fn read_watts(&mut self) -> Option<f64> {
        let now = Instant::now();
        let e = self.read_energy()?;
        let dt = now.duration_since(self.last_time).as_secs_f64();

        if dt <= 0.0 {
            return None;
        }

        let w = (e - self.last_energy) / 1_000_000.0 / dt;
        self.last_energy = e;
        self.last_time = now;
        Some(w)
    }
}


struct Estimate {
    last_idle: u64,
    last_total: u64,
    tdp: f64,
}

impl Estimate {
    fn new() -> Option<Self> {
        Some(Self {
            last_idle: 0,
            last_total: 0,
            tdp: 65.0,
        })
    }

    fn read_stat() -> Option<(u64, u64)> {
        let line = fs::read_to_string("/proc/stat").ok()?;
        let cpu = line.lines().next()?;
        let vals: Vec<u64> = cpu
            .split_whitespace()
            .skip(1)
            .filter_map(|v| v.parse().ok())
            .collect();

        if vals.len() < 4 {
            return None;
        }
        let idle = vals[3];
        let total: u64 = vals.iter().sum();        
        Some((idle, total))
    }
}

impl PowerSensor for Estimate {
    fn init(&mut self) -> bool {
        if let Some((idle, total)) = Self::read_stat() {
            self.last_idle = idle;
            self.last_total = total;
            true
        } else {
            false
        }
    }

    fn read_watts(&mut self) -> Option<f64> {
        let (idle, total) = Self::read_stat()?;        
        let idle_delta = idle - self.last_idle;
        let total_delta = total - self.last_total;

        self.last_idle = idle;
        self.last_total = total;
        
        if total_delta == 0 {
            return None;
        }

        let usage = 1.0 - (idle_delta as f64 / total_delta as f64);
        Some(usage * self.tdp)
    }
}


fn get_server_power() -> f64 {
    if let Some(mut ina) = Ina3221::probe() {
        ina.init();
        if let Some(w) = ina.read_watts() {
            return w;
        }
    }

    if let Some(mut rapl) = Rapl::probe() && rapl.init() {        
        sleep(Duration::from_secs(2));
        if let Some(w) = rapl.read_watts() {
            return w;
        }
    }

    if let Some(mut est) = Estimate::new() {        
        est.init();
         sleep(Duration::from_secs(2));
        if let Some(w) = est.read_watts() {
            return w;
        }
    }

    0.0
}
