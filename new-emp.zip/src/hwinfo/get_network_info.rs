use serde::Serialize;
use std::process::Command;
use std::time::Instant;
use std::net::TcpStream;
use sysinfo::Networks;



#[derive(Serialize, Clone, Debug)]
pub struct NetworkInfo {
    pub rx_bytes_per_sec: u64,
    pub tx_bytes_per_sec: u64,
    pub latency_ms: u128,
}


#[cfg(target_os = "linux")]
pub fn get_primary_interface() -> Option<String> {
    if let Ok(out) = Command::new("ip").args(["route","get","8.8.8.8"]).output() && out.status.success() {
        let s = String::from_utf8_lossy(&out.stdout);
        let mut tokens = s.split_whitespace();
        while let Some(tok) = tokens.next() {
            if tok == "dev" {
                return tokens.next().map(|t| t.to_string());
            }
        }
    }

    if let Ok(out) = Command::new("ip").args(["route","show","default"]).output() && out.status.success() {
        let s = String::from_utf8_lossy(&out.stdout);
        for part in s.split_whitespace().collect::<Vec<_>>().windows(2) {
            if part[0] == "dev" {
                return Some(part[1].to_string());
            }
        }
    }

    None
}

#[cfg(target_os = "macos")]
pub fn get_primary_interface() -> Option<String> {
    if let Ok(out) = Command::new("route").arg("get").arg("default").output() && out.status.success() {
        let s = String::from_utf8_lossy(&out.stdout);
        for line in s.lines() {
            let line = line.trim();
            if line.starts_with("interface:") {
                return line.split(':').nth(1).map(|t| t.trim().to_string());
            }
        }
    }
    None
}

#[cfg(target_os = "windows")]
pub fn get_primary_interface() -> Option<String> {
    let ps = r#"Get-NetIPConfiguration | Where-Object { $_.IPv4DefaultGateway -ne $null } | Select-Object -ExpandProperty InterfaceAlias"#;
    if let Ok(out) = Command::new("powershell")
        .args(&["-NoProfile", "-Command", ps])
        .output()
    {
        if out.status.success() {
            let s = String::from_utf8_lossy(&out.stdout).trim().to_string();
            if !s.is_empty() {
                return Some(s);
            }
        }
    }
    None
}


pub fn get_network_stats(interface: &str, networks: &mut Networks) -> Vec<NetworkInfo> {
    networks.refresh(true);
    let start = Instant::now();
    let _ = TcpStream::connect("8.8.8.8:53");
    let latency_ms = start.elapsed().as_millis();
        
    let mut network = Vec::new();
    for (interface_name, data) in networks.iter() {
        if interface_name == interface {
            network.push(NetworkInfo {
                rx_bytes_per_sec: data.received(),
                tx_bytes_per_sec: data.transmitted(),
                latency_ms,
            });
        }
    }
    network
}
