use anyhow::{Result, anyhow};
use std::fs;
use std::path::{Path, PathBuf};
use std::time::Instant;

/// Giữ state giữa các lần đọc RAPL
pub struct RaplState {
    paths: Vec<PathBuf>,
    last_energy_uj: f64,
    last_time: Instant,
}

/// Khởi tạo RAPL (gọi 1 lần)
pub fn init_rapl() -> Result<RaplState> {
    let base = Path::new("/sys/class/powercap");
    if !base.exists() {
        return Err(anyhow!("RAPL not available: /sys/class/powercap not found"));
    }

    let mut paths = Vec::new();

    for entry in fs::read_dir(base)? {
        let path = entry?.path();
        let name = path.file_name().unwrap().to_string_lossy();

        if name.contains("rapl") {
            let energy = path.join("energy_uj");
            if energy.exists() {
                paths.push(energy);
            }
        }
    }

    if paths.is_empty() {
        return Err(anyhow!("No RAPL energy files found"));
    }

    let energy = read_total_energy(&paths)?;

    Ok(RaplState {
        paths,
        last_energy_uj: energy,
        last_time: Instant::now(),
    })
}

/// Đọc tổng năng lượng (µJ)
fn read_total_energy(paths: &[PathBuf]) -> Result<f64> {
    let mut total = 0.0;

    for path in paths {
        let value: f64 = fs::read_to_string(path)?
            .trim()
            .parse()
            .map_err(|e| anyhow!("Failed to parse {:?}: {}", path, e))?;
        total += value;
    }

    Ok(total)
}

/// Đọc power tiêu thụ (W)
///
/// Gọi hàm này trong loop.
/// Hàm sẽ tự dùng delta energy / delta time.
pub async fn read_rapl_power(state: &mut RaplState) -> Result<f64> {
    let now = Instant::now();
    let energy = read_total_energy(&state.paths)?;

    let dt = now.duration_since(state.last_time).as_secs_f64();
    if dt <= 0.0 {
        return Err(anyhow!("Invalid time delta"));
    }

    let delta_energy = energy - state.last_energy_uj;

    // RAPL counter có thể reset / wrap
    if delta_energy < 0.0 {
        state.last_energy_uj = energy;
        state.last_time = now;
        return Err(anyhow!("RAPL counter reset detected"));
    }

    // µJ → J → W
    let power_watts = delta_energy / 1_000_000.0 / dt;

    state.last_energy_uj = energy;
    state.last_time = now;

    Ok(power_watts)
}
