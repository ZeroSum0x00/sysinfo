use std::process::Command;
use std::io::{BufReader, BufRead};
use std::process::Stdio;


fn parse_power_rail(line: &str, rail: &str) -> Option<u64> {
    let pos = line.find(rail)?;
    let part = &line[pos..];

    // Ví dụ: "CPU 618mW/501mW"
    let token = part.split_whitespace().nth(1)?;
    let current = token.split('/').next()?;

    let mw = current.replace("mW", "").parse::<u64>().ok()?;
    Some(mw)
}

fn parse_tegrastats_power(line: &str) -> Option<f32> {
    // 1️⃣ Ưu tiên SYS5V (tổng power board)
    if let Some(sys5v_mw) = parse_power_rail(line, "SYS5V") {
        return Some(sys5v_mw as f32 / 1000.0);
    }

    // 2️⃣ Fallback: cộng các rail chính
    let mut total_mw = 0u64;

    for rail in ["CPU", "GPU", "SOC", "CV", "VDDRQ"] {
        if let Some(mw) = parse_power_rail(line, rail) {
            total_mw += mw;
        }
    }

    if total_mw > 0 {
        Some(total_mw as f32 / 1000.0)
    } else {
        None
    }
}

pub fn get_jetson_power() -> Option<f32> {
    let mut child = Command::new("tegrastats")
        .stdout(Stdio::piped())
        .spawn()
        .ok()?;

    let stdout = child.stdout.take()?;
    let mut reader = BufReader::new(stdout);
    let mut line = String::new();

    if reader.read_line(&mut line).is_err() || line.is_empty() {
        let _ = child.kill();
        return None;
    }

    let _ = child.kill();
    let _ = child.wait();

    parse_tegrastats_power(&line)
}