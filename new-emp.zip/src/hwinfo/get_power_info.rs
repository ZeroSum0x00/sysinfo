use std::fs;
use std::path::{Path, PathBuf};
use std::time::{Duration, Instant};
use std::thread::sleep;

use serde::Serialize;
use crate::utils::helper::is_jetson;
use crate::hwinfo::power::rapl_power::{RaplState, read_rapl_power};
use crate::types::MetricsInfo;
use std::process::Command;
use std::io::BufReader;
use std::process::Stdio;
use std::io::BufRead;

#[derive(Serialize, Clone, Debug)]
pub struct PowerInfo {
    pub power_consum: f32,
}


fn calc_power_cpus(metrics: &MetricsInfo) -> f32 {
    metrics
        .cpu
        .get(0)
        .map(|cpu| cpu.power)
        .unwrap_or(0.0)
}

fn calc_power_gpus(metrics: &MetricsInfo) -> f32 {
    metrics
        .gpu
        .iter()
        .map(|gpu| gpu.power_used)
        .fold(0.0_f32, f32::max)
}

fn parse_power_rail(line: &str, rail: &str) -> Option<u64> {
    let pos = line.find(rail)?;
    let part = &line[pos..];

    // Ví dụ: "CPU 618mW/501mW"
    let token = part.split_whitespace().nth(1)?;
    let current = token.split('/').next()?;

    let mw = current.replace("mW", "").parse::<u64>().ok()?;
    Some(mw)
}

fn parse_tegrastats_power(line: &str) -> Option<f32> {
    // 1️⃣ Ưu tiên SYS5V (tổng power board)
    if let Some(sys5v_mw) = parse_power_rail(line, "SYS5V") {
        return Some(sys5v_mw as f32 / 1000.0);
    }

    // 2️⃣ Fallback: cộng các rail chính
    let mut total_mw = 0u64;

    for rail in ["CPU", "GPU", "SOC", "CV", "VDDRQ"] {
        if let Some(mw) = parse_power_rail(line, rail) {
            total_mw += mw;
        }
    }

    if total_mw > 0 {
        Some(total_mw as f32 / 1000.0)
    } else {
        None
    }
}

fn get_jetson_power() -> Option<f32> {
    let mut child = Command::new("tegrastats")
        .stdout(Stdio::piped())
        .spawn()
        .ok()?;

    let stdout = child.stdout.take()?;
    let mut reader = BufReader::new(stdout);
    let mut line = String::new();

    if reader.read_line(&mut line).is_err() || line.is_empty() {
        let _ = child.kill();
        return None;
    }

    let _ = child.kill();

    parse_tegrastats_power(&line)
}

pub fn get_all_power_info(metrics: MetricsInfo) -> anyhow::Result<PowerInfo> {
    if is_jetson() {
        Ok(PowerInfo {
            power_consum: get_jetson_power().unwrap_or(0.0),
        })
    } else {
        let power_cpu = calc_power_cpus(&metrics);
        let power_gpu = calc_power_gpus(&metrics);
    
        Ok(PowerInfo {
            power_consum: 1.15 * power_cpu + power_gpu,
        })
    }
}
