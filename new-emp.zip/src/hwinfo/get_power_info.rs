use std::fs;
use std::path::{Path, PathBuf};
use std::time::{Duration, Instant};
use std::thread::sleep;

use serde::Serialize;
use crate::utils::helper::is_jetson;
use crate::hwinfo::power::rapl_power::{RaplState, read_rapl_power};
use crate::types::MetricsInfo;


#[derive(Serialize, Clone, Debug)]
pub struct PowerInfo {
    pub power_consum: f32,
}


fn calc_power_cpus(metrics: &MetricsInfo) -> f32 {
    metrics
        .cpu
        .get(0)
        .map(|cpu| cpu.power)
        .unwrap_or(0.0)
}

fn calc_power_gpus(metrics: &MetricsInfo) -> f32 {
    metrics
        .gpu
        .iter()
        .map(|gpu| gpu.power_used)
        .fold(0.0_f32, f32::max)
}

    
pub fn get_all_power_info(metrics: MetricsInfo) -> anyhow::Result<PowerInfo> {
    let power_cpu = calc_power_cpus(&metrics);
    let power_gpu = calc_power_gpus(&metrics);

    Ok(PowerInfo {
        power_consum: 1.15 * power_cpu + power_gpu,
    })
}
