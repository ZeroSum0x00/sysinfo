use serde::Serialize;
use crate::utils::helper::is_jetson;
use crate::types::MetricsInfo;
use crate::hwinfo::power::jetpack_power::get_jetson_power;


#[derive(Serialize, Clone, Debug)]
pub struct PowerInfo {
    pub power_in: f32,
    pub power_consum: f32,
}


fn calc_power_cpus(metrics: &MetricsInfo) -> f32 {
    metrics
        .cpu
        .first()
        .map(|cpu| cpu.power)
        .unwrap_or(0.0)
}


fn calc_power_gpus(metrics: &MetricsInfo) -> f32 {
    metrics
        .gpu
        .iter()
        .map(|gpu| gpu.power_used)
        .fold(0.0_f32, f32::max)
}


pub fn get_all_power_info(metrics: MetricsInfo) -> anyhow::Result<PowerInfo> {
    if is_jetson() {
        Ok(PowerInfo {
            power_in: get_jetson_power().unwrap_or(0.0),
            power_consum: 0.0
        })
    } else {
        let power_cpu = calc_power_cpus(&metrics);
        let power_gpu = calc_power_gpus(&metrics);
    
        Ok(PowerInfo {
            power_in: 1.15 * power_cpu + power_gpu,
            power_consum: 0.0
        })
    }
}
