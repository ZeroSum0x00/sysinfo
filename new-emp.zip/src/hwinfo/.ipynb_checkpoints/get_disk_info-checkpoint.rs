use sysinfo::Disks;
use serde::Serialize;
use std::collections::HashSet;

use std::collections::HashMap;
use std::time::Instant;

#[derive(Default)]
pub struct DiskIoState {
    pub last_read: u64,
    pub last_write: u64,
}

pub struct DiskIoCache {
    pub last_ts: Instant,
    pub state: HashMap<String, DiskIoState>,
}

#[derive(Serialize, Clone, Debug)]
pub struct DiskInfo {
    pub id: usize,
    pub name: String,
    pub read_bps: u64,
    pub write_bps: u64,
    pub used_space: u64,
    pub free_space: u64,
    pub total_space: u64,
    pub percent: f32,
}

pub fn get_all_disk_info(
    disks: &mut Disks,
    cache: &mut DiskIoCache,
) -> Vec<DiskInfo> {
    disks.refresh(true);

    let now = Instant::now();
    let dt = now
        .duration_since(cache.last_ts)
        .as_secs_f64()
        .max(1e-6); // tránh chia 0

    cache.last_ts = now;

    let skip_fs = ["overlay", "tmpfs", "shm", "proc", "sysfs", "devtmpfs"];

    let mut disk_metrics = Vec::new();
    let mut seen = HashSet::new();
    let mut disk_id = 0;

    for disk in disks.iter() {
        let name = disk.name().to_string_lossy().to_string();

        if skip_fs.iter().any(|fs| name.contains(fs)) {
            continue;
        }

        let key = (name.clone(), disk.total_space());
        if !seen.insert(key) {
            continue;
        }

        let total_space = disk.total_space();
        let free_space = disk.available_space();
        let used_space = total_space.saturating_sub(free_space);

        let read_now = disk.read_bytes();
        let write_now = disk.written_bytes();

        let entry = cache.state.entry(name.clone()).or_default();

        let mut read_bps =
            ((read_now.saturating_sub(entry.last_read)) as f64 / dt) as u64;
        let mut write_bps =
            ((write_now.saturating_sub(entry.last_write)) as f64 / dt) as u64;
        if entry.last_read == 0 && entry.last_write == 0 {
            entry.last_read = read_now;
            entry.last_write = write_now;
        
            read_bps = 0;
            write_bps = 0;
        }
        
        entry.last_read = read_now;
        entry.last_write = write_now;

        let percent = if total_space > 0 {
            (used_space as f32 / total_space as f32) * 100.0
        } else {
            0.0
        };

        disk_metrics.push(DiskInfo {
            id: disk_id,
            name,
            read_bps,
            write_bps,
            used_space,
            free_space,
            total_space,
            percent,
        });

        disk_id += 1;
    }

    disk_metrics
}

