use sysinfo::{System, Components};
use std::{thread, time::Duration};
use std::collections::HashMap;
use regex::Regex;
use crate::utils::helper::{JetsonModel, get_jetson_model};
use std::process::{Command, Stdio};
use std::io::{BufRead, BufReader};
use std::path::PathBuf;
use std::time::Instant;
use std::path::Path;
use std::fs;
use serde::{Deserialize, Serialize};

pub struct RaplCpuState {
    pub energy_path: PathBuf,
    pub last_energy_uj: f64,
}

pub struct RaplState {
    pub cpus: HashMap<u32, RaplCpuState>,
    pub last_time: Instant,
}


#[derive(Serialize, Clone, Debug)]
pub struct CoreInfo {
    pub id: u32,
    pub name: String,
    pub usage: f32,
    pub frequency: u64,
    pub thermal: f32,
}

#[derive(Serialize, Clone, Debug)]
pub struct CpuInfo {
    pub id: u32,
    pub device: String,
    pub device_name: String,
    pub avg_usage: f32,
    pub avg_thermal: f32,
    pub power: f32,
    // pub core_info: Vec<CoreInfo>,
}


pub fn init_rapl() -> anyhow::Result<RaplState> {
    let base = Path::new("/sys/class/powercap");
    let mut cpus = HashMap::new();

    for entry in fs::read_dir(base)? {
        let path = entry?.path();
        let name = path.file_name().unwrap().to_string_lossy();

        // intel-rapl:0 , intel-rapl:1
        if let Some(id) = name.strip_prefix("intel-rapl:") {
            if let Ok(cpu_id) = id.parse::<u32>() {
                let energy = path.join("energy_uj");
                if energy.exists() {
                    let val: f64 = fs::read_to_string(&energy)?.trim().parse()?;
                    cpus.insert(cpu_id, RaplCpuState {
                        energy_path: energy,
                        last_energy_uj: val,
                    });
                }
            }
        }
    }

    if cpus.is_empty() {
        anyhow::bail!("No intel-rapl CPUs found");
    }

    Ok(RaplState {
        cpus,
        last_time: Instant::now(),
    })
}


pub fn read_rapl_cpu_power(
    state: &mut RaplState
) -> anyhow::Result<HashMap<u32, f32>> {

    let now = Instant::now();
    let dt = now.duration_since(state.last_time).as_secs_f64();
    if dt <= 0.0 {
        anyhow::bail!("Invalid time delta");
    }

    let mut result = HashMap::new();

    for (cpu_id, cpu) in state.cpus.iter_mut() {
        let energy: f64 = fs::read_to_string(&cpu.energy_path)?
            .trim()
            .parse()?;

        let delta = energy - cpu.last_energy_uj;
        if delta < 0.0 {
            continue; // counter reset
        }

        let watts = (delta / 1_000_000.0 / dt) as f32;
        cpu.last_energy_uj = energy;

        result.insert(*cpu_id, watts);
    }

    state.last_time = now;
    Ok(result)
}


pub fn get_all_cpu_info(sys: &mut System, components: &mut Components, rapl: Option<&mut RaplState>) -> Vec<CpuInfo> {
    match get_jetson_model() {
        Some(model) => {
            get_jetpack_cpu_info(model)
        }
        None => {
            get_server_cpu_info(sys, components, rapl)
        }
    }
}


fn get_jetpack_cpu_info(model: JetsonModel) -> Vec<CpuInfo> {
    let mut child = match Command::new("tegrastats")
        .stdout(Stdio::piped())
        .spawn()
    {
        Ok(c) => c,
        Err(_) => return vec![],
    };

    let stdout = match child.stdout.take() {
        Some(s) => s,
        None => return vec![],
    };

    let mut reader = BufReader::new(stdout);
    let mut line = String::new();

    if reader.read_line(&mut line).is_err() || line.is_empty() {
        let _ = child.kill();
        return vec![];
    }

    let _ = child.kill();

    let mut core_info = Vec::new();
    let mut total_usage = 0.0;
    let mut cpu_temp = 0.0;

    if let Some(start) = line.find("CPU [") && let Some(end) = line[start..].find(']') {
        let cores = &line[start + 5..start + end];

        for (i, core) in cores.split(',').enumerate() {
            let mut usage = 0.0;
            let mut freq = 0;

            if let Some((u, f)) = core.split_once("%@") {
                usage = u.trim().parse().unwrap_or(0.0);
                freq = f.trim().parse().unwrap_or(0);
            }

            total_usage += usage;

            core_info.push(CoreInfo {
                id: i as u32,
                name: format!("core_{}", i),
                usage,
                frequency: freq,
                thermal: 0.0,
            });
        }
    }

    if let Some(pos) = line.find("CPU@") {
        let part = &line[pos + 4..];
        if let Some(t) = part.split('C').next() {
            cpu_temp = t.parse().unwrap_or(0.0);
        }
    }

    for core in core_info.iter_mut() {
        core.thermal = cpu_temp;
    }

    let core_count = core_info.len() as f32;
    let avg_usage = if core_count > 0.0 {
        total_usage / core_count
    } else {
        0.0
    };

    vec![CpuInfo {
        id: 0,
        device: "cpu_0".to_string(),
        device_name: model.to_cpu_arch().to_string(),
        avg_usage,
        avg_thermal: cpu_temp,
        power: 0.0,
        // core_info,
    }]
}


fn get_server_cpu_info(sys: &mut System, components: &mut Components, rapl: Option<&mut RaplState>) -> Vec<CpuInfo> {
    let power_map = if let Some(rapl) = rapl {
        read_rapl_cpu_power(rapl).unwrap_or_default()
    } else {
        Default::default()
    };
    
    sys.refresh_cpu_all();
    thread::sleep(Duration::from_millis(250));
    sys.refresh_cpu_all();
    components.refresh(true);

    let mut total_usage = 0.0;
    let mut cpu_name = "";

    let mut usage_metrics = Vec::new();
    for (i, cpu) in sys.cpus().iter().enumerate() {
        let name = format!("core_{}", i);
        let usage = cpu.cpu_usage();
        let freq = cpu.frequency();

        total_usage += usage;
        cpu_name = cpu.brand();

        usage_metrics.push((i as u32, name, usage, freq));
    }

    let re_core = Regex::new(r"core\s+(\d+)").unwrap();
    let re_pkg = Regex::new(r"package id\s+(\d+)").unwrap();
    
    let mut core_temp = HashMap::new();
    let mut cpu_pkg_temp = HashMap::new();

    for component in components.iter() {
        let Some(temp_val) = component.temperature() else {
            continue;
        };
    
        let label = component.label().to_lowercase();
    
        if let Some(cap) = re_core.captures(&label)
            && let Ok(core_id) = cap[1].parse::<u32>()
        {
            core_temp.insert(core_id, temp_val);
        }
    
        if let Some(cap) = re_pkg.captures(&label)
            && let Ok(pkg_id) = cap[1].parse::<u32>()
        {
            cpu_pkg_temp.insert(pkg_id, temp_val);
        }
    }

    let mut core_info = Vec::new();
    for (id, name, usage, freq) in usage_metrics.into_iter() {
        let thermal = core_temp.get(&id).cloned().unwrap_or(0.0);
    
        core_info.push(CoreInfo {
            id,
            name,
            usage,
            frequency: freq,
            thermal,
        });
    }

    let core_count = core_info.len() as f32;
    let avg_usage = if core_count > 0.0 {
        total_usage / core_count
    } else {
        0.0
    };

    let avg_thermal = if !cpu_pkg_temp.is_empty() {
        cpu_pkg_temp.values().sum::<f32>() / cpu_pkg_temp.len() as f32
    } else {
        0.0
    };

    let total_cpu_power: f32 = power_map.values().copied().sum();


    vec![CpuInfo {
        id: 0,
        device: "cpu_0".to_string(),
        device_name: cpu_name.to_string(),
        avg_usage,
        avg_thermal,
        power: total_cpu_power,
        // core_info,
    }]
}
