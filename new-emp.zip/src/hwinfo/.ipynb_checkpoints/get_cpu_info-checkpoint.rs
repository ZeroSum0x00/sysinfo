use sysinfo::{System, Components};
use serde::Serialize;
use crate::hwinfo::cpu::{
    rapl_cpu_power::RaplState,
    estimate_cpu_power::CpuEstimateState,
    jetpack_cpu::get_jetpack_cpu_info,
    popular_cpu::get_popular_cpu_info,
};
use crate::utils::helper::get_jetson_model;


pub enum CpuPowerBackendMut<'a> {
    Rapl(&'a mut RaplState),
    Estimate(&'a mut CpuEstimateState),
}


#[derive(Serialize, Clone, Debug)]
pub struct CoreInfo {
    pub id: u32,
    pub name: String,
    pub usage: f32,
    pub frequency: u64,
    pub thermal: f32,
}

#[derive(Serialize, Clone, Debug)]
pub struct CpuInfo {
    pub id: u32,
    pub device: String,
    pub device_name: String,
    pub avg_usage: f32,
    pub avg_thermal: f32,
    pub power: f32,
    // pub core_info: Vec<CoreInfo>,
}




pub fn get_all_cpu_info(
    sys: &mut System,
    components: &mut Components,
    power_backend: Option<CpuPowerBackendMut>,
) -> Vec<CpuInfo> {
    match get_jetson_model() {
        Some(model) => {
            get_jetpack_cpu_info(model)
        }
        None => {
            get_popular_cpu_info(sys, components, power_backend)
        }
    }
}

