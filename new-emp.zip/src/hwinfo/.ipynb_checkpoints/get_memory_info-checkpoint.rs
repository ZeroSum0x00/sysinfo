use serde::Serialize;
use sysinfo::System;
use std::process::{Command, Stdio};
use std::io::{BufRead, BufReader};
use tracing::error;
use crate::utils::helper::is_jetson;


#[derive(Serialize, Clone, Debug)]
pub struct MemoryInfo {
    pub percent: f32,
    pub used_mb: u64,
    pub available_mb: u64,
}


pub fn get_all_memory_info(sys: &mut System) -> MemoryInfo {
    if is_jetson() {
        if let Some(mem) = get_jetson_memory() {
            return mem;
        } else {
            error!("Failed to read Jetson memory via tegrastats, fallback to sysinfo");
        }
    }

    sys.refresh_memory();
    let total_mb = sys.total_memory() / 1_000;
    let available_mb = sys.available_memory() / 1_000;
    let used_mb = total_mb.saturating_sub(available_mb);

    let percent = if total_mb > 0 {
        (used_mb as f32 / total_mb as f32) * 100.0
    } else {
        0.0
    };

    MemoryInfo {
        percent,
        used_mb,
        available_mb,
    }
}

fn get_jetson_memory() -> Option<MemoryInfo> {
    let mut child = Command::new("tegrastats")
        .stdout(Stdio::piped())
        .spawn()
        .ok()?;

    let stdout = child.stdout.take()?;
    let mut reader = BufReader::new(stdout);
    let mut line = String::new();

    if reader.read_line(&mut line).is_err() || line.is_empty() {
        let _ = child.kill();
        return None;
    }

    let _ = child.kill();

    let (used_mb, total_mb) = parse_tegrastats_ram(&line)?;

    let available_mb = total_mb.saturating_sub(used_mb);
    let percent = if total_mb > 0 {
        (used_mb as f32 / total_mb as f32) * 100.0
    } else {
        0.0
    };

    Some(MemoryInfo {
        percent,
        used_mb,
        available_mb,
    })
}

fn parse_tegrastats_ram(line: &str) -> Option<(u64, u64)> {
    let pos = line.find("RAM")?;
    let part = &line[pos..];

    let ram_token = part.split_whitespace().nth(1)?;
    let ram_token = ram_token.replace("MB", "");

    let (used, total) = ram_token.split_once('/')?;

    let used_mb = used.parse::<u64>().ok()?;
    let total_mb = total.parse::<u64>().ok()?;

    Some((used_mb, total_mb))
}
