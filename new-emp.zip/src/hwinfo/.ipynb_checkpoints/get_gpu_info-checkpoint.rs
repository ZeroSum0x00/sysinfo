use crate::hwinfo::gpu::gpu_model::GpuInfo;
use crate::hwinfo::gpu::jetpack_gpu_collector::get_tegrastats_gpu_infomation;
use crate::hwinfo::gpu::nvidia_gpu_collector::get_nvidia_gpu_infomation;
use crate::hwinfo::gpu::amd_gpu_collector::get_amd_gpu_infomation;
use crate::utils::helper::{cmd_exists, get_jetson_model};



pub fn get_all_gpu_info() -> Vec<GpuInfo> {
    match get_jetson_model() {
        Some(model) => {
            get_tegrastats_gpu_infomation(model)
        }
        None => {
            if cmd_exists("nvidia-smi") {
                get_nvidia_gpu_infomation()
            } else if cmd_exists("rocm-smi") {
                get_amd_gpu_infomation()
            } else {
                vec![GpuInfo::empty()]
            }
        }
    }
}

