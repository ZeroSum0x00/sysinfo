use std::path::PathBuf;
use std::collections::HashMap;
use std::time::Instant;
use std::path::Path;
use std::fs;


pub struct RaplCpuState {
    pub energy_path: PathBuf,
    pub last_energy_uj: f64,
}

pub struct RaplState {
    pub cpus: HashMap<u32, RaplCpuState>,
    pub last_time: Instant,
}


pub fn init_rapl() -> Option<RaplState> {
    let base = Path::new("/sys/class/powercap");
    let mut cpus = HashMap::new();

    let entries = fs::read_dir(base).ok()?;

    for entry in entries.flatten() {
        let path = entry.path();
        let name = match path.file_name() {
            Some(n) => n.to_string_lossy(),
            None => continue,
        };

        // chỉ match intel-rapl:N (package), không match intel-rapl gốc
        let cpu_id = match name.strip_prefix("intel-rapl:") {
            Some(id) => id.parse::<u32>().ok(),
            None => None,
        };

        let cpu_id = match cpu_id {
            Some(id) => id,
            None => continue,
        };

        let energy = path.join("energy_uj");
        if !energy.is_file() {
            continue;
        }

        let val = fs::read_to_string(&energy)
            .ok()?
            .trim()
            .parse::<f64>()
            .ok()?;

        cpus.insert(
            cpu_id,
            RaplCpuState {
                energy_path: energy,
                last_energy_uj: val,
            },
        );
    }

    // 👉 CHECK QUAN TRỌNG
    if cpus.is_empty() {
        return None;
    }

    Some(RaplState {
        cpus,
        last_time: Instant::now(),
    })
}


pub fn read_rapl_cpu_power(
    state: &mut RaplState
) -> anyhow::Result<HashMap<u32, f32>> {

    let now = Instant::now();
    let dt = now.duration_since(state.last_time).as_secs_f64();
    if dt <= 0.0 {
        anyhow::bail!("Invalid time delta");
    }

    let mut result = HashMap::new();

    for (cpu_id, cpu) in state.cpus.iter_mut() {
        let energy: f64 = fs::read_to_string(&cpu.energy_path)?
            .trim()
            .parse()?;

        let delta = energy - cpu.last_energy_uj;
        if delta < 0.0 {
            continue; // counter reset
        }

        let watts = (delta / 1_000_000.0 / dt) as f32;
        cpu.last_energy_uj = energy;

        result.insert(*cpu_id, watts);
    }

    state.last_time = now;
    Ok(result)
}
