use crate::utils::helper::{JetsonModel};
use crate::hwinfo::get_cpu_info::{CpuInfo, CoreInfo};
use std::process::{Command, Stdio};
use std::io::{BufRead, BufReader};


pub fn get_jetpack_cpu_info(model: JetsonModel) -> Vec<CpuInfo> {
    let mut child = match Command::new("tegrastats")
        .stdout(Stdio::piped())
        .spawn()
    {
        Ok(c) => c,
        Err(_) => return vec![],
    };

    let stdout = match child.stdout.take() {
        Some(s) => s,
        None => return vec![],
    };

    let mut reader = BufReader::new(stdout);
    let mut line = String::new();

    if reader.read_line(&mut line).is_err() || line.is_empty() {
        let _ = child.kill();
        return vec![];
    }

    let _ = child.kill();
    let _ = child.wait();

    let mut core_info = Vec::new();
    let mut total_usage = 0.0;
    let mut cpu_temp = 0.0;

    if let Some(start) = line.find("CPU [") && let Some(end) = line[start..].find(']') {
        let cores = &line[start + 5..start + end];

        for (i, core) in cores.split(',').enumerate() {
            let mut usage = 0.0;
            let mut freq = 0;

            if let Some((u, f)) = core.split_once("%@") {
                usage = u.trim().parse().unwrap_or(0.0);
                freq = f.trim().parse().unwrap_or(0);
            }

            total_usage += usage;

            core_info.push(CoreInfo {
                id: i as u32,
                name: format!("core_{}", i),
                usage,
                frequency: freq,
                thermal: 0.0,
            });
        }
    }

    if let Some(pos) = line.find("CPU@") {
        let part = &line[pos + 4..];
        if let Some(t) = part.split('C').next() {
            cpu_temp = t.parse().unwrap_or(0.0);
        }
    }

    for core in core_info.iter_mut() {
        core.thermal = cpu_temp;
    }

    let core_count = core_info.len() as f32;
    let avg_usage = if core_count > 0.0 {
        total_usage / core_count
    } else {
        0.0
    };

    vec![CpuInfo {
        id: 0,
        device: "cpu_0".to_string(),
        device_name: model.to_cpu_arch().to_string(),
        avg_usage,
        avg_thermal: cpu_temp,
        power: 0.0,
        // core_info,
    }]
}
