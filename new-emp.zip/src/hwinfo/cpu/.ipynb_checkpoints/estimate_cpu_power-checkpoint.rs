pub struct CpuEstimateState {
    pub idle_power_w: f32,
    pub max_power_w: f32,
}





pub fn init_cpu_estimate(
    idle_power_w: f32,
    max_power_w: f32,
) -> anyhow::Result<CpuEstimateState> {
    Ok(CpuEstimateState {
        idle_power_w,
        max_power_w,
    })
}


pub fn read_estimate_cpu_power(
    state: &mut CpuEstimateState,
    usage: &f32,
    cpu_count: &f32,
) -> anyhow::Result<f32> {
    let power = (state.idle_power_w + usage / 100_f32 * (state.max_power_w - state.idle_power_w)) * cpu_count;
    Ok(power)
}

