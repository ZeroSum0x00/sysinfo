use serde::Serialize;
use sysinfo::System;
use std::process::{Command, Stdio};
use std::io::{BufRead, BufReader};
use tracing::error;

use crate::utils::helper::is_jetson;

#[derive(Serialize, Clone, Debug)]
pub enum RamType {
    DDR3,
    DDR4,
    DDR5,
    Unknown,
}

#[derive(Debug)]
pub struct RamBasicInfo {
    pub ram_type: RamType,
    pub dimm_count: u32,
}

pub fn detect_ram_basic_info() -> RamBasicInfo {
    let output = Command::new("dmidecode")
        .args(["-t", "memory"])
        .output();

    let Ok(output) = output else {
        return RamBasicInfo {
            ram_type: RamType::Unknown,
            dimm_count: 0,
        };
    };

    let text = String::from_utf8_lossy(&output.stdout);
    let text_lower = text.to_lowercase();

    // ---- detect RAM type ----
    let ram_type = if text_lower.contains("ddr5") {
        RamType::DDR5
    } else if text_lower.contains("ddr4") {
        RamType::DDR4
    } else if text_lower.contains("ddr3") {
        RamType::DDR3
    } else {
        RamType::Unknown
    };

    // ---- count DIMM ----
    let mut dimm_count = 0;

    for line in text.lines() {
        let line = line.trim();
        if line.starts_with("Size:")
            && !line.contains("No Module Installed")
        {
            dimm_count += 1;
        }
    }

    RamBasicInfo {
        ram_type,
        dimm_count,
    }
}

#[derive(Serialize, Clone, Debug)]
pub struct MemoryInfo {
    #[serde(rename = "type")]
    pub _type: RamType,
    pub dimm_count: u32,
    pub percent: f32,
    pub used_mb: u64,
    pub available_mb: u64,
}

pub fn get_all_memory_info(sys: &mut System) -> MemoryInfo {
    if is_jetson() {
        if let Some(mem) = get_jetson_memory() {
            return mem;
        } else {
            error!("Failed to read Jetson memory via tegrastats, fallback to sysinfo");
        }
    }

    sys.refresh_memory();
    let ram_info = detect_ram_basic_info();
    let total_mb = sys.total_memory() / 1_000;
    let available_mb = sys.available_memory() / 1_000;
    let used_mb = total_mb.saturating_sub(available_mb);

    let percent = if total_mb > 0 {
        (used_mb as f32 / total_mb as f32) * 100.0
    } else {
        0.0
    };

    MemoryInfo {
        _type: ram_info.ram_type,
        dimm_count: ram_info.dimm_count,
        percent,
        used_mb,
        available_mb,
    }
}

fn get_jetson_memory() -> Option<MemoryInfo> {
    let mut child = Command::new("tegrastats")
        .stdout(Stdio::piped())
        .spawn()
        .ok()?;

    let stdout = child.stdout.take()?;
    let mut reader = BufReader::new(stdout);
    let mut line = String::new();

    if reader.read_line(&mut line).is_err() || line.is_empty() {
        let _ = child.kill();
        return None;
    }

    let _ = child.kill();

    let (used_mb, total_mb) = parse_tegrastats_ram(&line)?;

    let available_mb = total_mb.saturating_sub(used_mb);
    let percent = if total_mb > 0 {
        (used_mb as f32 / total_mb as f32) * 100.0
    } else {
        0.0
    };

    Some(MemoryInfo {
        _type: RamType::Unknown,
        dimm_count: 1,
        percent,
        used_mb,
        available_mb,
    })
}

fn parse_tegrastats_ram(line: &str) -> Option<(u64, u64)> {
    let pos = line.find("RAM")?;
    let part = &line[pos..];

    let ram_token = part.split_whitespace().nth(1)?;
    let ram_token = ram_token.replace("MB", "");

    let (used, total) = ram_token.split_once('/')?;

    let used_mb = used.parse::<u64>().ok()?;
    let total_mb = total.parse::<u64>().ok()?;

    Some((used_mb, total_mb))
}
