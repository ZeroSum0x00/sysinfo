use std::str;
use std::process::Command;
use crate::hwinfo::gpu::gpu_model::GpuInfo;

pub fn get_nvidia_gpu_infomation() -> Vec<GpuInfo> {
    let mut all_gpus = Vec::new();

    let output = Command::new("nvidia-smi")
        .args([
            "--query-gpu=index,name,temperature.gpu,utilization.gpu,memory.used,memory.total,power.draw,power.max_limit",
            "--format=csv,noheader,nounits",
        ])
        .output()
        .expect("Can't run nvidia-smi. Did you install the driver?");

    let stdout = str::from_utf8(&output.stdout).unwrap_or("");
    
    if stdout.contains("NVIDIA-SMI has failed because it couldn't communicate with the NVIDIA driver") {
        return vec![GpuInfo::empty()];
    }
    
    for line in stdout.lines() {
        let parts: Vec<&str> = line.split(',').map(|s| s.trim()).collect();
        if parts.len() == 8 {
            let index: u32 = parts[0].parse().unwrap_or(0);
            let gpu_name = parts[1];
            let thermal: f32 = parts[2].parse().unwrap_or(0.0);
            let util: f32 = parts[3].parse().unwrap_or(0.0);
            let vram_used: f32 = parts[4].parse().unwrap_or(0.0);
            let vram_total: f32 = parts[5].parse().unwrap_or(0.0);
            let vram_percent: f32 = vram_used / vram_total * 100.0;
            let power: f32 = parts[6].parse().unwrap_or(0.0);
            let power_limit: f32 = parts[7].parse().unwrap_or(0.0);

            all_gpus.push(GpuInfo {
                id: index,
                device_name: gpu_name.to_string(),
                util,
                vram_used,
                vram_total,
                vram_percent,
                thermal,
                power_used: power,
                power_limit,
            });
        }
    }
    
    if all_gpus.is_empty() {
        return vec![GpuInfo::empty()];
    }
    
    all_gpus
}
