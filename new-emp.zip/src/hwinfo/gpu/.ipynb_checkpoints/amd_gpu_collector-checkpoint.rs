use std::str;
use std::process::Command;
use crate::hwinfo::gpu::gpu_model::GpuInfo;



pub fn get_amd_gpu_infomation() -> Vec<GpuInfo> {
    let mut all_gpus = Vec::new();
    let output = Command::new("rocm-smi")
        .args([
            "--showproductname", // Tên GPU
            "--showtemp",        // Nhiệt độ
            "--showuse",         // % sử dụng
            "--showmemuse",      // Dung lượng VRAM
            "--showpower",       // Công suất tiêu thụ
            "--json",            // Xuất JSON để parse dễ
        ])
        .output()
        .expect("Can't run rocm-smi. Do you installed driver yet?");

    let _stdout = str::from_utf8(&output.stdout).unwrap_or("");

    all_gpus.push(GpuInfo {
        id: 0,
        device_name: "test".to_string(),
        util: 50.,
        vram_used: 50.,
        vram_total: 100.,
        vram_percent: 0.,
        thermal: 100.,
        power_used: 23.,
        power_limit: 255.,
    });

    all_gpus
}
