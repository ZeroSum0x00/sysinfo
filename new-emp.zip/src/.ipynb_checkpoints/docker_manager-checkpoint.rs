use std::sync::Arc;
use tracing::error;
use anyhow::{anyhow, Result};
use serde_json::Value;
use serde_json::json;
use std::default::Default;
use bollard::Docker;
use bollard::auth::DockerCredentials;
use bollard::models::{HostConfig, PortBinding};
use bollard::container::{Config, ListContainersOptions, CreateContainerOptions, RemoveContainerOptions, LogsOptions, LogOutput};
use bollard::image::{CreateImageOptions, ListImagesOptions};
use futures_util::stream::StreamExt;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use futures_util::stream::TryStreamExt;


pub fn docker_connect(url: &str, timeout: u64) -> Docker {
    if url.starts_with("unix://") {
        let path = url.trim_start_matches("unix://");
        Docker::connect_with_unix(path, timeout, bollard::API_DEFAULT_VERSION)
            .expect("Failed to connect using unix socket")
    } else if url.starts_with("tcp://") {
        Docker::connect_with_http(url, timeout, bollard::API_DEFAULT_VERSION)
            .expect("Failed to connect using tcp")
    } else {
        panic!("Unknown docker endpoint: {}", url);
    }
}

#[derive(Debug, Clone, Serialize)]
pub enum DockerCommand {
    Start { action_type: String, container_id: String },
    Stop { action_type: String, container_id: String },
    Restart { action_type: String, container_id: String },
    Delete { action_type: String, container_id: String, force: bool },
    RunImageProgress {
        id: String,
        image: String,
        name: Option<String>,
        envs: Option<HashMap<String, String>>,
        ports: Option<Value>,
        volumes: Option<Value>,
    },
    GetLogs { stream_id: String, container_id: String, flag: bool },
    GetContainers { stream_id: String, container_ids: toml::Value },
    Exception { error: String },
}

pub struct MQTTConfig {
    pub topic: String,
    pub id: String,
    pub mqtt_client: Arc<crate::mqtt_client::MqttProgressPublisher>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OperatorPublisherConfig {
    pub container_id: String,
    pub state: String,
    pub status: String,
    pub message: String,
    #[serde(rename = "type")]
    pub _type: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ApplicationPublisherConfig {
    pub id: String,
    pub status: String,
    pub step: String,
    pub message: String,
    pub payload: Value,
}


#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DockerResponse {
    pub success: bool,
    pub message: String,
    pub data: Option<serde_json::Value>,
}

pub struct DockerManager {
    docker: Docker,
    credential: DockerCredentials
}


impl DockerManager {
    pub fn new_with_endpoint(endpoint: &str, docker_credential: DockerCredentials) -> Result<Self> {
        let docker = docker_connect(endpoint, 120);
        let credential = docker_credential.clone();
        Ok(Self { docker, credential })
    }

    pub fn new_default(docker_credential: DockerCredentials) -> Result<Self> {
        let docker = Docker::connect_with_socket_defaults()?;
        let credential = docker_credential.clone();
        Ok(Self { docker, credential })
    }

    pub async fn get_containers(&self) -> Result<Vec<bollard::models::ContainerSummary>> {
        let options = ListContainersOptions::<String> {
            all: true,
            ..Default::default()
        };

        let containers = self.docker.list_containers(Some(options)).await?;
        Ok(containers)
    }

    pub async fn inspect_container_status(
        &self,
        container_id: &str,
    ) -> Result<String, Box<dyn std::error::Error + Send + Sync>> {
    
        let info = self.docker.inspect_container(container_id, None).await?;
    
        let status = info
            .state
            .as_ref()
            .and_then(|s| s.status.as_ref())
            .map(|s| match s {
                bollard::models::ContainerStateStatusEnum::CREATED     => "created",
                bollard::models::ContainerStateStatusEnum::RUNNING     => "running",
                bollard::models::ContainerStateStatusEnum::PAUSED      => "paused",
                bollard::models::ContainerStateStatusEnum::RESTARTING  => "restarting",
                bollard::models::ContainerStateStatusEnum::REMOVING    => "removing",
                bollard::models::ContainerStateStatusEnum::EXITED      => "exited",
                bollard::models::ContainerStateStatusEnum::DEAD        => "dead",
                _                                                      => "unknown",
            })
            .unwrap_or("unknown");

        Ok(status.to_string())
    }
    
    pub async fn list_images(&self) -> Result<Vec<bollard::models::ImageSummary>> {
        let options = ListImagesOptions::<String> {
            all: true,
            ..Default::default()
        };

        let images = self.docker.list_images(Some(options)).await?;
        Ok(images)
    }
    
    pub async fn list_images_advance(&self) -> Result<Vec<Value>, Box<dyn std::error::Error + Send + Sync>> {
        let options = ListImagesOptions::<String> {
            all: true,
            ..Default::default()
        };

        let images = self.docker.list_images(Some(options)).await?;
        Ok(images
            .into_iter()
            .map(|img| {
                serde_json::json!({
                    "id": img.id,
                    "tags": img.repo_tags,
                    "digests": img.repo_digests,
                    "created": img.created,
                    "size": img.size,
                    "virtual_size": img.virtual_size,
                    "shared_size": img.shared_size,
                    "labels": img.labels,
                    "containers": img.containers,
                    "parent_id": img.parent_id,
                })
            })
            .collect())
    }
    
    pub async fn get_container_stats(
        &self,
        container_ids: toml::Value,
    ) -> anyhow::Result<serde_json::Value> {
    
        let mut my_list_containers = Vec::new();
    
        let container_ids = container_ids
            .as_array()
            .ok_or_else(|| anyhow::anyhow!("container_ids must be an array"))?;
    
        match self.list_all_containers2().await {
            Ok(containers) => {
                for container in containers {
                    let id = container
                        .get("id")
                        .and_then(|v| v.as_str())
                        .unwrap_or("");

                    let exists = container_ids.iter().any(|v| {
                        v.as_str()
                            .map(|short_id| id.starts_with(short_id))
                            .unwrap_or(false)
                    });

    
                    if !exists {
                        continue;
                    }
    
                    let filtered = serde_json::json!({
                        "id": id,
                        "state": container.get("state"),
                        "status": container.get("status"),
                    });
    
                    my_list_containers.push(filtered);
                }
            }
            Err(e) => {
                error!("Running failed id {:?}", e);
            }
        }
        Ok(serde_json::json!(my_list_containers))
    }


    pub async fn start_container(&self, container_id: &str) -> Result<()> {
        self.docker.start_container::<String>(container_id, None).await?;
        Ok(())
    }

    pub async fn stop_container(&self, container_id: &str) -> Result<()> {
        self.docker.stop_container(container_id, None).await?;
        Ok(())
    }

    pub async fn restart_container(&self, container_id: &str) -> Result<()> {
        self.docker.restart_container(container_id, None).await?;
        Ok(())
    }

    pub async fn delete_container(&self, container_id: &str, force: bool) -> Result<()> {
        let options = RemoveContainerOptions {
            force,
            ..Default::default()
        };
        self.docker.remove_container(container_id, Some(options)).await?;
        Ok(())
    }

    pub async fn pull_image(&self, image: &str) -> Result<()> {
        let options = CreateImageOptions {
            from_image: image,
            ..Default::default()
        };

        let mut stream = self.docker.create_image(Some(options), None, None);
        while let Some(result) = stream.next().await {
            match result {
                Ok(_) => continue,
                Err(e) => return Err(e.into()),
            }
        }
        Ok(())
    }

    async fn pull_image_for_run(
        docker_manager: Docker,
        credential: DockerCredentials,
        topic: &str,
        id: &str,
        image: String,
        mqtt_client: Arc<crate::mqtt_client::MqttProgressPublisher>
    ) -> Result<(), anyhow::Error> {
        let options = CreateImageOptions {
            from_image: image.clone(),
            ..Default::default()
        };

        let mut stream = docker_manager.create_image(Some(options), None, Some(credential));
        let mut last_update = std::time::Instant::now();

        while let Some(result) = stream.next().await {
            match result {
                Ok(progress_info) => {
                    let now = std::time::Instant::now();
                    let should_publish = now.duration_since(last_update).as_secs() >= 2 ||
                        progress_info.status.as_deref() == Some("Pull complete") ||
                        progress_info.status.as_deref() == Some("Downloaded newer image") ||
                        progress_info.error.is_some();

                    if should_publish {
                        let payload = serde_json::json!({
                            "process_id": progress_info.id.as_deref().unwrap_or(""),
                            "status": progress_info.status.as_deref().unwrap_or(""),
                            "progress": progress_info.progress.as_deref().unwrap_or(""),
                            "error": progress_info.error.as_deref().unwrap_or(""),
                            "progress_detail": progress_info.progress_detail,
                            "timestamp": chrono::Utc::now().to_rfc3339()
                        });
                        
                        let data_publisher = ApplicationPublisherConfig {
                            id: id.to_string(),
                            status: "pulling".to_string(),
                            step: "pull".to_string(),
                            message: "".to_string(),
                            payload,
                        };
                        
                        let payload = serde_json::to_string(&data_publisher)?;

                        if let Err(e) = mqtt_client.publish_to_topic(topic, payload).await {
                            eprintln!("Failed to publish run progress: {}", e);
                        }

                        last_update = now;
                    }
                }
                Err(e) => {
                    eprintln!("Error during image pull for run_image: {}", e);
                    let data_publisher = ApplicationPublisherConfig {
                        id: id.to_string(),
                        status: "error".to_string(),
                        step: "pull".to_string(),
                        message: e.to_string(),
                        payload: json!({}),
                    };
                    
                    let payload = serde_json::to_string(&data_publisher)?;
                    let _ = mqtt_client.publish_to_topic(topic, payload).await;
                    return Err(e.into());
                }
            }
        }

        Ok(())
    }

    async fn create_container_for_run(
        docker_manager: Docker,
        image: String,
        name: Option<String>,
        envs: Option<HashMap<String, String>>,
        ports: Option<Value>,
        volumes: Option<Value>,
    ) -> Result<String, anyhow::Error> {
        let create_options = CreateContainerOptions::<String> {
            name: name.clone().unwrap_or_default(),
            ..Default::default()
        };

        let env_vars: Option<Vec<String>> = envs.map(|map| {
            map.into_iter()
                .map(|(k, v)| format!("{}={}", k, v))
                .collect()
        });
    
        let mut exposed_ports: HashMap<String, HashMap<(), ()>> = HashMap::new();
        let mut port_bindings: HashMap<String, Option<Vec<PortBinding>>> = HashMap::new();
            
        if let Some(port_list) = ports && let Some(arr) = port_list.as_array() {
            for port_value in arr {
                if let Some(port_str) = port_value.as_str() {
                    let parts: Vec<&str> = port_str.split(':').collect();
                    let (host_port, container_port) = match parts.as_slice() {
                        [host, container] => (*host, *container),
                        [single] => (*single, *single),
                        _ => continue,
                    };
    
                    let container_key = format!("{}/tcp", container_port);
    
                    exposed_ports.insert(container_key.clone(), HashMap::new());
                    port_bindings.insert(
                        container_key.clone(),
                        Some(vec![PortBinding {
                            host_ip: Some("0.0.0.0".to_string()),
                            host_port: Some(host_port.to_string()),
                        }]),
                    );
                }
            }
        }
                let mut binds: Vec<String> = vec![];
            
        if let Some(vol_list) = volumes && let Some(arr) = vol_list.as_array() {
            for v in arr {
                if let Some(v_str) = v.as_str() {
                    let trimmed = v_str.trim();
                    if trimmed.is_empty() {
                        continue;
                    }
    
                    if !trimmed.contains(':') {
                        return Err(anyhow!(
                            "Invalid volume '{}': must contain ':'",
                            trimmed
                        ));
                    }
    
                    let parts: Vec<&str> = trimmed.split(':').collect();
                    if parts.len() < 2 || parts[0].is_empty() || parts[1].is_empty() {
                        return Err(anyhow!(
                            "Invalid volume '{}': missing host or container path",
                            trimmed
                        ));
                    }
    
                    binds.push(trimmed.to_string());
                }
            }
        }
                
        let config: Config<String> = Config {
            image: Some(image.clone()),
            env: env_vars,
            exposed_ports: if exposed_ports.is_empty() {
                None
            } else {
                Some(exposed_ports)
            },
            host_config: Some(HostConfig {
                port_bindings: if port_bindings.is_empty() {
                    None
                } else {
                    Some(port_bindings)
                },
                binds: if binds.is_empty() {
                    None
                } else {
                    Some(binds)
                },
                ..Default::default()
            }),
            ..Default::default()
        };

        let container_result = docker_manager.create_container(Some(create_options), config).await;

        match container_result {
            Ok(result) => {
                Ok(result.id)
            }
            Err(e) => {
                Err(e.into())
            }
        }
    }

    async fn start_container_for_run(
        docker_manager: Docker,
        container_id: String,
    ) -> Result<(), anyhow::Error> {
        if let Err(e) = docker_manager.start_container::<String>(&container_id, None).await {
            return Err(e.into());
        }
        Ok(())
    }

    pub async fn run_image_with_progress_updates(
        &self,
        mqtt_config: MQTTConfig,
        image: &str,
        name: Option<&str>,
        envs: Option<HashMap<String, String>>,
        ports: Option<Value>,
        volumes: Option<Value>,
    ) -> Result<String, anyhow::Error> {
        let MQTTConfig {
            topic,
            id,
            mqtt_client,
        } = mqtt_config;

        let topic = topic.to_string();
        let id = id.to_string();
        let image = image.to_string();
        let name = name.map(|s| s.to_string());
        let docker = self.docker.clone();
        let credential = self.credential.clone();

        Self::pull_image_for_run(
            docker.clone(),
            credential,
            &topic,
            &id,
            image.clone(),
            mqtt_client.clone()
        ).await?;
    
        let container_id = Self::create_container_for_run(
            docker.clone(),
            image.clone(),
            name.clone(),
            envs,
            ports,
            volumes,
        ).await?;
    
        Self::start_container_for_run(
            docker,
            container_id.clone(),
        ).await?;
    
        Ok(container_id)
    }

    pub async fn get_logs_container(
        &self,
        container_id: &str,
        tail: usize,
    ) -> Result<String, Box<dyn std::error::Error + Send + Sync>> {
    
        let options = Some(LogsOptions::<String> {
            stdout: true,
            stderr: true,
            follow: false,
            tail: tail.to_string(),
            timestamps: false,
            since: 0,
            until: 0,
        });
    
        let mut logs_stream = self.docker.logs(container_id, options);
    
        let mut logs = String::new();
    
        while let Some(chunk) = logs_stream.try_next().await? {
            match chunk {
                LogOutput::StdOut { message }
                | LogOutput::StdErr { message } => {
                    logs.push_str(&String::from_utf8_lossy(&message));
                }
                _ => {}
            }
        }
    
        Ok(logs)
    }

    pub async fn list_all_containers2(&self) -> Result<Vec<Value>, Box<dyn std::error::Error + Send + Sync>> {

        let options = ListContainersOptions::<String> {
            all: true,
            ..Default::default()
        };

        let containers = self.docker.list_containers(Some(options)).await?;

        Ok(containers
            .into_iter()
            .map(|c| {
                serde_json::json!({
                    "id": c.id,
                    "names": c.names,
                    "image": c.image,
                    "image_id": c.image_id,
                    "command": c.command,
                    "created": c.created,
                    "state": c.state,
                    "status": c.status,
                    "ports": c.ports,
                    "labels": c.labels,
                    "size_rw": c.size_rw,
                    "size_root_fs": c.size_root_fs,
                    "host_config": c.host_config,
                    "network_settings": c.network_settings,
                    "mounts": c.mounts,
                })
            })
            .collect())
    }

    pub async fn execute_command(&self, command: DockerCommand) -> DockerResponse {
        match command {
            DockerCommand::Start { action_type: _,  container_id } => {
                match self.start_container(&container_id).await {
                    Ok(_) => DockerResponse {
                        success: true,
                        message: format!("Container {} started successfully", container_id),
                        data: None,
                    },
                    Err(e) => DockerResponse {
                        success: false,
                        message: format!("Failed to start container {}: {}", container_id, e),
                        data: None,
                    },
                }
            }
            DockerCommand::Stop { action_type: _,  container_id } => {
                match self.stop_container(&container_id).await {
                    Ok(_) => DockerResponse {
                        success: true,
                        message: format!("Container {} stopped successfully", container_id),
                        data: None,
                    },
                    Err(e) => DockerResponse {
                        success: false,
                        message: format!("Failed to stop container {}: {}", container_id, e),
                        data: None,
                    },
                }
            }
            DockerCommand::Restart { action_type: _, container_id } => {
                match self.restart_container(&container_id).await {
                    Ok(_) => DockerResponse {
                        success: true,
                        message: format!("Container {} restarted successfully", container_id),
                        data: None,
                    },
                    Err(e) => DockerResponse {
                        success: false,
                        message: format!("Failed to restart container {}: {}", container_id, e),
                        data: None,
                    },
                }
            }
            DockerCommand::Delete { action_type: _,  container_id, force } => {
                match self.delete_container(&container_id, force).await {
                    Ok(_) => DockerResponse {
                        success: true,
                        message: format!("Container {} deleted successfully", container_id),
                        data: None,
                    },
                    Err(e) => DockerResponse {
                        success: false,
                        message: format!("Failed to delete container {}: {}", container_id, e),
                        data: None,
                    },
                }
            }
            DockerCommand::RunImageProgress { id: _, image, name, envs: _, ports: _, volumes: _ } => {
                DockerResponse {
                    success: true,
                    message: format!("Started running image {} with progress updates", image),
                    data: Some(serde_json::json!({ "status": "started", "image": image, "name": name })),
                }
            }
            DockerCommand::GetLogs { stream_id: _, container_id, flag: _ } => {
                DockerResponse {
                    success: false,
                    message: format!("Logs functionality temporarily disabled for container {}", container_id),
                    data: None,
                }
            }
            DockerCommand::GetContainers { stream_id: _, container_ids: _ } => {
                DockerResponse {
                    success: false,
                    message: "Get container logs failed".to_string(),
                    data: None,
                }
            }
            DockerCommand::Exception { error } => {
                DockerResponse {
                    success: false,
                    message: format!("Failed message: {}", error),
                    data: None,
                }
            }
        }
    }
}
