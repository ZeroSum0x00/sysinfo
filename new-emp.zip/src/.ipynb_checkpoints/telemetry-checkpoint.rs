use anyhow::Result;

use sysinfo::{System, Components, Disks, Networks};

use crate::hwinfo::get_cpu_info::get_all_cpu_info;
use crate::hwinfo::get_gpu_info::{get_gpu_vendor, get_all_gpu_info};
use crate::hwinfo::get_memory_info::get_all_memory_info;
use crate::hwinfo::get_disk_info::{DiskIoCache, get_all_disk_info};
use crate::hwinfo::get_network_info::{get_primary_interface, get_network_stats};
use crate::hwinfo::get_power_info::{PowerInfo, get_all_power_info};
use crate::types::{SystemMetrics, MetricsInfo};
use chrono::Utc;
use tokio::sync::Mutex;
use std::sync::Arc;
use std::time::Instant;
// use crate::hwinfo::power::rapl_power::{init_rapl, RaplState};
use crate::hwinfo::get_cpu_info::{init_rapl, RaplState};
use crate::utils::helper::is_jetson;
use crate::hwinfo::get_cpu_info::CpuInfo;


pub struct TelemetryCollector {
    system: Arc<Mutex<System>>,
    components: Arc<Mutex<Components>>,
    disks: Arc<Mutex<Disks>>,
    disk_cache: Arc<Mutex<DiskIoCache>>,
    networks: Arc<Mutex<Networks>>,
    cpu_rapl: Option<Arc<Mutex<RaplState>>>,
}

impl TelemetryCollector {
    pub fn new() -> Result<Self> {
        let system = Arc::new(Mutex::new(System::new_all()));
        let components = Arc::new(Mutex::new(Components::new_with_refreshed_list()));
        let disks = Arc::new(Mutex::new(Disks::new_with_refreshed_list()));
        let disk_cache = Arc::new(Mutex::new(DiskIoCache {
            last_ts: Instant::now(),
            state: Default::default(),
        }));
        let cpu_rapl = if is_jetson() {
            None
        } else {
            Some(Arc::new(Mutex::new(init_rapl()?)))
        };
        
        let networks = Arc::new(Mutex::new(Networks::new_with_refreshed_list()));

        Ok(Self {
            system,
            components,
            disks,
            disk_cache,
            networks,
            cpu_rapl
        })
    }

    pub async fn collect(&self, device_id: String) -> anyhow::Result<SystemMetrics> {
        let mut system_instance = self.system.lock().await;
        let mut component_instance = self.components.lock().await;
        let mut disk_instance = self.disks.lock().await;
        let mut disk_cache_instance = self.disk_cache.lock().await;
        let mut network_instance = self.networks.lock().await;
        // let mut cpu_rapl_instance = self.cpu_rapl.lock().await;
        let uptime = System::uptime();
    
        // let cpus = get_all_cpu_info(&mut system_instance, &mut component_instance, &mut *cpu_rapl_instance);
        let cpus = if let Some(cpu_rapl) = &self.cpu_rapl {
            let mut rapl_guard = cpu_rapl.lock().await;
            get_all_cpu_info(
                &mut system_instance,
                &mut component_instance,
                Some(&mut *rapl_guard),
            )
        } else {
            get_all_cpu_info(
                &mut system_instance,
                &mut component_instance,
                None,
            )
        };

        let memories = get_all_memory_info(&mut system_instance);
        let disks = get_all_disk_info(&mut disk_instance, &mut disk_cache_instance);
    
        let iface = get_primary_interface().unwrap_or_default();
        let network = get_network_stats(&iface, &mut network_instance);
    
        let gpus_vendor = get_gpu_vendor();
        let vendor = gpus_vendor
            .first()
            .map(|v| match v.to_lowercase().as_str() {
                "jepack" => "tegrastats",
                "nvidia" => "nvidia",
                "amd" => "rocm",
                _ => "unknown",
            })
            .unwrap_or("unknown");
    
        let gpus = get_all_gpu_info(vendor);

        let mut metrics = MetricsInfo {
            cpu: cpus,
            gpu: gpus,
            memory: memories,
            disk: disks,
            network_metrics: network,
            power: PowerInfo { power_consum: 0.0 },
        };
        let power = get_all_power_info(metrics.clone());
        metrics.power = power?;
        println!("{:?}", metrics);
        Ok(SystemMetrics {
            device_id,
            metrics,
            uptime,
            timestamp: Utc::now(),
        })
    }

}
