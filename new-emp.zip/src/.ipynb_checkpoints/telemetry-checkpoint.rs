use chrono::Utc;
use std::sync::Arc;
use anyhow::Result;
use tokio::sync::Mutex;
use std::time::Instant;
use sysinfo::{System, Components, Disks, Networks};
use tracing::info;

use crate::hwinfo::{
    cpu::{
        estimate_cpu_power::{init_cpu_estimate, CpuEstimateState},
        rapl_cpu_power::{init_rapl, RaplState},
    },
    get_cpu_info::{CpuPowerBackendMut, get_all_cpu_info},
    get_gpu_info::get_all_gpu_info,
    get_memory_info::get_all_memory_info,
    get_disk_info::{DiskIoCache, get_all_disk_info},
    get_network_info::{get_primary_interface, get_network_stats},
    get_power_info::{PowerInfo, get_all_power_info}
};
use crate::types::{SystemMetrics, MetricsInfo};
use crate::utils::helper::is_jetson;


enum CpuPowerSource {
    Rapl(Arc<Mutex<RaplState>>),
    Estimate(Arc<Mutex<CpuEstimateState>>),
}

pub struct TelemetryCollector {
    system: Arc<Mutex<System>>,
    components: Arc<Mutex<Components>>,
    disks: Arc<Mutex<Disks>>,
    disk_cache: Arc<Mutex<DiskIoCache>>,
    networks: Arc<Mutex<Networks>>,
    cpu_backend: Option<CpuPowerSource>,
}

impl TelemetryCollector {
    pub fn new() -> Result<Self> {
        let system = Arc::new(Mutex::new(System::new_all()));
        let components = Arc::new(Mutex::new(Components::new_with_refreshed_list()));
        let disks = Arc::new(Mutex::new(Disks::new_with_refreshed_list()));
        let disk_cache = Arc::new(Mutex::new(DiskIoCache {
            last_ts: Instant::now(),
            state: Default::default(),
        }));

        let cpu_backend = if is_jetson() {
            info!("{}", "use jetpack backend");
            None
        } else if let Some(rapl) = init_rapl() {
            info!("{}", "use rapl backend");
            Some(CpuPowerSource::Rapl(Arc::new(Mutex::new(rapl))))
        } else {
            info!("{}", "use estimate backend");
            Some(CpuPowerSource::Estimate(Arc::new(Mutex::new(init_cpu_estimate(15., 90.)?))))
        };
        
        let networks = Arc::new(Mutex::new(Networks::new_with_refreshed_list()));

        Ok(Self {
            system,
            components,
            disks,
            disk_cache,
            networks,
            cpu_backend,
        })
    }

    pub async fn collect(&self, device_id: String) -> anyhow::Result<SystemMetrics> {
        let mut system_instance = self.system.lock().await;
        let mut component_instance = self.components.lock().await;
        let mut disk_instance = self.disks.lock().await;
        let mut disk_cache_instance = self.disk_cache.lock().await;
        let mut network_instance = self.networks.lock().await;
        let uptime = System::uptime();

        let cpus = match &self.cpu_backend {
            Some(CpuPowerSource::Rapl(rapl)) => {
                let mut rapl_guard = rapl.lock().await;
                get_all_cpu_info(
                    &mut system_instance,
                    &mut component_instance,
                    Some(CpuPowerBackendMut::Rapl(&mut rapl_guard))
                )
            }
            Some(CpuPowerSource::Estimate(estimate)) => {
                let mut estimate_guard = estimate.lock().await;
                get_all_cpu_info(
                    &mut system_instance,
                    &mut component_instance,
                    Some(CpuPowerBackendMut::Estimate(&mut estimate_guard))
                )
            }
            None => {
                get_all_cpu_info(
                    &mut system_instance,
                    &mut component_instance,
                    None,
                )
            }
        };
            
        let memories = get_all_memory_info(&mut system_instance);
        let disks = get_all_disk_info(&mut disk_instance, &mut disk_cache_instance);
    
        let iface = get_primary_interface().unwrap_or_default();
        let network = get_network_stats(&iface, &mut network_instance);
        let gpus = get_all_gpu_info();

        let mut metrics = MetricsInfo {
            cpu: cpus,
            gpu: gpus,
            memory: memories,
            disk: disks,
            network_metrics: network,
            power: PowerInfo { power_consum: 0.0, power_in: 0.0 },
        };
        let power = get_all_power_info(metrics.clone());
        metrics.power = power?;
        // println!("{:?}", metrics);
        Ok(SystemMetrics {
            device_id,
            metrics,
            uptime,
            timestamp: Utc::now(),
        })
    }

}
