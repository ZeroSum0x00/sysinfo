use anyhow::Result;
use tracing::{debug, error, info, warn};
use serde_json::{Value, json, to_string};
use tokio::{
    task,
    sync::{Mutex, mpsc},
};
use rumqttc::{AsyncClient, Event, Incoming, MqttOptions, QoS, LastWill, Transport, TlsConfiguration};

use crate::types::{Alert, AlertType, AlertData, SystemMetrics, SSHResponse, ApplicationLogResponse, ContainerLogs};
use crate::config::MqttConfig;
use crate::docker_manager::{
    MQTTConfig,
    DockerCommand, DockerManager, DockerResponse,
    OperatorPublisherConfig, ApplicationPublisherConfig
};
use crate::utils::convert_message::{convert_message_docker, convert_message_ssh};
use crate::reverse_ssh::ReverseSsh;
use futures_util::future::Abortable;
use futures_util::future::AbortHandle;
use std::collections::HashMap;


use rumqttc::tokio_rustls::rustls::{
    ClientConfig, RootCertStore,
    pki_types::PrivateKeyDer,
};

use rustls_pemfile::{certs, pkcs8_private_keys, rsa_private_keys};

use std::{
    fs,
    sync::Arc,
    time::Duration,
};


#[derive(Clone)]
pub struct MqttProgressPublisher {
    client: AsyncClient,
    qos: QoS,
}

impl MqttProgressPublisher {
    pub async fn publish_to_topic(&self, topic: &str, payload: String) -> Result<()> {
        self.client.publish(topic, self.qos, false, payload).await?;
        Ok(())
    }
}

fn build_tls_config(
    ca_path: &str,
    cert_path: &str,
    key_path: &str,
) -> ClientConfig {

    // ---------- CA ----------
    let mut root_store = RootCertStore::empty();
    let ca_bytes = fs::read(ca_path).expect("Cannot read CA file");

    for cert in certs(&mut &ca_bytes[..]) {
        let cert = cert.expect("Invalid CA cert");
        root_store.add(cert).unwrap();
    }

    // ---------- Client cert ----------
    let cert_bytes = fs::read(cert_path).expect("Cannot read device cert");

    let mut client_certs = Vec::new();
    for cert in certs(&mut &cert_bytes[..]) {
        let cert = cert.expect("Invalid device cert");
        client_certs.push(cert);
    }

    // ---------- Private key ----------
    let key_bytes = fs::read(key_path).expect("Cannot read private key");

    let private_key = pkcs8_private_keys(&mut &key_bytes[..])
        .next()
        .map(|key| {
            PrivateKeyDer::Pkcs8(key.expect("Invalid PKCS8 key"))
        })
        .or_else(|| {
            rsa_private_keys(&mut &key_bytes[..])
                .next()
                .map(|key| {
                    PrivateKeyDer::Pkcs1(key.expect("Invalid RSA key"))
                })
        })
        .expect("❌ No valid private key found");


    // ---------- Build config ----------
    ClientConfig::builder()
        .with_root_certificates(root_store)
        .with_client_auth_cert(client_certs, private_key)
        .expect("Failed to build TLS config")
}

#[derive(Clone)]
#[allow(dead_code)]
pub struct MqttClient {
    client: AsyncClient,
    default_topic: String,
    telemetry_topic: String,
    log_topic: String,
    docker_info_topic: String,
    command_topic: String,
    ssh_topic: String,
    qos: QoS,
    docker_manager: Option<Arc<Mutex<DockerManager>>>,
    ssh_manager: Option<Arc<Mutex<ReverseSsh>>>,
    log_tasks: Arc<Mutex<HashMap<String, AbortHandle>>>,
}

impl MqttClient {
    pub async fn new(
        config: &MqttConfig,
        docker_manager: Option<Arc<Mutex<DockerManager>>>,
        local_ssh_port: u16,
        ssh_manager: Option<Arc<Mutex<ReverseSsh>>>,
    ) -> Result<Self> {
        let device_id = config.client_id.clone();
        
        info!(
            "Initializing MQTT client: {}@{}:{}",
            device_id, config.broker, config.port
        );
        let will_payload = json!({
            "device_id": device_id,
            "status": "offline",
            "reason": "connection_lost"
        }).to_string();
        
        let qos = match config.qos {
            0 => QoS::AtMostOnce,
            1 => QoS::AtLeastOnce,
            2 => QoS::ExactlyOnce,
            _ => QoS::AtMostOnce,
        };
        let log_qos = QoS::AtMostOnce;
        let mut mqtt_options = MqttOptions::new(&device_id, &config.broker, config.port);
        mqtt_options.set_keep_alive(Duration::from_secs(30));
        
        // tránh nghẽn khi offline
        mqtt_options.set_inflight(200);
        mqtt_options.set_request_channel_capacity(1000);
        
        if config.broker_type == "aws" && !config.ca_path.is_empty() && !config.cert_path.is_empty() && !config.key_path.is_empty() {
            let tls_config = build_tls_config(
                &config.ca_path,
                &config.cert_path,
                &config.key_path,
            );
            
            mqtt_options.set_transport(
                Transport::Tls(
                    TlsConfiguration::Rustls(Arc::new(tls_config))
                )
            );
        }

        // Clone variables for event loop
        let default_base_topic = format!("{}/{}", config.default_topic.clone(), device_id);
        let telemetry_topic_pub = format!("{}/{}", default_base_topic.clone(), config.telemetry_topic.clone());
        let docker_info_topic_pub = format!("{}/{}", default_base_topic.clone(), config.docker_info_topic.clone());
        let log_topic_pub = format!("{}/{}", default_base_topic.clone(), config.log_topic.clone());

        let containers_topic_sub = format!("{}/{}", default_base_topic.clone(), config.docker_info_topic.clone());
        let containers_topic_clone = containers_topic_sub.clone();
        let containers_topic_pub = format!("{}/response", containers_topic_clone.clone());
        
        let command_topic_sub = format!("{}/{}", default_base_topic.clone(), config.command_topic.clone());
        let command_topic_sub_clone = command_topic_sub.clone();
        let command_topic_pub = format!("{}/response", command_topic_sub.clone());
        
        let operator_topic_sub = format!("{}/{}", default_base_topic.clone(), config.operator_topic.clone());
        let operator_topic_sub_clone = operator_topic_sub.clone();
        let operator_topic_pub = format!("{}/response", operator_topic_sub.clone());
        
        let ssh_topic_sub = format!("{}/{}", default_base_topic.clone(), config.ssh_topic.clone());
        let ssh_topic_sub_clone = ssh_topic_sub.clone();
        let ssh_topic_pub = format!("{}/response", ssh_topic_sub.clone());

        let application_log_topic_sub = format!("{}/{}", default_base_topic.clone(), config.application_log_topic.clone());
        let application_log_topic_sub_clone = application_log_topic_sub.clone();
        let application_log_topic_pub = format!("{}/response", application_log_topic_sub.clone());

        mqtt_options.set_last_will(LastWill::new(
            format!("{}/presence", default_base_topic.clone()),
            will_payload,
            qos,
            false,
        ));

        let (client, mut eventloop) = AsyncClient::new(mqtt_options, 1000);
        
        let log_tasks: Arc<Mutex<HashMap<String, AbortHandle>>> = Arc::new(Mutex::new(HashMap::new()));

        let (mqtt_tx, mut mqtt_rx) = mpsc::channel::<(String, String)>(100);
        let client_pub = client.clone();
        task::spawn(async move {
            while let Some((topic, payload)) = mqtt_rx.recv().await {
                if let Err(e) = client_pub.publish(&topic, log_qos, false, payload).await {
                    error!("MQTT publish failed: {}", e);
                }
            }
        });
        
        let docker_controller_manager = docker_manager.clone();
        let client_clone = client.clone();
        let ssh_manager_clone = ssh_manager.clone();
        let log_tasks_clone = log_tasks.clone();
        let mqtt_tx_clone = mqtt_tx.clone();
        let log_topic_pub_clone = log_topic_pub.clone();
        
        // Spawn event loop handler
        task::spawn(async move {
            loop {
                match eventloop.poll().await {
                    Ok(Event::Incoming(Incoming::ConnAck(_))) => {
                        info!("MQTT connected successfully");
                    }
                    Ok(Event::Incoming(Incoming::Disconnect)) => {
                        warn!("MQTT disconnected");
                    }
                    Ok(Event::Incoming(Incoming::Publish(publish))) => {
                        debug!(
                            "MQTT message received on topic '{}': {} bytes",
                            publish.topic,
                            publish.payload.len()
                        );

                        println!("DEBUG MQTT: Topic matches, docker_manager is_some: {}", docker_controller_manager.is_some());
                        let client_for_task = client_clone.clone();
                        let device_id_clone = device_id.clone();
                        
                        // Handle Docker commands
                        if publish.topic == containers_topic_sub && let Some(ref docker_mgr) = docker_controller_manager {
                            let docker_mgr_for_task = docker_mgr.clone();
                            
                            match convert_message_docker(&publish.payload).await {
                                Ok(command) => {
                                    info!("Executing Docker Containers command: {:?}", command);
                                    if let DockerCommand::GetContainers { stream_id, container_ids } = command {
                                        let docker_mgr_for_inspect = docker_mgr.clone();
                                        let docker_stats = docker_mgr_for_inspect
                                                .lock()
                                                .await
                                                .get_container_stats(container_ids)
                                                .await;
                                        
                                        let msg = match docker_stats {
                                            Ok(stats) => {
                                                Some(ContainerLogs {
                                                    stream_id,
                                                    device_id: device_id_clone,
                                                    containers: Some(stats),
                                                })                                                
                                            }
                                            Err(_e) => {
                                                Some(ContainerLogs {
                                                    stream_id,
                                                    device_id: device_id_clone,
                                                    containers: Some(serde_json::json!([])),
                                                })
                                            }
                                        };

                                        if let Some(m) = msg && let Ok(json) = to_string(&m) {
                                            let _ = client_clone.publish(&containers_topic_pub, qos, false, json).await;
                                            info!("MQTT send docker container log");
                                        }

                                        
                                    } else {
                                        let response = docker_mgr_for_task.lock().await.execute_command(command).await;
                                        // Publish response
                                        if let Ok(response_json) = to_string(&response) {
                                            let _ = client_clone.publish(&command_topic_pub, qos, false, response_json).await;
                                        }
                                    }
                                }
                                Err(e) => {
                                    error!("Failed to parse Docker command: {}", e);
                                    let error_response = DockerResponse {
                                        success: false,
                                        message: format!("Invalid command format: {}", e),
                                        data: None,
                                    };
                                    if let Ok(response_json) = to_string(&error_response) {
                                        let _ = client_clone.publish(&command_topic_pub, qos, false, response_json).await;
                                    }
                                }
                            }
                        } else if publish.topic == command_topic_sub && let Some(ref docker_mgr) = docker_controller_manager {
                            // Debug payload
                            // let payload_str = String::from_utf8_lossy(&publish.payload);
                            // println!("DEBUG MQTT: Received payload: {}", payload_str);

                            let docker_mgr_for_task = docker_mgr.clone();
                            
                            match convert_message_docker(&publish.payload).await {
                                Ok(command) => {
                                    info!("Executing Docker command: {:?}", command);
                                    
                                    if let DockerCommand::RunImageProgress { id, image, name, envs, ports, volumes } = command {
                                        let docker_mgr_for_inspect = docker_mgr.clone();
                                        let mqtt_config = MQTTConfig {
                                            topic: command_topic_pub.clone(),
                                            id: id.clone(),
                                            mqtt_client: Arc::new(MqttProgressPublisher {
                                                             client: client_clone.clone(),
                                                             qos,
                                                         }),
                                        };
                                        
                                        let command_topic_pub_for_task = command_topic_pub.clone();
                                        
                                        tokio::spawn(async move {
                                            let created_container_id =
                                                docker_mgr_for_task.lock().await
                                                    .run_image_with_progress_updates(
                                                        mqtt_config,
                                                        &image.clone(),
                                                        name.clone().as_deref(),
                                                        envs,
                                                        ports,
                                                        volumes,
                                                    )
                                                    .await;
                                        
                                            let container_id = match created_container_id {
                                                Ok(id) => id,
                                                Err(e) => {
                                                    error!("Failed to run container: {:?}", e);
                                                    return;
                                                }
                                            };
                                        
                                            let state = docker_mgr_for_inspect
                                                .lock()
                                                .await
                                                .inspect_container_status(&container_id)
                                                .await
                                                .unwrap_or_else(|_| "unknown".to_string());
                                        
                                            let payload = json!({
                                                "container_id": container_id,
                                                "status": state,
                                            });
                                        
                                            let data_publisher = ApplicationPublisherConfig {
                                                id,
                                                status: "successfully".to_string(),
                                                step: "run".to_string(),
                                                message: "".to_string(),
                                                payload,
                                            };
                                        
                                            if let Ok(json) = to_string(&data_publisher) {
                                                let _ = client_for_task
                                                    .publish(&command_topic_pub_for_task, qos, false, json)
                                                    .await;
                                            }
                                        });
                                    } else {
                                        let response = docker_mgr_for_task.lock().await.execute_command(command).await;

                                        // Publish response
                                        if let Ok(response_json) = to_string(&response) {
                                            let _ = client_clone.publish(&command_topic_pub, qos, false, response_json).await;
                                        }
                                    }
                                }
                                Err(e) => {
                                    error!("Failed to parse Docker command: {}", e);
                                    let error_response = DockerResponse {
                                        success: false,
                                        message: format!("Invalid command format: {}", e),
                                        data: None,
                                    };
                                    if let Ok(response_json) = to_string(&error_response) {
                                        let _ = client_clone.publish(&command_topic_pub, qos, false, response_json).await;
                                    }
                                }
                            }
                        } else if publish.topic == operator_topic_sub && let Some(ref docker_mgr) = docker_controller_manager {
                            match convert_message_docker(&publish.payload).await {
                                Ok(command) => {
                                    info!("Executing Docker command: {:?}", command);
                                    let docker_mgr_for_task = docker_mgr.clone();
                                    let docker_mgr_for_inspect = docker_mgr.clone();
                                    let operator_topic_pub_for_task = operator_topic_pub.clone();
                                    
                                    // Handle special case for PullImageProgress and RunImageProgress
                                    if let DockerCommand::Start { action_type, container_id } = command {
                                        let container_id_for_task = container_id.clone();
                                        tokio::spawn(async move {
                                            let res = docker_mgr_for_task
                                                .lock()
                                                .await
                                                .start_container(&container_id_for_task)
                                                .await;
                                        
                                            if let Err(e) = res {
                                                error!("Failed to start container {}: {:?}", container_id_for_task, e);
                                        
                                                let response = OperatorPublisherConfig {
                                                    container_id: container_id_for_task,
                                                    state: "error".to_string(),
                                                    status: "failed".to_string(),
                                                    message: e.to_string(),
                                                    _type: action_type.to_string(),
                                                };
                                        
                                                if let Ok(json) = to_string(&response) {
                                                    let _ = client_for_task.publish(&operator_topic_pub_for_task, qos, false, json).await;
                                                }
                                                return;
                                            }
                                        
                                            info!("Container {} start requested", container_id_for_task);
                                        
                                            tokio::time::sleep(std::time::Duration::from_millis(300)).await;
                                        
                                            let state = docker_mgr_for_inspect
                                                .lock()
                                                .await
                                                .inspect_container_status(&container_id_for_task)
                                                .await
                                                .unwrap_or_else(|_| "unknown".to_string());
                                        
                                            let response = OperatorPublisherConfig {
                                                container_id: container_id_for_task,
                                                state,
                                                status: "successfully".to_string(),
                                                message: "".to_string(),
                                                _type: action_type.to_string(),
                                            };
                                        
                                            if let Ok(json) = to_string(&response) {
                                                let _ = client_for_task.publish(&operator_topic_pub_for_task, qos, false, json).await;
                                            }
                                        });
                                    } else if let DockerCommand::Stop { action_type, container_id } = command {
                                        let container_id_for_task = container_id.clone();
                                        tokio::spawn(async move {
                                            let res = docker_mgr_for_task
                                                .lock()
                                                .await
                                                .stop_container(&container_id_for_task)
                                                .await;
                                        
                                            if let Err(e) = res {
                                                error!("Failed to stop container {}: {:?}", container_id_for_task, e);
                                        
                                                let response = OperatorPublisherConfig {
                                                    container_id: container_id_for_task,
                                                    state: "error".to_string(),
                                                    status: "failed".to_string(),
                                                    message: e.to_string(),
                                                    _type: action_type.to_string(),
                                                };
                                        
                                                if let Ok(json) = to_string(&response) {
                                                    let _ = client_for_task.publish(&operator_topic_pub_for_task, qos, false, json).await;
                                                }
                                                return;
                                            }
                                        
                                            info!("Container {} stop requested", container_id_for_task);
                                        
                                            tokio::time::sleep(std::time::Duration::from_millis(300)).await;
                                        
                                            let state = docker_mgr_for_inspect
                                                .lock()
                                                .await
                                                .inspect_container_status(&container_id_for_task)
                                                .await
                                                .unwrap_or_else(|_| "unknown".to_string());
                                        
                                            let response = OperatorPublisherConfig {
                                                container_id: container_id_for_task,
                                                state,
                                                status: "successfully".to_string(),
                                                message: "".to_string(),
                                                _type: action_type.to_string(),
                                            };
                                        
                                            if let Ok(json) = to_string(&response) {
                                                let _ = client_for_task.publish(&operator_topic_pub_for_task, qos, false, json).await;
                                            }
                                        });
                                    } else if let DockerCommand::Restart { action_type, container_id } = command {
                                        let container_id_for_task = container_id.clone();
                                        tokio::spawn(async move {
                                            let res = docker_mgr_for_task
                                                .lock()
                                                .await
                                                .restart_container(&container_id_for_task)
                                                .await;
                                        
                                            if let Err(e) = res {
                                                error!("Failed to restart container {}: {:?}", container_id_for_task, e);
                                        
                                                let response = OperatorPublisherConfig {
                                                    container_id: container_id_for_task,
                                                    state: "error".to_string(),
                                                    status: "failed".to_string(),
                                                    message: e.to_string(),
                                                    _type: action_type.to_string(),
                                                };
                                        
                                                if let Ok(json) = to_string(&response) {
                                                    let _ = client_for_task.publish(&operator_topic_pub_for_task, qos, false, json).await;
                                                }
                                                return;
                                            }
                                        
                                            info!("Container {} restart requested", container_id_for_task);
                                        
                                            tokio::time::sleep(std::time::Duration::from_millis(300)).await;
                                        
                                            let state = docker_mgr_for_inspect
                                                .lock()
                                                .await
                                                .inspect_container_status(&container_id_for_task)
                                                .await
                                                .unwrap_or_else(|_| "unknown".to_string());
                                        
                                            let response = OperatorPublisherConfig {
                                                container_id: container_id_for_task,
                                                state,
                                                status: "successfully".to_string(),
                                                message: "".to_string(),
                                                _type: action_type.to_string(),
                                            };
                                        
                                            if let Ok(json) = to_string(&response) {
                                                let _ = client_for_task.publish(&operator_topic_pub_for_task, qos, false, json).await;
                                            }
                                        });
                                    } else if let DockerCommand::Delete { action_type, container_id, force } = command {
                                        let container_id_for_task = container_id.clone();
                                        tokio::spawn(async move {
                                            let res = docker_mgr_for_task
                                                .lock()
                                                .await
                                                .delete_container(&container_id_for_task, force)
                                                .await;
                                        
                                            if let Err(e) = res {
                                                error!("Failed to delete container {}: {:?}", container_id_for_task, e);
                                        
                                                let response = OperatorPublisherConfig {
                                                    container_id: container_id_for_task,
                                                    state: "error".to_string(),
                                                    status: "failed".to_string(),
                                                    message: e.to_string(),
                                                    _type: action_type.to_string(),
                                                };
                                        
                                                if let Ok(json) = to_string(&response) {
                                                    let _ = client_for_task.publish(&operator_topic_pub_for_task, qos, false, json).await;
                                                }
                                                return;
                                            }
                                        
                                            info!("Container {} delete requested", container_id_for_task);
                                        
                                            tokio::time::sleep(std::time::Duration::from_millis(300)).await;
                                        
                                            let state = docker_mgr_for_inspect
                                                .lock()
                                                .await
                                                .inspect_container_status(&container_id_for_task)
                                                .await
                                                .unwrap_or_else(|_| "unknown".to_string());
                                        
                                            let response = OperatorPublisherConfig {
                                                container_id: container_id_for_task,
                                                state,
                                                status: "successfully".to_string(),
                                                message: "".to_string(),
                                                _type: action_type.to_string(),
                                            };
                                        
                                            if let Ok(json) = to_string(&response) {
                                                let _ = client_for_task.publish(&operator_topic_pub_for_task, qos, false, json).await;
                                            }
                                        });
                                    } else {
                                        // Handle other commands normally
                                        let docker_mgr_locked = docker_mgr.lock().await;
                                        let response = docker_mgr_locked.execute_command(command).await;

                                        // Publish response
                                        if let Ok(response_json) = to_string(&response) {
                                            let _ = client_clone.publish(&operator_topic_pub_for_task, qos, false, response_json).await;
                                        }
                                    }
                                }
                                Err(e) => {
                                    error!("Failed to parse Docker command: {}", e);
                                    let error_response = DockerResponse {
                                        success: false,
                                        message: format!("Invalid command format: {}", e),
                                        data: None,
                                    };
                                    if let Ok(response_json) = to_string(&error_response) {
                                        let _ = client_clone.publish(&operator_topic_pub.clone(), qos, false, response_json).await;
                                    }
                                }
                            }
                        } else if publish.topic == ssh_topic_sub && let Some(ref ssh_manager_clone) = ssh_manager_clone{
                            match convert_message_ssh(&publish.payload, local_ssh_port) {
                                Ok(command) => {
                                    let command_clone = command.clone();
                                    let result = ssh_manager_clone.lock().await.execute_command(command);
                                    match result {
                                        Ok(_) => {
                                            let response = SSHResponse {
                                                success: true,
                                                message: format!("Executed SSH command: {:?}", command_clone),
                                                data: None,
                                            };
                                            if let Ok(response_json) = to_string(&response) {
                                                let _ = client_for_task.publish(&ssh_topic_pub, qos, false, response_json).await;
                                            }
                                        }
                                        Err(e) => {
                                            let alert_data = Alert {
                                                alert_code: AlertType::UnauthorizedSSH.code().to_string(),
                                                device_id: device_id_clone,
                                                data: AlertData{
                                                    message: e.to_string(),
                                                    value: 0.
                                                }
                                            };
                                            
                                            if let Ok(alert) = to_string(&alert_data) {
                                                let _ = client_for_task.publish(&log_topic_pub_clone, qos, false, alert).await;
                                            }
                                            
                                            let error_response = SSHResponse {
                                                success: false,
                                                message: format!("Command execution failed: {}", e),
                                                data: None,
                                            };
                                            
                                            if let Ok(error_json) = to_string(&error_response) {
                                                let _ = client_for_task.publish(&ssh_topic_pub, qos, false, error_json).await;
                                            }
                                            
                                            error!("Failed to execute SSH command: {}", e);
                                        }
                                    }
                                }
                                Err(e) => {
                                    error!("Failed to parse SSH command: {}", e);
                                    let error_response = SSHResponse {
                                        success: false,
                                        message: format!("Invalid command format: {}", e),
                                        data: None,
                                    };
                                    if let Ok(error_json) = to_string(&error_response) {
                                        let _ = client_for_task.publish(&ssh_topic_pub, qos, false, error_json).await;
                                    }
                                }
                            }
                        } else if publish.topic == application_log_topic_sub && let Some(ref docker_mgr) = docker_controller_manager {
                            
                            match convert_message_docker(&publish.payload).await {
                                Ok(command) => {
                                    info!("Executing Docker command: {:?}", command);
                                    if let DockerCommand::GetLogs { stream_id, container_id, flag } = command {
                                        let mut tasks = log_tasks_clone.lock().await;

                                        if !flag {
                                            if let Some(h) = tasks.remove(&stream_id) {
                                                h.abort();
                                                info!("Stopped log stream for {}", stream_id);
                                            }
                                            continue;
                                        }

                                        if tasks.contains_key(&stream_id) {
                                            debug!("Log stream already running for {}", stream_id);
                                            continue;
                                        }
                                        let sid = stream_id.clone();
                                        let cid = container_id.clone();
                                        let docker_mgr = docker_mgr.clone();
                                        let tx = mqtt_tx_clone.clone();
                                        let topic = application_log_topic_pub.clone();

                                        let (abort_handle, abort_reg) = AbortHandle::new_pair();
                                        
                                        
                                        task::spawn(Abortable::new(
                                            async move {
                                                let mut first = true;
                                                let mut last_log = String::new();

                                                loop {
                                                    let mut is_failed = false;
                                                    let tail = if first {
                                                        first = false;
                                                        20
                                                    } else {
                                                        1
                                                    };

                                                    let res = docker_mgr
                                                        .lock()
                                                        .await
                                                        .get_logs_container(&cid, tail)
                                                        .await;

                                                    let msg = match res {
                                                        Ok(log) if log != last_log => {
                                                            is_failed = false;
                                                            last_log = log.clone();
                                                            Some(ApplicationLogResponse {
                                                                stream_id: sid.clone(),
                                                                container_id: cid.clone(),
                                                                status: "success".into(),
                                                                message: log,
                                                            })
                                                        }
                                                        Err(e) => {
                                                            is_failed = true;
                                                            Some(ApplicationLogResponse {
                                                                stream_id: sid.clone(),
                                                                container_id: cid.clone(),
                                                                status: "failed".into(),
                                                                message: e.to_string(),
                                                            })
                                                        },
                                                        _ => None,
                                                    };
                                                    
                                                    if let Some(m) = msg && let Ok(json) = to_string(&m) {
                                                        let _ = tx.send((topic.clone(), json)).await;
                                                        info!("MQTT send application-log");
                                                    }
                                                    
                                                    tokio::time::sleep(Duration::from_secs(2)).await;
                                                    if is_failed {
                                                        break;
                                                    }
                                                }
                                            },
                                            abort_reg,
                                        ));

                                        tasks.insert(stream_id, abort_handle);
                                    }
                                }
                                Err(e) => {
                                    error!("Failed to parse Docker command: {}", e);
                                    let error_response = DockerResponse {
                                        success: false,
                                        message: format!("Invalid command format: {}", e),
                                        data: None,
                                    };
                                    if let Ok(response_json) = to_string(&error_response) {
                                        let _ = client_clone.publish(&command_topic_pub, qos, false, response_json).await;
                                    }
                                }
                            }
                        }
                    }
                    Ok(Event::Incoming(Incoming::SubAck(suback))) => {
                        info!("MQTT subscription acknowledged: {:?}", suback);
                    }
                    Ok(Event::Incoming(Incoming::PubAck(puback))) => {
                        debug!("MQTT publish acknowledged: packet_id={}", puback.pkid);
                    }
                    Ok(Event::Outgoing(outgoing)) => {
                        debug!("MQTT outgoing event: {:?}", outgoing);
                    }
                    Err(e) => {
                        error!("MQTT connection error: {:?}", e);
                        tokio::time::sleep(Duration::from_secs(1)).await;
                    }
                    _ => {
                        debug!("MQTT unhandled event");
                    }
                }
            }
        });

        // Subscribe to command topic if Docker manager is available
        if docker_manager.is_some() {
            client.subscribe(&containers_topic_clone, qos).await?;
            client.subscribe(&command_topic_sub_clone, qos).await?;
            client.subscribe(&operator_topic_sub_clone, qos).await?;
            client.subscribe(&ssh_topic_sub_clone, qos).await?;
            client.subscribe(&application_log_topic_sub_clone, qos).await?;
            // info!(
            //     "Subscribed to Docker command topic: {}",
            //     command_topic_sub_clone.clone()
            // );
        }

        Ok(Self {
            client,
            default_topic: default_base_topic.clone(),
            telemetry_topic: telemetry_topic_pub.clone(),
            log_topic: log_topic_pub.clone(),
            docker_info_topic: docker_info_topic_pub.clone(),
            command_topic: config.command_topic.clone(),
            ssh_topic: config.ssh_topic.clone(),
            qos,
            docker_manager,
            ssh_manager,
            log_tasks,
        })
    }

    pub async fn publish_telemetry(&self, metrics: &SystemMetrics, qos: QoS) -> Result<()> {
        let payload = to_string(metrics)?;
        self.client
            .publish(&self.telemetry_topic, qos, false, payload.clone())
            .await?;        
        info!(
            "Publishing telemetry to topic '{}' at qos {:?} ({} bytes)",
            self.telemetry_topic,
            qos,
            payload.len()
        );
        Ok(())
    }

    pub async fn publish_alert(&self, alert: &Alert) -> Result<()> {
        let payload = to_string(alert)?;
        // warn!(
        //     "Publishing alert to topic '{}' ({} bytes): {}",
        //     self.log_topic,
        //     payload.len(),
        //     alert.message
        // );
        debug!("Alert payload: {}", payload);
        self.client
            .publish(&self.log_topic, self.qos, false, payload)
            .await?;
        Ok(())
    }
    
    pub async fn publish_container_stats2(
        &self,
        stats: &Value,
        client_id_clone: &str,
    ) -> Result<()> {
        let mut payload_value = stats.clone();
    
        if let Value::Object(ref mut map) = payload_value {
            map.insert(
                "device_id".to_string(),
                Value::String(client_id_clone.to_string()),
            );
        }
    
        let payload = to_string(&payload_value)?;
        self.client
            .publish(&self.docker_info_topic, self.qos, false, payload)
            .await?;
    
        Ok(())
    }

    pub async fn subscribe_to_commands(&self, command_topic: &str) -> Result<()> {
        info!("Subscribing to command topic: '{}'", command_topic);
        self.client.subscribe(command_topic, self.qos).await?;
        Ok(())
    }

    pub async fn publish_log(&self, level: &str, message: &str) -> Result<()> {
        let log_entry = json!({
            "timestamp": chrono::Utc::now().to_rfc3339(),
            "level": level,
            "message": message
        });

        let topic = "logs/edge-controller";
        let payload = log_entry.to_string();
        // info!(
        //     "Publishing log [{}] to topic '{}' ({} bytes): {}",
        //     level,
        //     topic,
        //     payload.len(),
        //     message
        // );
        // debug!("Log payload: {}", payload);
        self.client.publish(topic, self.qos, false, payload).await?;
        Ok(())
    }

    pub async fn publish_to_topic(&self, topic: &str, payload: String) -> Result<()> {
        self.client.publish(topic, self.qos, false, payload.clone()).await?;
        info!("MQTT publish init success to {} with payload {:?} qos {:?}", topic, payload, self.qos);
        Ok(())
    }
}

