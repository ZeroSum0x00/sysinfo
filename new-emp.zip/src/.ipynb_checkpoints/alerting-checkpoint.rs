use crate::types::{Alert, AlertData, AlertType, SystemMetrics};
use crate::config::AlertingConfig;
use crate::mqtt_client::MqttClient;

use chrono::{DateTime, Utc};
use std::{collections::HashMap, sync::Arc};
use tokio::sync::Mutex;

#[derive(Debug, Clone)]
struct AlertState {
    last_alert_time: Option<DateTime<Utc>>,
    is_currently_high: bool,
}


pub struct AlertManager {
    device_id: String,
    mqtt_client: MqttClient,
    config: AlertingConfig,
    alert_states: Arc<Mutex<HashMap<AlertType, AlertState>>>,
}

impl AlertManager {
    pub fn new(
        device_id: String,
        mqtt_client: MqttClient,
        config: AlertingConfig,
    ) -> Self {
        Self {
            device_id,
            mqtt_client,
            config,
            alert_states: Arc::new(Mutex::new(HashMap::new())),
        }
    }

    pub async fn check_alerts(&self, metrics: SystemMetrics) {
        let alerts = {
            let mut states = self.alert_states.lock().await;

            let mut out = Vec::new();

            if let Some(a) = self.check_cpu_alert(&mut states, &metrics) {
                out.push(a);
            }

            if let Some(a) = self.check_gpu_usage_alert(&mut states, &metrics) {
                out.push(a);
            }

            if let Some(a) = self.check_gpu_memory_alert(&mut states, &metrics) {
                out.push(a);
            }
            
            if let Some(a) = self.check_memory_alert(&mut states, &metrics) {
                out.push(a);
            }

            if let Some(a) = self.check_temperature_alert(&mut states, &metrics) {
                out.push(a);
            }

            if let Some(a) = self.check_storage_capacity_alert(&mut states, &metrics) {
                out.push(a);
            }

            out
        };

        for alert in alerts {
            let _ = self.mqtt_client.publish_alert(&alert).await;
        }
    }

    fn check_cpu_alert(
        &self,
        states: &mut HashMap<AlertType, AlertState>,
        metrics: &SystemMetrics,
    ) -> Option<Alert> {
        let level = "Critical";
        let cpu = &metrics.metrics.cpu[0];
        let current_value = cpu.avg_usage;
        let threshold = self.config.cpu_usage_threshold_percent;

        self.check_threshold_alert(
            states,
            AlertType::CpuExeeded,
            current_value,
            threshold,
            &format!("{} | CPU usage exceeded {:.1} threshold", level, threshold),
        )
    }

    fn check_memory_alert(
        &self,
        states: &mut HashMap<AlertType, AlertState>,
        metrics: &SystemMetrics,
    ) -> Option<Alert> {
        let level = "Critical";
        let current_value = metrics.metrics.memory.percent;
        let threshold = self.config.memory_threshold_percent;
        
        self.check_threshold_alert(
            states,
            AlertType::MemoryExeeded,
            current_value,
            threshold,
            &format!("{} | RAM usage exceeded {:.1} threshold", level, threshold),
        )
    }

    fn check_gpu_usage_alert(
        &self,
        states: &mut HashMap<AlertType, AlertState>,
        metrics: &SystemMetrics,
    ) -> Option<Alert> {
        let level = "Critical";
        let current_value: f32 = metrics
            .metrics
            .gpu
            .iter()
            .map(|gpu| gpu.util)
            .fold(0.0_f32, f32::max);
        
        let threshold = self.config.gpu_usage_threshold_percent;
        
        self.check_threshold_alert(
            states,
            AlertType::GpuExeeded,
            current_value,
            threshold,
            &format!("{} | GPU usage exceeded {:.1} on {}", level, threshold, self.device_id),
        )
    }
    
    fn check_gpu_memory_alert(
        &self,
        states: &mut HashMap<AlertType, AlertState>,
        metrics: &SystemMetrics,
    ) -> Option<Alert> {
        let level = "Critical";
        let current_value: f32 = metrics
            .metrics
            .gpu
            .iter()
            .map(|gpu| gpu.vram_percent)
            .fold(0.0_f32, f32::max);
        
        let threshold = self.config.gpu_memory_threshold_percent;
        
        self.check_threshold_alert(
            states,
            AlertType::GpuMemExeeded,
            current_value,
            threshold,
            &format!("{} | GPU memory usage exceeded {:.1} on {}", level, threshold, self.device_id),
        )
    }
    
    fn check_temperature_alert(
        &self,
        states: &mut HashMap<AlertType, AlertState>,
        metrics: &SystemMetrics,
    ) -> Option<Alert> {
        let level = "Critical";
        let cpu = &metrics.metrics.cpu[0];
        let cpu_current_value = cpu.avg_thermal;
        
        let gpu_current_value: f32 = metrics
            .metrics
            .gpu
            .iter()
            .map(|gpu| gpu.thermal)
            .fold(0.0_f32, f32::max);
        
        let warning_threshold = self.config.warning_temperature_threshold_percent;
        let throttled_threshold = self.config.throttled_temperature_threshold_percent;
        
        let value = cpu_current_value.max(gpu_current_value);
        
        let (type_alert, threshold, message) = if value >= throttled_threshold {
            (
                AlertType::TemperatureThrottled,
                throttled_threshold,
                format!(
                    "{} | {} temperature exceeded {:.1} system throttled",
                    level, self.device_id, throttled_threshold
                ),
            )
        } else {
            (
                AlertType::TemperatureExeeded,
                warning_threshold,
                format!(
                    "{} | {} temperature exceeded threshold {:.1}",
                    level, self.device_id, warning_threshold
                ),
            )
        };
        
        self.check_threshold_alert(
            states,
            type_alert,
            value,
            threshold,
            &message,
        )
    }

    fn check_storage_capacity_alert(
        &self,
        states: &mut HashMap<AlertType, AlertState>,
        metrics: &SystemMetrics,
    ) -> Option<Alert> {
        let level = "Critical";
        let disk_current_value: f32 = metrics
            .metrics
            .disk
            .iter()
            .map(|disk| disk.percent)
            .fold(0.0_f32, f32::max);
        
        let warning_threshold = self.config.warning_storage_capacity_threshold_percent;
        let full_threshold = self.config.full_storage_capacity_threshold_percent;
        
        let (type_alert, threshold, message) = if disk_current_value >= full_threshold {
            (
                AlertType::StorageCapacityFull,
                full_threshold,
                format!(
                    "{} | Storage full on {} - data write aborted.",
                    level, self.device_id
                ),
            )
        } else {
            (
                AlertType::StorageCapacityExeeded,
                warning_threshold,
                format!(
                    "{} | Storage usage exceeded {:.1}",
                    level, warning_threshold
                ),
            )
        };
        
        self.check_threshold_alert(
            states,
            type_alert,
            disk_current_value,
            threshold,
            &message,
        )
    }

    fn check_threshold_alert(
        &self,
        states: &mut HashMap<AlertType, AlertState>,
        alert_code: AlertType,
        current_value: f32,
        threshold: f32,
        message: &str,
    ) -> Option<Alert> {
        let now = Utc::now();

        let state = states.entry(alert_code.clone()).or_insert(AlertState {
            last_alert_time: None,
            is_currently_high: false,
        });

        if current_value >= threshold && !state.is_currently_high {
            state.last_alert_time = Some(now);
            state.is_currently_high = false;
                        
            return Some(Alert {
                alert_code: alert_code.code().to_string(),
                device_id: self.device_id.clone(),
                data: AlertData{
                    message: message.to_string(),
                    value: current_value
                }
            });
        }

        state.is_currently_high = current_value >= threshold;
        None
    }

}
