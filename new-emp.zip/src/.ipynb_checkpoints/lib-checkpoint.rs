pub mod config;
pub mod telemetry;
pub mod docker_manager;
pub mod mqtt_client;
pub mod alerting;
pub mod types;
pub mod hwinfo;
pub mod utils;
use anyhow::{Context, Result};
use std::sync::Arc;
use std::time::Duration;
use tracing::{error, info};
pub mod reverse_ssh;

use config::Config;
use telemetry::TelemetryCollector;
use docker_manager::DockerManager;
use mqtt_client::MqttClient;
use alerting::AlertManager;
use bollard::auth::DockerCredentials;
use rumqttc::QoS;
use tokio::{
    task, time,
    sync::Mutex,
};

pub async fn run() -> Result<()> {
    // Initialize tracing
    tracing_subscriber::fmt()
        .with_env_filter(tracing_subscriber::EnvFilter::from_default_env())
        .init();

    info!("Starting Edge Controller monitoring bot...");

    // Load configuration
    let config_path = std::env::var("CONFIG_PATH").unwrap_or_else(|_| "config.toml".to_string());
    let config = Config::load(&config_path).await
        .context(format!("Failed to load configuration from {}", config_path))?;

    // Initialize components
    let telemetry_collector = TelemetryCollector::new()?;

    let store_credential = DockerCredentials {
        username: Some(config.docker.username.clone()),
        password: Some(config.docker.password.clone()),
        serveraddress: Some(config.docker.store_url.clone()),
        ..Default::default()
    };

    
    let docker_manager = if config.docker.enable_container_monitoring {
        let endpoint = config
            .docker
            .socket_path
            .as_str();
        println!("{:?}", endpoint);
        Some(Arc::new(Mutex::new(
            DockerManager::new_with_endpoint(endpoint, store_credential)?
        )))
    } else {
        None
    };
    
    let ssh_manager = Some(Arc::new(Mutex::new(crate::reverse_ssh::ReverseSsh::default())));

    let mqtt_client = Arc::new(
        MqttClient::new(
            &config.mqtt,
            docker_manager.clone(),
            config.ssh.local_ssh_port,
            ssh_manager.clone()
        ).await?
    );
    
    let mqtt_alert_client = mqtt_client.clone();
    let alert_manager = Arc::new(
        AlertManager::new(config.mqtt.client_id.clone(), mqtt_alert_client)
    );
    info!("All components initialized successfully");

    // Main monitoring loop
    let mut interval = time::interval(Duration::from_secs(config.monitoring.interval_seconds));

    loop {
        interval.tick().await;

        match run_monitoring_cycle(
            &telemetry_collector,
            mqtt_client.clone(),
            alert_manager.clone(),
            &config
        ).await {
            Ok(_) => {},
            Err(e) => {
                error!("Error in monitoring cycle: {:?}", e);
            }
        }
    }
}

async fn run_monitoring_cycle(
    telemetry: &TelemetryCollector,
    mqtt_client: Arc<MqttClient>,
    alert_manager: Arc<AlertManager>,
    config: &Config,
) -> Result<()> {
    let metrics = telemetry.collect(config.mqtt.client_id.clone()).await?;

    let mqtt_client_for_task = mqtt_client.clone();
    let metrics_for_task = metrics.clone();
    
    task::spawn(async move {
        let _ = mqtt_client_for_task
            .publish_telemetry(&metrics_for_task, QoS::AtMostOnce)
            .await;
    });
    

    let alert_manager_for_task = alert_manager.clone();
    let metrics_for_task2 = metrics.clone();
    
    task::spawn(async move {
        let _ = alert_manager_for_task
            .check_alerts(metrics_for_task2)
            .await;
    });
    
    Ok(())
}
