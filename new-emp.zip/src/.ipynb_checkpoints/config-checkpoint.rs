use serde::{Deserialize, Serialize};
use std::path::Path;
use tokio::fs;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Config {
    pub monitoring: MonitoringConfig,
    pub mqtt: MqttConfig,
    pub alerting: AlertingConfig,
    pub docker: DockerConfig,
    pub ssh: SSHConfig,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SSHConfig {
    pub local_ssh_ip: String,
    pub local_ssh_port: u16,
    pub hostname: String,
    pub user: String,
    pub mac: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MonitoringConfig {
    pub interval_seconds: u64,
    pub enable_gpu: bool,
    pub enable_power: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MqttConfig {
    pub broker_type: String,
    pub broker: String,
    pub port: u16,
    pub client_id: String,
    pub default_topic: String,
    pub telemetry_topic: String,
    pub log_topic: String,
    pub docker_info_topic: String,
    pub command_topic: String,
    pub operator_topic: String,
    pub ssh_topic: String,
    pub application_log_topic: String,
    pub ca_path: String,
    pub cert_path: String,
    pub key_path: String,
    pub qos: u8,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AlertingConfig {
    pub cpu_usage_threshold_percent: f32,
    pub gpu_usage_threshold_percent: f32,
    pub gpu_memory_threshold_percent: f32,
    pub memory_threshold_percent: f32,
    pub warning_temperature_threshold_percent: f32,
    pub throttled_temperature_threshold_percent: f32,
    pub warning_storage_capacity_threshold_percent: f32,
    pub full_storage_capacity_threshold_percent: f32,
    pub alert_cooldown_seconds: u64,
    pub sustained_alert_seconds: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DockerConfig {
    pub socket_path: String,
    pub enable_container_monitoring: bool,
    pub username: String,
    pub password: String,
    pub store_url: String,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            monitoring: MonitoringConfig {
                interval_seconds: 30,
                enable_gpu: true,
                enable_power: true,
            },
            mqtt: MqttConfig {
                broker_type: "mqtt".to_string(),
                broker: "localhost".to_string(),
                port: 1883,
                client_id: "edge-controller".to_string(),
                default_topic: "device".to_string(),
                telemetry_topic: "telemetry".to_string(),
                log_topic: "logs".to_string(),
                docker_info_topic: "docker-info".to_string(),
                command_topic: "applications".to_string(),
                operator_topic: "operator".to_string(),
                ssh_topic: "ssh".to_string(),
                application_log_topic: "application-logs".to_string(),
                ca_path: "".to_string(),
                cert_path: "".to_string(),
                key_path: "".to_string(),
                qos: 1,
            },
            alerting: AlertingConfig {
                cpu_usage_threshold_percent: 80.0,
                gpu_usage_threshold_percent: 90.0,
                gpu_memory_threshold_percent: 90.0,
                memory_threshold_percent: 85.0,
                warning_temperature_threshold_percent: 80.0,
                throttled_temperature_threshold_percent: 100.0,
                warning_storage_capacity_threshold_percent: 80.0,
                full_storage_capacity_threshold_percent: 95.0,
                alert_cooldown_seconds: 300, // 5 minutes
                sustained_alert_seconds: 60, // Alert after 60 seconds of sustained high usage
            },
            docker: DockerConfig {
                socket_path: "/var/run/docker.sock".to_string(),
                enable_container_monitoring: true,
                username: "".to_string(),
                password: "".to_string(),
                store_url: "".to_string(),
            },
            ssh: SSHConfig {
                local_ssh_ip: "localhost".to_string(),
                local_ssh_port: 22,
                hostname: "Ubuntu".to_string(),
                user: "".to_string(),
                mac: "".to_string(),
            },
        }
    }
}

impl Config {
    pub async fn load<P: AsRef<Path>>(path: P) -> anyhow::Result<Self> {
        let path = path.as_ref();

        if path.exists() {
            let contents = fs::read_to_string(path).await?;
            let config: Config = toml::from_str(&contents)?;
            Ok(config)
        } else {
            let config = Self::default();
            let toml_string = toml::to_string_pretty(&config)?;
            fs::write(path, toml_string).await?;
            tracing::info!("Created default configuration file at {:?}", path);
            Ok(config)
        }
    }
}
