use std::fs::File;
use std::io::{BufRead, BufReader, Seek, SeekFrom};
use regex::Regex;


#[derive(Debug)]
pub struct SSHLogWatcher {
    file: File,
    offset: u64,
    re_ip: Regex,
}

impl SSHLogWatcher {
    pub fn new() -> std::io::Result<Self> {
        let file = File::open("/var/log/auth.log")?;
        Ok(Self {
            file,
            offset: 0,
            re_ip: Regex::new(r"from ([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)").unwrap(),
        })
    }

    pub fn poll(&mut self) -> Vec<(String, Option<String>)> {
        let mut reader = BufReader::new(&self.file);
        let _ = reader.seek(SeekFrom::Start(self.offset));

        let mut events = vec![];
        let mut pos = self.offset;

        for line in reader.lines().flatten() {
            pos += line.len() as u64 + 1;

            if line.contains("Failed password")
                || line.contains("Failed publickey")
                || line.contains("Invalid user")
            {
                let ip = self.re_ip
                    .captures(&line)
                    .and_then(|c| c.get(1))
                    .map(|m| m.as_str().to_string());

                events.push((line, ip));
            }
        }

        self.offset = pos;
        events
    }
}
