use std::process::Command;
use std::path::Path;
use std::fs;

pub fn cmd_exists(cmd: &str) -> bool {
    Command::new(cmd)
        .arg("--help")
        .output()
        .is_ok()
}


#[derive(Debug, Clone, PartialEq, Eq)]
pub enum JetsonModel {
    Nano,
    TX2,
    XavierNX,
    AGXXavier,
    OrinNano,
    OrinNX,
    AGXOrin,
    Unknown(String),
}

impl JetsonModel {
    pub fn to_cpu_arch(&self) -> &str {
        match self {
            JetsonModel::Nano =>
                "Quad-core ARM Cortex-A57",
            JetsonModel::TX2 =>
                "Dual-core Denver 2 + Quad-core ARM Cortex-A57",
            JetsonModel::XavierNX =>
                "6-core NVIDIA Carmel ARMv8.2 64-bit",
            JetsonModel::AGXXavier =>
                "8-core NVIDIA Carmel ARMv8.2 64-bit",
            JetsonModel::OrinNano =>
                "6-core Arm Cortex-A78AE v8.2 64-bit",
            JetsonModel::OrinNX =>
                "8-core Arm Cortex-A78AE v8.2 64-bit",
            JetsonModel::AGXOrin =>
                "12-core Arm Cortex-A78AE v8.2 64-bit",
            JetsonModel::Unknown(model) =>
                model.as_str(),
        }
    }

    pub fn to_gpu_arch(&self) -> &str {
        match self {
            JetsonModel::Nano =>
                "Maxwell (SM 5.3)",
            JetsonModel::TX2 =>
                "Pascal (SM 6.2)",
            JetsonModel::XavierNX =>
                "Volta (SM 7.2)",
            JetsonModel::AGXXavier =>
                "Volta (SM 7.2)",
            JetsonModel::OrinNano =>
                "Ampere (SM 8.7)",
            JetsonModel::OrinNX =>
                "Ampere (SM 8.7)",
            JetsonModel::AGXOrin =>
                "Ampere (SM 8.7)",
            JetsonModel::Unknown(_) =>
                "Unknown GPU architecture",
        }
    }
}

pub fn is_jetson() -> bool {
    cmd_exists("tegrastats") &&
    Path::new("/proc/device-tree/model").exists() &&
    Path::new("/etc/nv_tegra_release").exists()
}

pub fn get_jetson_model() -> Option<JetsonModel> {
    if !is_jetson() {
        return None;
    }

    let model = fs::read_to_string("/proc/device-tree/model")
        .ok()?
        .to_lowercase();

    let jetson = if model.contains("nano") {
        JetsonModel::Nano
    } else if model.contains("tx2") {
        JetsonModel::TX2
    } else if model.contains("xavier nx") {
        JetsonModel::XavierNX
    } else if model.contains("agx xavier") {
        JetsonModel::AGXXavier
    } else if model.contains("orin nano") {
        JetsonModel::OrinNano
    } else if model.contains("orin nx") {
        JetsonModel::OrinNX
    } else if model.contains("agx orin") {
        JetsonModel::AGXOrin
    } else {
        JetsonModel::Unknown(model.trim().to_string())
    };

    Some(jetson)
}