use std::process::Command;
use std::path::Path;
use std::fs;

pub fn cmd_exists(cmd: &str) -> bool {
    Command::new(cmd)
        .arg("--help")
        .output()
        .is_ok()
}


#[derive(Debug, Clone, PartialEq, Eq)]
pub enum JetsonModel {
    Nano,
    TX2,
    XavierNX,
    AGXXavier,
    OrinNano,
    OrinNX,
    AGXOrin,
    Unknown(String),
}

impl JetsonModel {
    pub fn to_cpu_arch(&self) -> &str {
        match self {
            JetsonModel::Nano =>
                "Quad-core ARM Cortex-A57",
            JetsonModel::TX2 =>
                "Dual-core Denver 2 + Quad-core ARM Cortex-A57",
            JetsonModel::XavierNX =>
                "6-core NVIDIA Carmel ARMv8.2 64-bit",
            JetsonModel::AGXXavier =>
                "8-core NVIDIA Carmel ARMv8.2 64-bit",
            JetsonModel::OrinNano =>
                "6-core Arm Cortex-A78AE v8.2 64-bit",
            JetsonModel::OrinNX =>
                "8-core Arm Cortex-A78AE v8.2 64-bit",
            JetsonModel::AGXOrin =>
                "12-core Arm Cortex-A78AE v8.2 64-bit",
            JetsonModel::Unknown(model) =>
                model.as_str(),
        }
    }

    pub fn to_gpu_arch(&self) -> &str {
        match self {
            JetsonModel::Nano =>
                "Maxwell (SM 5.3)",
            JetsonModel::TX2 =>
                "Pascal (SM 6.2)",
            JetsonModel::XavierNX =>
                "Volta (SM 7.2)",
            JetsonModel::AGXXavier =>
                "Volta (SM 7.2)",
            JetsonModel::OrinNano =>
                "Ampere (SM 8.7)",
            JetsonModel::OrinNX =>
                "Ampere (SM 8.7)",
            JetsonModel::AGXOrin =>
                "Ampere (SM 8.7)",
            JetsonModel::Unknown(_) =>
                "Unknown GPU architecture",
        }
    }
}


fn normalize_model(s: &str) -> String {
    s.to_lowercase()
        .replace('_', " ")
        .replace('-', " ")
}


pub fn is_jetson() -> bool {
    cmd_exists("tegrastats") &&
    Path::new("/proc/device-tree/model").exists() &&
    Path::new("/etc/nv_tegra_release").exists()
}

fn detect_soc() -> Option<&'static str> {
    let c = std::fs::read_to_string("/proc/device-tree/compatible").ok()?.to_lowercase();

    if c.contains("tegra234") {
        Some("orin")
    } else if c.contains("tegra194") {
        Some("xavier")
    } else if c.contains("tegra186") {
        Some("tx2")
    } else if c.contains("tegra210") {
        Some("nano")
    } else {
        None
    }
}

pub fn get_jetson_model() -> Option<JetsonModel> {
    if !is_jetson() {
        return None;
    }

    let raw_model = fs::read_to_string("/proc/device-tree/model").ok()?;
    let m = normalize_model(&raw_model);


    let jetson = if m.contains("orin") {
        if m.contains("nano") {
            JetsonModel::OrinNano
        } else if m.contains("nx") {
            JetsonModel::OrinNX
        } else if m.contains("agx") {
            JetsonModel::AGXOrin
        } else {
            // ví dụ: "jetson orin"
            match detect_soc() {
                Some("orin") => JetsonModel::AGXOrin,
                _ => JetsonModel::Unknown(raw_model.trim().to_string()),
            }
        }

    } else if m.contains("xavier") {
        if m.contains("nx") {
            JetsonModel::XavierNX
        } else if m.contains("agx") {
            JetsonModel::AGXXavier
        } else {
            match detect_soc() {
                Some("xavier") => JetsonModel::AGXXavier,
                _ => JetsonModel::Unknown(raw_model.trim().to_string()),
            }
        }

    } else if m.contains("tx2") {
        JetsonModel::TX2

    } else if m.contains("nano") {
        JetsonModel::Nano

    // CASE CỰC KỲ QUAN TRỌNG:
    // model chỉ là "Jetson-AGX"
    } else if m.contains("agx") {
        match detect_soc() {
            Some("orin") => JetsonModel::AGXOrin,
            Some("xavier") => JetsonModel::AGXXavier,
            _ => JetsonModel::Unknown(raw_model.trim().to_string()),
        }

    } else {
        JetsonModel::Unknown(raw_model.trim().to_string())
    };

    Some(jetson)
}