use std::process::Command;
use std::path::Path;


pub fn cmd_exists(cmd: &str) -> bool {
    Command::new(cmd)
        .arg("--help")
        .output()
        .is_ok()
}


pub fn is_jetson() -> bool {
    cmd_exists("tegrastats") &&
    Path::new("/proc/device-tree/model").exists() &&
    Path::new("/etc/nv_tegra_release").exists()
}