use crate::docker_manager::DockerCommand;
use crate::reverse_ssh::SSHCommand;
use toml::Value;
use tracing::error;
use std::collections::HashMap;
use serde::Deserialize;


fn toml_to_json(v: &toml::Value) -> serde_json::Value {
    match v {
        toml::Value::String(s) => serde_json::Value::String(s.clone()),
        toml::Value::Integer(i) => serde_json::Value::Number((*i).into()),
        toml::Value::Float(f) => {
            serde_json::Number::from_f64(*f)
                .map(serde_json::Value::Number)
                .unwrap_or(serde_json::Value::Null)
        }
        toml::Value::Boolean(b) => serde_json::Value::Bool(*b),
        toml::Value::Array(arr) => serde_json::Value::Array(
            arr.iter().map(toml_to_json).collect()
        ),
        toml::Value::Table(table) => serde_json::Value::Object(
            table.iter()
                .map(|(k, v)| (k.clone(), toml_to_json(v)))
                .collect()
        ),
        toml::Value::Datetime(dt) => {
            serde_json::Value::String(dt.to_string())
        }
    }
}


pub async fn convert_message_docker(payload: &[u8]) -> Result<DockerCommand, serde_json::Error> {
    let message = serde_json::from_slice::<Value>(payload)?;

    let action_type = message["type"].as_str().unwrap_or("").to_string();

    let command = match action_type.as_str() {
        "RUN_APPLICATION" => {
            // let session_id = message["session_id"].as_str().unwrap_or("");
            
            let payload_list: Vec<Value> = match message.get("payload") {
                Some(v) => v.as_array().cloned().unwrap_or_default(),
                None => Vec::new(),
            };
            
            let payload = &payload_list[0];
            
            let id = payload
                .get("id")
                .and_then(|v| v.as_str())
                .unwrap_or("")
                .to_string();

            let env_obj = payload.get("envs").and_then(|v| v.as_table());
            
            let env_map: Option<HashMap<String, String>> = env_obj.map(|map| {
                map.iter()
                    .map(|(key, val)| {
                        let value = val
                            .as_str()
                            .map(|s| s.to_string())
                            .unwrap_or_else(|| val.to_string());
            
                        (key.clone(), value)
                    })
                    .collect::<HashMap<String, String>>()
            });
            
            let volume_list = payload
                .get("volumes")
                .map(toml_to_json);
            
            let ports_list = payload
                .get("ports")
                .map(toml_to_json);

            let image = payload
                .get("resource_name")
                .and_then(|v| v.as_str())
                .unwrap_or("")
                .to_string();
            
            let name = payload
                .get("container_name")
                .and_then(|v| v.as_str())
                .unwrap_or("")
                .to_string();
            
            DockerCommand::RunImageProgress {
                id,
                image,
                name: Some(name),
                envs: env_map,
                ports: ports_list,
                volumes: volume_list,
            }

        }
        "START_APPLICATION" => {
            let container_ids: Vec<Value> = match message.get("container_ids") {
                Some(v) => v.as_array().cloned().unwrap_or_default(),
                None => Vec::new(),
            };
            let container_id = container_ids[0]
                .as_str()
                .unwrap()
                .to_string();
            DockerCommand::Start { action_type: action_type.to_string(), container_id: container_id.to_string() }
        }
        "STOP_APPLICATION" => {
            let container_ids: Vec<Value> = match message.get("container_ids") {
                Some(v) => v.as_array().cloned().unwrap_or_default(),
                None => Vec::new(),
            };
            let container_id = container_ids[0]
                .as_str()
                .unwrap()
                .to_string();
            println!("{}", container_id);
            
            DockerCommand::Stop { action_type: action_type.to_string(),  container_id: container_id.to_string() }
        }
        "DELETE_APPLICATION" => {
            let container_ids: Vec<Value> = match message.get("container_ids") {
                Some(v) => v.as_array().cloned().unwrap_or_default(),
                None => Vec::new(),
            };
            let container_id = container_ids[0]
                .as_str()
                .unwrap()
                .to_string();
            DockerCommand::Delete { action_type: action_type.to_string(),  container_id: container_id.to_string(), force: true }
        }
        "RESTART_APPLICATION" => {
            let container_ids: Vec<Value> = match message.get("container_ids") {
                Some(v) => v.as_array().cloned().unwrap_or_default(),
                None => Vec::new(),
            };
            let container_id = container_ids[0]
                .as_str()
                .unwrap()
                .to_string();
            DockerCommand::Restart { action_type: action_type.to_string(),  container_id: container_id.to_string() }
        }
        "APPLICATION_LOGS" => {
            let stream_id = message
                .get("stream_id")
                .and_then(|v| v.as_str())
                .unwrap_or("")
                .to_string();
            
            let container_id = message
                .get("container_id")
                .and_then(|v| v.as_str())
                .unwrap_or("")
                .to_string();
            
            let flag = message
                .get("flag")
                .and_then(|v| v.as_bool())
                .unwrap_or(false);
            
            DockerCommand::GetLogs { stream_id: stream_id.to_string(), container_id: container_id.to_string(), flag }
        }
        "CONTAINER_LOGS" => {
            let stream_id = message
                .get("stream_id")
                .and_then(|v| v.as_str())
                .unwrap_or("")
                .to_string();
            
            let container_ids = match message.get("container_ids") {
                Some(v) => toml::Value::Array(v.as_array().cloned().unwrap_or_default()),
                None => toml::Value::Array(Vec::new()),
            };
            
            DockerCommand::GetContainers { stream_id: stream_id.to_string(), container_ids }
        }
        _ => {
            error!(
                "convert message fail, message_id {}",
                message["message_id"].as_str().unwrap_or("").to_string()
            );
            DockerCommand::Exception {
                error: message["message_id"].as_str().unwrap_or("").to_string()
            }
        }
    };
    Ok(command)

}


#[derive(Debug, Deserialize)]
#[serde(tag = "action")]
pub enum IncomingMessage {
    #[serde(rename = "OPEN_CONNECTION")]
    OpenConnection {
        message_id: String,
        port_available: u16,
        host: String,
        username: String,
        port: u16,
        password: String,
    },

    #[serde(rename = "CLOSE_CONNECTION")]
    CloseConnection {
        message_id: String,
    },
}

pub fn convert_message_ssh(
    payload: &[u8],
    local_ssh_port: u16,
) -> Result<SSHCommand, serde_json::Error> {
    let msg: IncomingMessage = serde_json::from_slice(payload)?;

    let cmd = match msg {
        IncomingMessage::OpenConnection {
            message_id,
            port_available,
            host,
            username,
            port,
            password,
            ..
        } => {
            tracing::info!(message_id=message_id,"Convert message ssh open connection");
            SSHCommand::StartWithPassword {
            vps_port: port_available,
            vps_host: host,
            vps_user: username,
            vps_ssh_port: port,
            local_ssh_port,
            password,
        }},

        IncomingMessage::CloseConnection { message_id, .. } => {
            tracing::info!(message_id=message_id,"Convert message ssh close connection");
            SSHCommand::Stop
        }
    };

    Ok(cmd)
}