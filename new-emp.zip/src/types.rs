use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use crate::hwinfo::get_cpu_info::CpuInfo;
use crate::hwinfo::gpu::gpu_model::GpuInfo;
use crate::hwinfo::get_memory_info::MemoryInfo;
use crate::hwinfo::get_disk_info::DiskInfo;
use crate::hwinfo::get_network_info::NetworkInfo;
use crate::hwinfo::get_power_info::PowerInfo;


#[derive(Debug, Clone, Serialize)]
pub struct MetricsInfo {
    pub cpu: Vec<CpuInfo>,
    pub gpu: Vec<GpuInfo>,
    pub memory: MemoryInfo,
    pub disk: Vec<DiskInfo>,
    pub network_metrics: Vec<NetworkInfo>,
    pub power: PowerInfo,
}

#[derive(Debug, Clone, Serialize)]
pub struct SystemMetrics {
    pub device_id: String,
    pub metrics: MetricsInfo,
    pub uptime: u64,
    pub timestamp: DateTime<Utc>,
}


#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct AlertData {
    pub message: String,
    pub value: f32,
}


#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ContainerStats {
    pub id: String,
    pub name: String,
    pub image: String,
    pub status: String,
    pub cpu_percent: f64,
    pub memory_usage: u64,
    pub memory_limit: u64,
    pub memory_percent: f64,
    pub network_rx: u64,
    pub network_tx: u64,
    pub block_read: u64,
    pub block_write: u64,
    pub timestamp: DateTime<Utc>,
}


#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SSHResponse {
    pub success: bool,
    pub message: String,
    pub data: Option<serde_json::Value>,
}


#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ApplicationLogResponse {
    pub stream_id: String,
    pub container_id: String,
    pub status: String,
    pub message: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ContainerLogs {
    pub stream_id: String,
    pub device_id: String,
    pub containers: Option<serde_json::Value>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SSHUnauthorizedMetric {
    pub attempts: u32,
    pub last_ip: Option<String>,
    pub reason: Option<String>,
}