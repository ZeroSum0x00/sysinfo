# Edge Controller - Technical Documentation

## Overview

Edge Controller is a comprehensive Rust-based monitoring and container management system designed for edge computing environments. It provides real-time system telemetry collection, Docker container management, and MQTT-based communication for distributed edge deployments.

## Architecture

### Core Components

#### 1. Telemetry Collector (`telemetry.rs`)
Responsible for collecting system metrics from the host machine.

**Key Features:**
- **CPU Monitoring**: Usage percentage, frequency, core information
- **Memory Monitoring**: Total, used, available memory with usage percentages
- **Disk Monitoring**: Per-disk usage statistics, I/O operations
- **Network Monitoring**: RX/TX bytes and packets across all interfaces
- **GPU Monitoring**: NVIDIA GPU utilization, memory, and temperature (optional)
- **Power Monitoring**: Battery consumption and voltage (optional)
- **I/O Monitoring**: Read/write operations and throughput

**Implementation:**
```rust
pub struct TelemetryCollector {
    // System information collectors
}

impl TelemetryCollector {
    pub fn new() -> Result<Self> {
        // Initialize system monitoring libraries
        Ok(Self { /* fields */ })
    }

    pub async fn collect_metrics(&self) -> Result<SystemMetrics> {
        // Collect all system metrics
        // Returns comprehensive system state
    }
}
```

#### 2. Docker Manager (`docker_manager.rs`)
Provides comprehensive Docker container lifecycle management with progress streaming.

**Key Features:**
- **Container Operations**: Start, stop, restart, delete containers
- **Image Management**: Pull, list, and run images
- **Progress Streaming**: Real-time progress updates for long-running operations
- **Container Statistics**: Detailed container metrics collection
- **Error Handling**: Comprehensive error reporting and recovery

**Core Structures:**
```rust
pub enum DockerCommand {
    Start { container_id: String },
    Stop { container_id: String },
    Restart { container_id: String },
    Delete { container_id: String, force: bool },
    RunImage { image: String, name: Option<String> },
    RunImageProgress { image: String, name: Option<String> },
    PullImage { image: String },
    PullImageProgress { image: String },
    ListContainers,
    ListImages,
    GetLogs { container_id: String, tail: Option<String> },
    GetInfo { container_id: String },
}

pub struct DockerResponse {
    pub success: bool,
    pub message: String,
    pub data: Option<serde_json::Value>,
}
```

**Progress Streaming:**
The system provides real-time progress updates for image operations:

- **Pull Progress**: `docker/pull/progress` topic
- **Run Progress**: `docker/run/progress` topic

```rust
// Progress message format
{
  "operation": "pull_image|run_image",
  "image": "nginx:latest",
  "phase": "pulling|completed",
  "status": "Pulling fs layer",
  "progress": "[===================>] 50MB/100MB",
  "timestamp": "2024-01-01T12:00:00Z"
}
```

#### 3. MQTT Client (`mqtt_client.rs`)
Handles all MQTT communication for telemetry publishing and command processing.

**Key Features:**
- **Multi-topic Publishing**: Telemetry, alerts, container stats
- **Command Subscription**: Real-time Docker management commands
- **QoS Support**: Configurable Quality of Service levels
- **Connection Management**: Automatic reconnection and error handling
- **Progress Streaming**: Publishes operation progress updates

**Topics:**
- **Publishing Topics:**
  - `telemetry/system`: System metrics
  - `telemetry/containers/{id}`: Container statistics
  - `alerts/system`: System alerts
  - `docker/pull/progress`: Image pull progress
  - `docker/run/progress`: Image run progress
  - `logs/edge-controller`: Application logs

- **Subscribing Topics:**
  - `commands/docker`: Docker management commands

**Message Formats:**
```rust
// System Metrics
{
  "timestamp": "2024-01-01T12:00:00Z",
  "cpu": { "usage_percent": 45.2, "frequency_mhz": 3200 },
  "memory": { "total_gb": 16.0, "used_gb": 8.5, "usage_percent": 53.1 },
  "disk": [{ "name": "/dev/sda1", "usage_percent": 30.0 }],
  "network": { "rx_bytes": 1024000, "tx_bytes": 512000 },
  "gpu": { "utilization_percent": 65 },
  "power": { "consumption_watts": 150.5 },
  "io": { "read_bytes": 1000000, "write_bytes": 500000 }
}

// Docker Commands
{
  "RunImageProgress": {
    "image": "nginx:latest",
    "name": "web-server"
  }
}

// Docker Response
{
  "success": true,
  "message": "Container abc123 started successfully",
  "data": { "container_id": "abc123" }
}
```

#### 4. Alert Manager (`alerting.rs`)
Monitors system metrics and triggers alerts based on configurable thresholds.

**Key Features:**
- **Threshold Monitoring**: CPU and memory usage alerts
- **Cooldown Periods**: Prevents alert spam
- **Sustained Alert Detection**: Alerts only after continuous high usage
- **State Management**: Tracks alert states and history

**Configuration:**
```rust
pub struct AlertingConfig {
    pub cpu_threshold_percent: f32,
    pub memory_threshold_percent: f32,
    pub alert_cooldown_seconds: u64,
    pub sustained_alert_seconds: u64,
}
```

#### 5. Configuration System (`config.rs`)
Centralized configuration management with TOML support.

**Configuration Structure:**
```rust
pub struct Config {
    pub monitoring: MonitoringConfig,
    pub mqtt: MqttConfig,
    pub alerting: AlertingConfig,
    pub docker: DockerConfig,
}
```

## API Reference

### TelemetryCollector

```rust
pub struct TelemetryCollector;

impl TelemetryCollector {
    pub fn new() -> Result<Self>;
    pub async fn collect_metrics(&self) -> Result<SystemMetrics>;
}
```

### DockerManager

```rust
pub struct DockerManager {
    docker: Docker,
}

impl DockerManager {
    pub async fn new() -> Result<Self>;
    pub async fn execute_command(&self, command: DockerCommand) -> DockerResponse;

    // Container operations
    pub async fn get_containers(&self) -> Result<Vec<ContainerSummary>>;
    pub async fn get_container_stats(&self) -> Result<Vec<ContainerStats>>;
    pub async fn start_container(&self, container_id: &str) -> Result<()>;
    pub async fn stop_container(&self, container_id: &str) -> Result<()>;
    pub async fn restart_container(&self, container_id: &str) -> Result<()>;
    pub async fn delete_container(&self, container_id: &str, force: bool) -> Result<()>;

    // Image operations
    pub async fn run_image(&self, image: &str, name: Option<&str>, config: Option<Config<String>>) -> Result<String>;
    pub async fn pull_image(&self, image: &str) -> Result<()>;
    pub fn pull_image_with_progress(&self, image: &str) -> impl Stream<Item = Result<CreateImageInfo>>;
    pub async fn pull_image_with_progress_updates(&self, image: &str, mqtt_client: Arc<Mutex<MqttClient>>);

    // Utility operations
    pub async fn list_images(&self) -> Result<Vec<ImageSummary>>;
    pub async fn logs_container(&self, container_id: &str, follow: bool, tail: Option<&str>) -> Result<Vec<String>>;
    pub async fn get_container_info(&self, container_id: &str) -> Result<ContainerInspectResponse>;
}
```

### MqttClient

```rust
pub struct MqttClient {
    client: AsyncClient,
    telemetry_topic: String,
    alert_topic: String,
    container_topic: String,
    command_topic: String,
    response_topic: String,
    qos: QoS,
    docker_manager: Option<Arc<Mutex<DockerManager>>>,
}

impl MqttClient {
    pub async fn new(config: &MqttConfig, docker_manager: Option<Arc<Mutex<DockerManager>>>) -> Result<Self>;
    pub async fn publish_telemetry(&self, metrics: &SystemMetrics) -> Result<()>;
    pub async fn publish_alert(&self, alert: &Alert) -> Result<()>;
    pub async fn publish_container_stats(&self, stats: &ContainerStats) -> Result<()>;
    pub async fn publish_log(&self, level: &str, message: &str) -> Result<()>;
    pub async fn publish_to_topic(&self, topic: &str, payload: String) -> Result<()>;
}
```

## Data Structures

### SystemMetrics

```rust
pub struct SystemMetrics {
    pub timestamp: DateTime<Utc>,
    pub cpu: CpuMetrics,
    pub memory: MemoryMetrics,
    pub disk: Vec<DiskMetrics>,
    pub network: NetworkMetrics,
    pub gpu: Option<GpuMetrics>,
    pub power: Option<PowerMetrics>,
    pub io: IoMetrics,
}

pub struct CpuMetrics {
    pub usage_percent: f32,
    pub frequency_mhz: u64,
}

pub struct MemoryMetrics {
    pub total_gb: f64,
    pub used_gb: f64,
    pub available_gb: f64,
    pub usage_percent: f32,
}

pub struct DiskMetrics {
    pub name: String,
    pub total_gb: f64,
    pub used_gb: f64,
    pub available_gb: f64,
    pub usage_percent: f32,
}

pub struct NetworkMetrics {
    pub rx_bytes: u64,
    pub tx_bytes: u64,
    pub rx_packets: u64,
    pub tx_packets: u64,
}

pub struct GpuMetrics {
    pub name: String,
    pub utilization_percent: u32,
    pub memory_used_mb: u32,
    pub memory_total_mb: u32,
    pub temperature_celsius: u32,
}

pub struct PowerMetrics {
    pub consumption_watts: f32,
    pub input_voltage: f32,
}

pub struct IoMetrics {
    pub read_bytes: u64,
    pub write_bytes: u64,
    pub read_operations: u64,
    pub write_operations: u64,
}
```

### ContainerStats

```rust
pub struct ContainerStats {
    pub id: String,
    pub name: String,
    pub image: String,
    pub status: String,
    pub cpu_percent: f32,
    pub memory_usage: u64,
    pub memory_limit: u64,
    pub memory_percent: f32,
    pub network_rx: u64,
    pub network_tx: u64,
    pub block_read: u64,
    pub block_write: u64,
    pub timestamp: DateTime<Utc>,
}
```

### Alert System

```rust
pub enum AlertType {
    CpuUsage,
    MemoryUsage,
}

pub struct Alert {
    pub alert_type: AlertType,
    pub message: String,
    pub value: f32,
    pub threshold: f32,
    pub timestamp: DateTime<Utc>,
}

pub struct AlertState {
    pub last_triggered: Option<DateTime<Utc>>,
    pub is_active: bool,
    pub consecutive_high_count: u32,
}
```

## Configuration

### Environment Variables

- `CONFIG_PATH`: Path to configuration file (default: "config.toml")

### Configuration File Format (TOML)

```toml
[monitoring]
interval_seconds = 30
enable_gpu = true
enable_power = true

[mqtt]
broker = "localhost"
port = 1883
client_id = "edge-controller"
telemetry_topic = "telemetry/system"
alert_topic = "alerts/system"
container_topic = "telemetry/containers"
command_topic = "commands/docker"
response_topic = "responses/docker"
qos = 1

[alerting]
cpu_threshold_percent = 80.0
memory_threshold_percent = 85.0
alert_cooldown_seconds = 300
sustained_alert_seconds = 60

[docker]
socket_path = "/var/run/docker.sock"
enable_container_monitoring = true
```

## Usage Examples

### Basic Monitoring

```rust
use edge_controller::*;

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let config = Config::load("config.toml").await?;
    let telemetry = TelemetryCollector::new()?;
    let metrics = telemetry.collect_metrics().await?;

    println!("CPU Usage: {:.1}%", metrics.cpu.usage_percent);
    println!("Memory Usage: {:.1}%", metrics.memory.usage_percent);

    Ok(())
}
```

### Docker Management

```rust
use edge_controller::docker_manager::{DockerManager, DockerCommand};

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let docker = DockerManager::new().await?;

    // List containers
    let containers = docker.get_containers().await?;
    println!("Found {} containers", containers.len());

    // Start a container
    docker.start_container("my-container").await?;

    // Run an image
    let container_id = docker.run_image("nginx:latest", Some("web-server"), None).await?;
    println!("Started container: {}", container_id);

    Ok(())
}
```

### MQTT Integration

```rust
use edge_controller::mqtt_client::MqttClient;

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let config = Config::load("config.toml").await?;
    let mqtt = MqttClient::new(&config.mqtt, None).await?;

    // Publish telemetry
    let telemetry = TelemetryCollector::new()?;
    let metrics = telemetry.collect_metrics().await?;
    mqtt.publish_telemetry(&metrics).await?;

    Ok(())
}
```

## Development Guide

### Building

```bash
# Debug build
cargo build

# Release build
cargo build --release

# Run tests
cargo test

# Run with logging
RUST_LOG=debug cargo run
```

### Dependencies

**Core Dependencies:**
- `tokio`: Async runtime
- `bollard`: Docker API client
- `rumqttc`: MQTT client
- `sysinfo`: System information
- `serde`: Serialization
- `chrono`: Date/time handling

**Optional Dependencies:**
- `nvml-wrapper`: NVIDIA GPU monitoring
- `battery`: Power consumption monitoring

### Error Handling

The application uses `anyhow::Result` for comprehensive error handling:

```rust
use anyhow::{Result, Context};

pub async fn some_operation(&self) -> Result<String> {
    let result = some_fallible_operation()
        .context("Failed to perform operation")?;

    Ok(result)
}
```

### Logging

Uses `tracing` for structured logging:

```rust
use tracing::{info, warn, error, debug};

info!("Starting edge controller");
debug!("Processing command: {:?}", command);
error!("Failed to connect: {}", error);
```

### Testing

```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn test_telemetry_collection() {
        let telemetry = TelemetryCollector::new().unwrap();
        let metrics = telemetry.collect_metrics().await.unwrap();

        assert!(metrics.cpu.usage_percent >= 0.0);
        assert!(metrics.memory.total_gb > 0.0);
    }
}
```

## Troubleshooting

### Common Issues

#### 1. Docker Socket Access
**Problem:** Permission denied when accessing Docker socket
**Solution:**
```bash
# Add user to docker group
sudo usermod -aG docker $USER

# Or run with sudo
sudo CONFIG_PATH=config.local.toml cargo run
```

#### 2. MQTT Connection Issues
**Problem:** Cannot connect to MQTT broker
**Solution:**
```bash
# Check if Mosquitto is running
ps aux | grep mosquitto

# Test connection
mosquitto_pub -h localhost -t "test" -m "hello"
```

#### 3. GPU Monitoring Not Working
**Problem:** GPU metrics not available
**Solution:**
- Ensure NVIDIA drivers are installed
- Install nvml library
- Check GPU is accessible: `nvidia-smi`

#### 4. High CPU Usage
**Problem:** Application consumes too much CPU
**Solution:**
- Increase monitoring interval in config
- Reduce logging verbosity
- Run in release mode: `cargo build --release`

### Debug Mode

Enable detailed logging:

```bash
RUST_LOG=debug CONFIG_PATH=config.local.toml cargo run
```

### Performance Monitoring

Monitor application performance:

```bash
# System resource usage
top -p $(pgrep edge-controller)

# MQTT message rate
mosquitto_sub -h localhost -t "telemetry/system" -C 10 | wc -l

# Docker operations
docker stats
```

## Deployment

### Docker Compose (Recommended)

```yaml
services:
  edge-controller:
    build: .
    privileged: true
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock
      - ./config.toml:/etc/edge-controller/config.toml:ro
    environment:
      - RUST_LOG=info
    network_mode: host
    depends_on:
      - mosquitto

  mosquitto:
    image: eclipse-mosquitto:2.0
    network_mode: host
    command: mosquitto -c /mosquitto-no-auth.conf
```

### Manual Deployment

```bash
# Build
cargo build --release

# Run
CONFIG_PATH=config.local.toml ./target/release/edge-controller

# Or as systemd service
sudo cp target/release/edge-controller /usr/local/bin/
sudo cp edge-controller.service /etc/systemd/system/
sudo systemctl enable edge-controller
sudo systemctl start edge-controller
```

## Security Considerations

### Docker Socket Access
- Only grant privileged access when necessary
- Consider using Docker API over TCP with TLS
- Limit container capabilities

### MQTT Security
- Use authentication for production deployments
- Enable TLS encryption
- Restrict topic access with ACLs

### Configuration Security
- Store sensitive configuration securely
- Use environment variables for secrets
- Rotate credentials regularly

## Contributing

### Code Style
- Follow Rust formatting: `cargo fmt`
- Run clippy: `cargo clippy`
- Write tests for new features

### Pull Request Process
1. Fork the repository
2. Create a feature branch
3. Make changes with tests
4. Ensure CI passes
5. Submit pull request

### Release Process
1. Update version in `Cargo.toml`
2. Update changelog
3. Create git tag
4. Publish to crates.io (if applicable)

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support and questions:
- Check the troubleshooting section
- Review existing issues on GitHub
- Create new issues for bugs/features
- Check logs with `RUST_LOG=debug`
