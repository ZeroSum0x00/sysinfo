use crate::common::{PowerMonitor, PowerReading, PowerSource, MonitorConfig};
use anyhow::{Result, anyhow};
use async_trait::async_trait;
use std::fs;
use tokio::time::Duration;

pub struct CpuEstimateMonitor {
    config: MonitorConfig,
    last_idle: u64,
    last_total: u64,
    sample_count: usize,
}

impl CpuEstimateMonitor {
    pub async fn new(config: MonitorConfig) -> Result<Self> {
        let (idle, total) = Self::read_cpu_stat()?;

        let mut monitor = Self {
            config,
            last_idle: idle,
            last_total: total,
            sample_count: 0,
        };

        // Perform initial sampling to establish baseline
        tokio::time::sleep(Duration::from_secs(1)).await;
        let _ = monitor.read_power().await;

        Ok(monitor)
    }

    fn read_cpu_stat() -> Result<(u64, u64)> {
        let content = fs::read_to_string("/proc/stat")?;
        let line = content
            .lines()
            .next()
            .ok_or_else(|| anyhow!("Empty /proc/stat"))?;

        // Parse: cpu  user nice system idle iowait irq softirq ...
        let parts: Vec<&str> = line.split_whitespace().collect();
        if parts.is_empty() || parts[0] != "cpu" {
            return Err(anyhow!("Invalid /proc/stat format"));
        }

        if parts.len() < 5 {
            return Err(anyhow!("/proc/stat has insufficient fields"));
        }

        let _user: u64 = parts[1].parse()?;
        let _nice: u64 = parts[2].parse()?;
        let _system: u64 = parts[3].parse()?;
        let idle: u64 = parts[4].parse()?;

        // Total is sum of all fields after "cpu"
        let mut total = 0u64;
        for i in 1..parts.len() {
            total = total.saturating_add(parts[i].parse::<u64>()?);
        }

        Ok((idle, total))
    }

    fn calculate_usage(&self, new_idle: u64, new_total: u64) -> Result<f64> {
        let idle_delta = new_idle.saturating_sub(self.last_idle);
        let total_delta = new_total.saturating_sub(self.last_total);

        if total_delta == 0 {
            return Err(anyhow!("No CPU stat change"));
        }

        let usage = 1.0 - (idle_delta as f64 / total_delta as f64);
        Ok(usage.max(0.0).min(1.0)) // Clamp to [0, 1]
    }
}

#[async_trait]
impl PowerMonitor for CpuEstimateMonitor {
    async fn read_power(&mut self) -> Result<PowerReading> {
        let (new_idle, new_total) = Self::read_cpu_stat()?;

        let usage = self.calculate_usage(new_idle, new_total)?;

        self.last_idle = new_idle;
        self.last_total = new_total;
        self.sample_count += 1;

        // Linear interpolation between idle and max power
        let power_watts = self.config.idle_power_w
            + usage * (self.config.max_power_w - self.config.idle_power_w);

        // Confidence decreases with fewer samples (ramp up over time)
        let confidence = 0.4 + (self.sample_count.min(20) as f32 / 20.0) * 0.2;

        Ok(PowerReading {
            power_watts,
            source: PowerSource::CpuEstimate,
            confidence: confidence.min(0.6),
            timestamp: std::time::Instant::now(),
        })
    }

    async fn shutdown(&mut self) -> Result<()> {
        Ok(())
    }
}
