use serde::Serialize;
use std::time::Instant;
use anyhow::Result;
use async_trait::async_trait;

#[derive(Debug, Clone, Serialize)]
pub struct PowerReading {
    pub power_watts: f64,
    pub source: PowerSource,
    pub confidence: f32,
    #[serde(skip)]
    pub timestamp: Instant,
}

#[derive(Debug, Clone, Serialize)]
pub enum PowerSource {
    Tegrastats,
    RaplSensor,
    InaSensor,
    CpuEstimate,
}

impl std::fmt::Display for PowerSource {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            PowerSource::Tegrastats => write!(f, "tegrastats"),
            PowerSource::RaplSensor => write!(f, "rapl"),
            PowerSource::InaSensor => write!(f, "ina"),
            PowerSource::CpuEstimate => write!(f, "cpu_estimate"),
        }
    }
}

#[derive(Debug, Clone)]
pub struct MonitorConfig {
    pub report_interval_secs: u64,
    pub idle_power_w: f64,
    pub max_power_w: f64,
    pub cpu_tdp: f64,
    pub tegrastats_restart_on_failure: bool,
    pub tegrastats_restart_delay_secs: u64,
}

impl Default for MonitorConfig {
    fn default() -> Self {
        Self {
            report_interval_secs: 5,
            idle_power_w: 5.0,
            max_power_w: 45.0,
            cpu_tdp: 65.0,
            tegrastats_restart_on_failure: true,
            tegrastats_restart_delay_secs: 5,
        }
    }
}

#[async_trait]
pub trait PowerMonitor: Send + Sync {
    async fn read_power(&mut self) -> Result<PowerReading>;
    async fn shutdown(&mut self) -> Result<()>;
}
