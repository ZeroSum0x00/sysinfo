pub mod common;
pub mod tegrastats;
pub mod rapl;
pub mod cpu_estimate;
use anyhow::{Result, Context};

use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use serde::{Deserialize, Serialize};
use std::path::Path;
use tokio::time::{interval, Duration};
use tracing::{info, warn, error};


use crate::common::{PowerReading, PowerSource, MonitorConfig, PowerMonitor};
use crate::tegrastats::TegrastatsMonitor;
use crate::rapl::RaplMonitor;
use crate::cpu_estimate::CpuEstimateMonitor;


#[derive(Debug, Serialize, Deserialize, Clone)]
struct ConfigFile {
    #[serde(default)]
    monitor: MonitorSection,
    #[serde(default)]
    power_estimates: PowerEstimatesSection,
    #[serde(default)]
    tegrastats: TegrastatsSection,
}

#[derive(Debug, Serialize, Deserialize, Clone, Default)]
struct MonitorSection {
    #[serde(default = "default_report_interval")]
    report_interval_secs: u64,
    #[serde(default)]
    enable_debug_logging: bool,
}

fn default_report_interval() -> u64 {
    5
}

#[derive(Debug, Serialize, Deserialize, Clone, Default)]
struct PowerEstimatesSection {
    #[serde(default = "default_idle_watts")]
    idle_watts: f64,
    #[serde(default = "default_max_watts")]
    max_watts: f64,
    #[serde(default = "default_cpu_tdp")]
    cpu_tdp: f64,
}

fn default_idle_watts() -> f64 {
    5.0
}

fn default_max_watts() -> f64 {
    45.0
}

fn default_cpu_tdp() -> f64 {
    65.0
}

#[derive(Debug, Serialize, Deserialize, Clone, Default)]
struct TegrastatsSection {
    #[serde(default)]
    restart_on_failure: bool,
    #[serde(default = "default_restart_delay")]
    restart_delay_secs: u64,
}

fn default_restart_delay() -> u64 {
    5
}

impl Default for ConfigFile {
    fn default() -> Self {
        Self {
            monitor: MonitorSection::default(),
            power_estimates: PowerEstimatesSection::default(),
            tegrastats: TegrastatsSection::default(),
        }
    }
}

fn load_config() -> Result<ConfigFile> {
    let config_path = "power_monitor.toml";

    if Path::new(config_path).exists() {
        let content = std::fs::read_to_string(config_path)
            .context("Failed to read power_monitor.toml")?;
        let config: ConfigFile = toml::from_str(&content)
            .context("Failed to parse power_monitor.toml")?;
        Ok(config)
    } else {
        Ok(ConfigFile::default())
    }
}

fn init_tracing(debug: bool) {
    let env_filter = if debug {
        tracing_subscriber::EnvFilter::new("debug")
    } else {
        tracing_subscriber::EnvFilter::new("info")
    };

    tracing_subscriber::fmt()
        .with_env_filter(env_filter)
        .with_target(false)
        .with_thread_ids(false)
        .init();
}

fn is_jetson() -> bool {
    std::process::Command::new("tegrastats")
        .arg("--help")
        .output()
        .is_ok()
}

#[tokio::main]
async fn main() -> Result<()> {
    // Load configuration
    let debug = true;

    // Initialize logging
    init_tracing(debug);

    info!("Starting unified power monitor");

    // Setup signal handler for graceful shutdown
    let shutdown = Arc::new(AtomicBool::new(false));
    let shutdown_clone = shutdown.clone();

    tokio::spawn(async move {
        let _ = tokio::signal::ctrl_c().await;
        info!("Shutdown signal received");
        shutdown_clone.store(true, Ordering::Relaxed);
    });

    // Build monitor config
    let monitor_config = MonitorConfig {
        report_interval_secs: 5,
        idle_power_w: 5.0,
        max_power_w: 45.0,
        cpu_tdp: 65.0,
        tegrastats_restart_on_failure: true,
        tegrastats_restart_delay_secs: 5,
    };

    // Select and create appropriate monitor
    let monitor: Box<dyn PowerMonitor> = if is_jetson() {
        info!("Platform: Jetson (tegrastats available)");
        match TegrastatsMonitor::new(monitor_config.clone()).await {
            Ok(m) => Box::new(m),
            Err(e) => {
                error!("Failed to initialize TegrastatsMonitor: {}", e);
                return Err(e);
            }
        }
    } else {
        info!("Platform: PC/Server");

        // Try RAPL first
        match RaplMonitor::new(monitor_config.clone()).await {
            Ok(m) => {
                info!("Using RAPL power sensor");
                Box::new(m)
            }
            Err(e) => {
                warn!("RAPL not available: {}, falling back to CPU estimation", e);

                // Fallback to CPU estimation
                match CpuEstimateMonitor::new(monitor_config.clone()).await {
                    Ok(m) => {
                        info!("Using CPU usage estimation for power");
                        Box::new(m)
                    }
                    Err(e) => {
                        error!("Failed to initialize CPU estimator: {}", e);
                        return Err(e);
                    }
                }
            }
        }
    };

    let mut monitor = monitor;
    let mut read_interval = interval(Duration::from_secs(
        5,
    ));

    // Main monitoring loop
    info!(
        "Starting monitoring loop | interval={}s",
        5
    );

    while !shutdown.load(Ordering::Relaxed) {
        read_interval.tick().await;

        match monitor.read_power().await {
            Ok(reading) => {
                info!(
                    "Power: {:.2}W | source={} | confidence={:.2}",
                    reading.power_watts, reading.source, reading.confidence
                );
            }
            Err(e) => {
                warn!("Failed to read power: {}", e);
            }
        }
    }

    // Graceful shutdown
    info!("Shutting down");
    monitor.shutdown().await?;

    Ok(())
}
