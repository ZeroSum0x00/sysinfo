use crate::common::{PowerMonitor, PowerReading, PowerSource, MonitorConfig};
use anyhow::{Result, anyhow};
use async_trait::async_trait;
use regex::Regex;
use std::sync::Arc;
use tokio::process::Command;
use tokio::io::{AsyncBufReadExt, BufReader};
use tokio::sync::Mutex;
use std::time::Instant;

pub struct TegrastatsMonitor {
    #[allow(dead_code)]
    config: MonitorConfig,
    regex: Regex,
}

impl TegrastatsMonitor {
    pub async fn new(config: MonitorConfig) -> Result<Self> {
        // Test if tegrastats is available
        let output = Command::new("tegrastats")
            .arg("--help")
            .output()
            .await;

        if output.is_err() {
            return Err(anyhow!("tegrastats command not found"));
        }

        // Compile regex pattern to find power values
        let regex = Regex::new(r"(\d+)mW/")?;

        Ok(Self {
            config,
            regex,
        })
    }
}

#[async_trait]
impl PowerMonitor for TegrastatsMonitor {
    async fn read_power(&mut self) -> Result<PowerReading> {
        let config = self.config.clone();
        let regex = self.regex.clone();

        // Spawn tegrastats process with output capture
        let mut child = Command::new("tegrastats")
            .arg("--interval")
            .arg("500")
            .stdout(std::process::Stdio::piped())
            .stderr(std::process::Stdio::piped())
            .spawn()?;

        let stdout = child.stdout.take().ok_or_else(|| anyhow!("Failed to get stdout"))?;
        let power = Arc::new(Mutex::new(None));

        let power_clone = power.clone();
        tokio::spawn(async move {
            let reader = BufReader::new(stdout);
            let mut lines = reader.lines();

            while let Ok(Some(line)) = lines.next_line().await {
                // Parse power from this line
                let mut total_mw = 0.0;
                let mut found = false;

                for cap in regex.captures_iter(&line) {
                    if let Ok(mw) = cap[1].parse::<f64>() {
                        total_mw += mw;
                        found = true;
                    }
                }

                if found {
                    let power_w = total_mw / 1000.0;
                    *power_clone.lock().await = Some(power_w);
                    // Return after first successful read
                    return;
                }
            }
        });

        // Read stderr in separate task to prevent deadlock
        let stderr = child.stderr.take();
        if let Some(err) = stderr {
            tokio::spawn(async move {
                let reader = BufReader::new(err);
                let mut _lines = reader.lines();
                // Just drain stderr to prevent deadlock
                while let Ok(Some(_)) = _lines.next_line().await {
                    // Ignore stderr output
                }
            });
        }

        // Wait for first power reading with timeout
        let start = tokio::time::Instant::now();
        let timeout = tokio::time::Duration::from_secs(3);

        loop {
            if let Some(power_w) = *power.lock().await {
                let now = Instant::now();
                return Ok(PowerReading {
                    power_watts: power_w,
                    source: PowerSource::Tegrastats,
                    confidence: 0.95,
                    timestamp: now,
                });
            }

            if start.elapsed() > timeout {
                // Kill the child process if we timeout
                let _ = child.kill().await;
                return Err(anyhow!("Timeout waiting for tegrastats output"));
            }

            tokio::time::sleep(tokio::time::Duration::from_millis(100)).await;
        }
    }

    async fn shutdown(&mut self) -> Result<()> {
        Ok(())
    }
}
