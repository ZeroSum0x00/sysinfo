use crate::common::{PowerMonitor, PowerReading, PowerSource, MonitorConfig};
use anyhow::{Result, anyhow};
use async_trait::async_trait;
use std::fs;
use std::path::{Path, PathBuf};
use std::time::Instant;
use tokio::time::Duration;

pub struct RaplMonitor {
    #[allow(dead_code)]
    config: MonitorConfig,
    paths: Vec<PathBuf>,
    last_energy: f64,
    last_time: Instant,
}

impl RaplMonitor {
    pub async fn new(config: MonitorConfig) -> Result<Self> {
        let base = Path::new("/sys/class/powercap");
        if !base.exists() {
            return Err(anyhow!("RAPL not available: /sys/class/powercap not found"));
        }

        let mut paths = Vec::new();

        for e in fs::read_dir(base)? {
            let p = e?.path();
            let name = p.file_name().ok_or_else(|| anyhow!("Invalid filename"))?;

            if name.to_string_lossy().contains("rapl") {
                let energy = p.join("energy_uj");
                if energy.exists() {
                    paths.push(energy);
                }
            }
        }

        if paths.is_empty() {
            return Err(anyhow!("No RAPL energy files found"));
        }

        let mut monitor = Self {
            config,
            paths,
            last_energy: 0.0,
            last_time: Instant::now(),
        };

        // Initialize with first reading
        monitor.last_energy = monitor.read_total_energy()?;
        monitor.last_time = Instant::now();

        // Sleep to allow energy accumulation
        tokio::time::sleep(Duration::from_secs(2)).await;

        Ok(monitor)
    }

    fn read_total_energy(&self) -> Result<f64> {
        let mut total = 0.0;

        for path in &self.paths {
            let content = fs::read_to_string(path)?;
            let energy: f64 = content.trim().parse()?;
            total += energy;
        }

        Ok(total)
    }
}

#[async_trait]
impl PowerMonitor for RaplMonitor {
    async fn read_power(&mut self) -> Result<PowerReading> {
        let now = Instant::now();
        let energy = self.read_total_energy()?;

        let dt = now.duration_since(self.last_time).as_secs_f64();

        if dt <= 0.0 {
            return Err(anyhow!("Invalid time delta"));
        }

        // Convert from µJ to J, then divide by time to get watts
        let power_watts = (energy - self.last_energy) / 1_000_000.0 / dt;

        // Handle wraparound - if power is negative, RAPL counter may have reset
        if power_watts < 0.0 {
            self.last_energy = energy;
            self.last_time = now;
            return Err(anyhow!("RAPL counter reset detected"));
        }

        self.last_energy = energy;
        self.last_time = now;

        Ok(PowerReading {
            power_watts,
            source: PowerSource::RaplSensor,
            confidence: 0.85,
            timestamp: now,
        })
    }

    async fn shutdown(&mut self) -> Result<()> {
        Ok(())
    }
}
