use serde_json::{Value, json};
use std::collections::HashMap;

use futures_util::stream::StreamExt;
use tokio::sync::mpsc;

use bollard::auth::DockerCredentials;
use bollard::models::{
    ContainerCreateBody,
    HostConfig,
    PortBinding,
    CreateImageInfo,
};
use bollard::query_parameters::{
    CreateImageOptionsBuilder,
    ListImagesOptionsBuilder,
};

use crate::docker_controller::docker_mount::DockerExecutor;
use crate::docker_controller::container_controller::{
    create_container,
    start_container,
    inspect_container_status,
    stop_container,
    delete_container,
};


/// =======================
/// LIST IMAGES
/// =======================
pub async fn list_images(
    docker: &DockerExecutor,
) -> Result<Vec<Value>, Box<dyn std::error::Error + Send + Sync>> {

    let images = docker.exec(|docker| async move {
        let options = ListImagesOptionsBuilder::default()
            .all(true)
            .build();

        let images = docker
            .list_images(Some(options))
            .await
            .map_err(|e| e.to_string())?;

        let mapped = images
            .into_iter()
            .map(|img| {
                json!({
                    "id": img.id,
                    "tags": img.repo_tags,
                    "digests": img.repo_digests,
                    "created": img.created,
                    "size": img.size,
                    "virtual_size": img.virtual_size,
                    "shared_size": img.shared_size,
                    "labels": img.labels,
                    "containers": img.containers,
                    "parent_id": img.parent_id,
                })
            })
            .collect();

        Ok(mapped)
    }).await?;

    Ok(images)
}


/// =======================
/// PULL IMAGE (STREAM)
/// =======================
pub async fn pull_image(
    docker: &DockerExecutor,
    credential: DockerCredentials,
    image: String,
) -> mpsc::Receiver<CreateImageInfo> {

    let (tx, rx) = mpsc::channel(32);

    let docker = docker.clone();
    let credential = credential.clone();
    let image = image.clone();

    tokio::spawn(async move {
        let _ = docker.exec(|docker| async move {
            let options = CreateImageOptionsBuilder::default()
                .from_image(&image)
                .build();

            let mut stream = docker.create_image(
                Some(options),
                None,
                Some(credential),
            );

            while let Some(msg) = stream.next().await {
                if let Ok(info) = msg {
                    let _ = tx.send(info).await;
                }
            }

            Ok(())
        }).await;
    });

    rx
}


/// =======================
/// RUN IMAGE (DEPLOY FLOW)
/// =======================
pub async fn run_image(
    docker: &DockerExecutor,
    container_name: String,
    resource_name: String,
    old_container_id: String,
    envs: Option<HashMap<String, String>>,
    ports: Option<&Vec<Value>>,
    volumes: Option<&Vec<Value>>,
) -> Result<HashMap<String, String>, Box<dyn std::error::Error + Send + Sync>> {

    // -------- ENV --------
    let env_vars: Option<Vec<String>> = envs.map(|map| {
        map.into_iter()
            .map(|(k, v)| format!("{}={}", k, v))
            .collect()
    });

    // -------- PORTS --------
    let mut exposed_ports: HashMap<String, HashMap<(), ()>> = HashMap::new();
    let mut port_bindings: HashMap<String, Option<Vec<PortBinding>>> = HashMap::new();

    if let Some(port_list) = ports {
        for port_value in port_list {
            if let Some(port_str) = port_value.as_str() {
                let parts: Vec<&str> = port_str.split(':').collect();
                let (host_port, container_port) = match parts.as_slice() {
                    [host, container] => (*host, *container),
                    [single]          => (*single, *single),
                    _                 => continue,
                };

                let container_key = format!("{}/tcp", container_port);

                exposed_ports.insert(container_key.clone(), HashMap::new());
                port_bindings.insert(
                    container_key.clone(),
                    Some(vec![PortBinding {
                        host_ip: Some("0.0.0.0".to_string()),
                        host_port: Some(host_port.to_string()),
                    }]),
                );
            }
        }
    }

    // -------- VOLUMES --------
    let mut binds: Vec<String> = vec![];

    if let Some(vol_list) = volumes {
        for v in vol_list {
            if let Some(v_str) = v.as_str() {
                let trimmed = v_str.trim();
                if trimmed.is_empty() {
                    continue;
                }

                if !trimmed.contains(':') {
                    return Err(format!(
                        "Invalid volume '{}': must contain ':'",
                        trimmed
                    ).into());
                }

                let parts: Vec<&str> = trimmed.split(':').collect();
                if parts.len() < 2 || parts[0].is_empty() || parts[1].is_empty() {
                    return Err(format!(
                        "Invalid volume '{}': missing host or container path",
                        trimmed
                    ).into());
                }

                binds.push(trimmed.to_string());
            }
        }
    }

    // -------- CONFIG --------
    let config = ContainerCreateBody {
        image: Some(resource_name.clone()),
        env: env_vars,
        exposed_ports: if exposed_ports.is_empty() { None } else { Some(exposed_ports) },
        host_config: Some(HostConfig {
            port_bindings: if port_bindings.is_empty() { None } else { Some(port_bindings) },
            binds: if binds.is_empty() { None } else { Some(binds) },
            ..Default::default()
        }),
        ..Default::default()
    };

    // -------- OLD CONTAINER --------
    if !old_container_id.is_empty() {
        let status = inspect_container_status(docker, &old_container_id).await?;
        if status == "running" {
            stop_container(docker, &old_container_id).await?;
        }
    }

    // -------- CREATE & START --------
    let new_container_id =
        create_container(docker, container_name, config).await?;

    start_container(docker, &new_container_id).await?;

    // -------- CLEANUP --------
    if !old_container_id.is_empty() {
        let status = inspect_container_status(docker, &new_container_id).await?;
        if status != "running" {
            start_container(docker, &old_container_id).await?;
        } else {
            delete_container(docker, &old_container_id).await?;
        }
    }

    Ok(HashMap::from([
        ("status".to_string(), "running".to_string()),
        ("current_id".to_string(), new_container_id),
    ]))
}
