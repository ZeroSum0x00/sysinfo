use bollard::Docker;
use bollard::container::{
    ListContainersOptions,
    InspectContainerOptions,
    RestartContainerOptions,
};
use serde_json::json;
use std::collections::HashMap;
use tracing::{info, warn, error};

use crate::mqtt_service::mqtt_handler::MqttHandler;
use tokio::sync::Mutex;
use std::sync::Arc;

pub struct DockerWatchdogConfig {
    pub mqtt: Arc<Mutex<MqttHandler>>,
    pub device_id: String,
    pub topic_pub_logs: String,
    pub qos: i32,
}

pub async fn docker_watchdog(
    docker: &Docker,
    config: &DockerWatchdogConfig,
) {
    let options = ListContainersOptions::<String> {
        all: true,
        ..Default::default()
    };

    let containers = match docker.list_containers(Some(options)).await {
        Ok(c) => c,
        Err(e) => {
            error!("Watchdog: failed to list containers: {}", e);
            return;
        }
    };

    for container in containers {
        let id = match container.id {
            Some(ref id) => id.clone(),
            None => continue,
        };

        // --- chỉ quản lý container do agent tạo ---
        let labels = container.labels.unwrap_or_default();
        if labels.get("managed_by") != Some(&"agent".to_string()) {
            continue;
        }

        let inspect = match docker
            .inspect_container(&id, None::<InspectContainerOptions>)
            .await
        {
            Ok(i) => i,
            Err(e) => {
                warn!("Watchdog: inspect failed for {}: {}", id, e);
                continue;
            }
        };

        let state = inspect.state.and_then(|s| s.status).unwrap_or_default();

        if state == "running" {
            continue;
        }

        warn!("Watchdog detected container {} in state '{}'", id, state);

        let restart_result = docker
            .restart_container(&id, None::<RestartContainerOptions>)
            .await;

        let (level, message) = match restart_result {
            Ok(_) => (
                "WARN",
                format!("Container {} restarted by watchdog", id),
            ),
            Err(e) => (
                "ERROR",
                format!("Failed to restart container {}: {}", id, e),
            ),
        };

        let payload = json!({
            "device_id": config.device_id,
            "category": "DockerWatchdog",
            "level": level,
            "container_id": id,
            "state": state,
            "message": message,
        });

        let mut mqtt = config.mqtt.lock().await;
        let _ = mqtt.publisher(
            Some(&config.topic_pub_logs),
            &payload,
            config.qos,
        );
    }
}
