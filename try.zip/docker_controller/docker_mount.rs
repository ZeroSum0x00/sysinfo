use bollard::Docker;
use std::time::Duration;
use tokio::sync::{mpsc, oneshot};
use tracing::{error, info};

/// Các lệnh docker nội bộ (chưa expose ra ngoài)
pub enum DockerCommand {
    Execute {
        action: Box<dyn FnOnce(&Docker) -> DockerFuture + Send>,
        resp: oneshot::Sender<Result<(), String>>,
    },
    Ping,
}

pub type DockerFuture =
    std::pin::Pin<Box<dyn std::future::Future<Output = Result<(), String>> + Send>>;

/// Handle để các module khác gửi lệnh docker
#[derive(Clone)]
pub struct DockerExecutor {
    sender: mpsc::Sender<DockerCommand>,
}

impl DockerExecutor {
    pub async fn exec<F, Fut>(&self, f: F) -> Result<(), String>
    where
        F: FnOnce(&Docker) -> Fut + Send + 'static,
        Fut: std::future::Future<Output = Result<(), String>> + Send + 'static,
    {
        let (tx, rx) = oneshot::channel();

        self.sender
            .send(DockerCommand::Execute {
                action: Box::new(move |docker| Box::pin(f(docker))),
                resp: tx,
            })
            .await
            .map_err(|_| "Docker executor stopped".to_string())?;

        rx.await.map_err(|_| "Docker executor dropped".to_string())?
    }
}

/// Mount docker & spawn executor loop
pub async fn docker_mount(url: &str, timeout: u64) -> DockerExecutor {
    let docker = if url.starts_with("unix://") {
        let path = url.trim_start_matches("unix://");
        Docker::connect_with_unix(
            path,
            timeout,
            bollard::API_DEFAULT_VERSION,
        )
        .expect("Failed to connect docker via unix socket")
    } else if url.starts_with("tcp://") {
        Docker::connect_with_http(
            url,
            timeout,
            bollard::API_DEFAULT_VERSION,
        )
        .expect("Failed to connect docker via tcp")
    } else {
        panic!("Unknown docker endpoint: {}", url);
    };

    let (tx, mut rx) = mpsc::channel::<DockerCommand>(128);

    tokio::spawn(async move {
        info!("🐳 Docker executor started");

        loop {
            match rx.recv().await {
                Some(DockerCommand::Execute { action, resp }) => {
                    let result = action(&docker).await;
                    let _ = resp.send(result);
                }
                Some(DockerCommand::Ping) => {
                    // giữ connection sống
                }
                None => {
                    error!("Docker executor channel closed");
                    break;
                }
            }
        }
    });

    DockerExecutor { sender: tx }
}
