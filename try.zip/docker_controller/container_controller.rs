use serde_json::Value;
use uuid::Uuid;

use bollard::models::ContainerCreateBody;
use bollard::query_parameters::{
    ListContainersOptionsBuilder,
    CreateContainerOptionsBuilder,
    StartContainerOptionsBuilder,
    StopContainerOptionsBuilder,
    RemoveContainerOptionsBuilder,
    InspectContainerOptions,
};

use crate::docker_controller::docker_mount::DockerExecutor;


/// =======================
/// LIST CONTAINERS
/// =======================
pub async fn list_containers(
    docker: &DockerExecutor,
) -> Result<Vec<Value>, Box<dyn std::error::Error + Send + Sync>> {

    let result = docker.exec(|docker| async move {
        let options = ListContainersOptionsBuilder::default()
            .all(true)
            .build();

        let list = docker.list_containers(Some(options))
            .await
            .map_err(|e| e.to_string())?;

        let mapped: Vec<Value> = list
            .into_iter()
            .map(|c| {
                serde_json::json!({
                    "id": c.id,
                    "names": c.names,
                    "image": c.image,
                    "image_id": c.image_id,
                    "command": c.command,
                    "created": c.created,
                    "state": c.state,
                    "status": c.status,
                    "ports": c.ports,
                    "labels": c.labels,
                    "size_rw": c.size_rw,
                    "size_root_fs": c.size_root_fs,
                    "host_config": c.host_config,
                    "network_settings": c.network_settings,
                    "mounts": c.mounts,
                })
            })
            .collect();

        Ok(mapped)
    }).await?;

    Ok(result)
}


/// =======================
/// CREATE CONTAINER
/// =======================
pub async fn create_container(
    docker: &DockerExecutor,
    container_name: String,
    config: ContainerCreateBody,
) -> Result<String, Box<dyn std::error::Error + Send + Sync>> {

    let result = docker.exec(|docker| async move {
        let final_name = if container_name.trim().is_empty() {
            Uuid::new_v4().to_string()
        } else {
            container_name
        };

        let options = CreateContainerOptionsBuilder::default()
            .name(&final_name)
            .build();

        let response = docker
            .create_container(Some(options), config)
            .await
            .map_err(|e| e.to_string())?;

        Ok(response.id)
    }).await?;

    Ok(result)
}


/// =======================
/// START CONTAINER
/// =======================
pub async fn start_container(
    docker: &DockerExecutor,
    id: &str,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {

    let id = id.to_string();

    docker.exec(move |docker| async move {
        let options = StartContainerOptionsBuilder::default().build();

        docker
            .start_container(&id, Some(options))
            .await
            .map_err(|e| e.to_string())?;

        Ok(())
    }).await?;

    Ok(())
}


/// =======================
/// INSPECT STATUS
/// =======================
pub async fn inspect_container_status(
    docker: &DockerExecutor,
    id: &str,
) -> Result<String, Box<dyn std::error::Error + Send + Sync>> {

    let id = id.to_string();

    let status = docker.exec(move |docker| async move {
        let info = docker
            .inspect_container(&id, None::<InspectContainerOptions>)
            .await
            .map_err(|e| e.to_string())?;

        let status = info
            .state
            .as_ref()
            .and_then(|s| s.status.as_ref())
            .map(|s| match s {
                bollard::models::ContainerStateStatusEnum::CREATED     => "created",
                bollard::models::ContainerStateStatusEnum::RUNNING     => "running",
                bollard::models::ContainerStateStatusEnum::PAUSED      => "paused",
                bollard::models::ContainerStateStatusEnum::RESTARTING  => "restarting",
                bollard::models::ContainerStateStatusEnum::REMOVING    => "removing",
                bollard::models::ContainerStateStatusEnum::EXITED      => "exited",
                bollard::models::ContainerStateStatusEnum::DEAD        => "dead",
                _                                                      => "unknown",
            })
            .unwrap_or("unknown");

        Ok(status.to_string())
    }).await?;

    Ok(status)
}


/// =======================
/// STOP CONTAINER
/// =======================
pub async fn stop_container(
    docker: &DockerExecutor,
    id: &str,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {

    let id = id.to_string();

    docker.exec(move |docker| async move {
        let options = StopContainerOptionsBuilder::default()
            .t(0)
            .build();

        docker
            .stop_container(&id, Some(options))
            .await
            .map_err(|e| e.to_string())?;

        Ok(())
    }).await?;

    Ok(())
}


/// =======================
/// DELETE CONTAINER
/// =======================
pub async fn delete_container(
    docker: &DockerExecutor,
    id: &str,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {

    let id = id.to_string();

    docker.exec(move |docker| async move {
        let options = RemoveContainerOptionsBuilder::default()
            .force(true)
            .v(true)
            .link(false)
            .build();

        docker
            .remove_container(&id, Some(options))
            .await
            .map_err(|e| e.to_string())?;

        Ok(())
    }).await?;

    Ok(())
}
