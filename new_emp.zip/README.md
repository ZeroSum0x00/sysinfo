# Edge Controller - System Monitoring Bot

A comprehensive system monitoring bot written in Rust that collects telemetry data, monitors Docker containers, and provides alerting capabilities via MQTT.

## Features

### Telemetry Collection
- **CPU**: Usage percentage, frequency
- **Memory (RAM)**: Total, used, available, usage percentage
- **Disk**: Per-disk usage statistics
- **Network**: RX/TX bytes and packets
- **GPU**: NVIDIA GPU utilization, memory, temperature (optional)
- **Power**: Consumption and input voltage (battery systems)
- **I/O**: Read/write operations (basic implementation)

### Docker Integration
- Container monitoring and statistics
- Container management (start/stop/restart)
- Real-time container metrics publishing

### Alerting System
- Configurable CPU and memory thresholds
- Sustained alert detection (alerts only after X seconds of continuous high usage)
- Alert cooldown periods to prevent spam
- MQTT-based alert publishing

### MQTT Pub/Sub
- Real-time telemetry publishing
- Alert notifications
- Container statistics
- Command subscription capability

## Quick Start

### Using Docker Compose (Recommended)

1. **Clone and navigate to the project:**
   ```bash
   cd edge-controller
   ```

2. **Start the monitoring stack:**
   ```bash
   docker-compose up -d
   ```

3. **Check logs:**
   ```bash
   docker-compose logs -f edge-controller
   ```

### Manual Build and Run

1. **Build the project:**
   ```bash
   cargo build --release
   ```

2. **Run with default config:**
   ```bash
   ./target/release/edge-controller
   ```

3. **Run with custom config:**
   ```bash
   CONFIG_PATH=/path/to/config.toml ./target/release/edge-controller
   ```

## Configuration

The application uses a TOML configuration file. A default `config.toml` is created automatically.

### Configuration Options

```toml
[monitoring]
interval_seconds = 30          # Monitoring interval
enable_gpu = true             # Enable GPU monitoring
enable_power = true           # Enable power monitoring

[mqtt]
broker = "localhost"          # MQTT broker address
port = 1883                   # MQTT port
client_id = "edge-controller" # Client ID
telemetry_topic = "telemetry/system"    # Telemetry topic
alert_topic = "alerts/system"           # Alert topic
container_topic = "telemetry/containers" # Container stats topic
qos = 1                      # QoS level (0, 1, 2)

[alerting]
cpu_threshold_percent = 80.0      # CPU alert threshold
memory_threshold_percent = 85.0   # Memory alert threshold
alert_cooldown_seconds = 300      # Min time between alerts
sustained_alert_seconds = 60      # Sustained high usage before alert

[docker]
socket_path = "/var/run/docker.sock"  # Docker socket path
enable_container_monitoring = true    # Enable container monitoring
```

## MQTT Topics

### Published Topics
- `telemetry/system` - System metrics (JSON)
- `alerts/system` - System alerts (JSON)
- `telemetry/containers/{container_id}` - Container statistics (JSON)
- `responses/docker` - Docker command responses (JSON)
- `docker/pull/progress` - Docker image pull progress updates (JSON)
- `docker/run/progress` - Docker run image progress updates (JSON)

### Subscribed Topics
- `commands/docker` - Docker management commands (JSON)

### Message Formats

#### System Metrics
```json
{
  "timestamp": "2024-01-01T12:00:00Z",
  "cpu": {
    "usage_percent": 45.2,
    "frequency_mhz": 3200
  },
  "memory": {
    "total_gb": 16.0,
    "used_gb": 8.5,
    "available_gb": 7.5,
    "usage_percent": 53.1
  },
  "disk": [
    {
      "name": "/dev/sda1",
      "total_gb": 500.0,
      "used_gb": 150.0,
      "available_gb": 350.0,
      "usage_percent": 30.0
    }
  ],
  "network": {
    "rx_bytes": 1024000,
    "tx_bytes": 512000,
    "rx_packets": 1500,
    "tx_packets": 800
  },
  "gpu": {
    "name": "NVIDIA GeForce RTX 3080",
    "utilization_percent": 65,
    "memory_used_mb": 2048,
    "memory_total_mb": 8192,
    "temperature_celsius": 72
  },
  "power": {
    "consumption_watts": 150.5,
    "input_voltage": 12.1
  },
  "io": {
    "read_bytes": 0,
    "write_bytes": 0,
    "read_operations": 0,
    "write_operations": 0
  }
}
```

#### Alerts
```json
{
  "alert_type": "CpuUsage",
  "message": "CPU usage is 85.2% (threshold: 80.0%)",
  "value": 85.2,
  "threshold": 80.0,
  "timestamp": "2024-01-01T12:00:00Z"
}
```

#### Container Stats
```json
{
  "id": "abc123...",
  "name": "my-container",
  "image": "nginx:latest",
  "status": "running",
  "cpu_percent": 5.2,
  "memory_usage": 67108864,
  "memory_limit": 134217728,
  "memory_percent": 50.0,
  "network_rx": 1024,
  "network_tx": 512,
  "block_read": 4096,
  "block_write": 2048,
  "timestamp": "2024-01-01T12:00:00Z"
}
```

## Docker Management API

The edge controller supports remote Docker container management through MQTT commands. Send JSON commands to the `commands/docker` topic and receive responses on `responses/docker`.

### Available Commands

#### 1. Start Container
```json
{
  "Start": {
    "container_id": "container_name_or_id"
  }
}
```

#### 2. Stop Container
```json
{
  "Stop": {
    "container_id": "container_name_or_id"
  }
}
```

#### 3. Restart Container
```json
{
  "Restart": {
    "container_id": "container_name_or_id"
  }
}
```

#### 4. Delete Container
```json
{
  "Delete": {
    "container_id": "container_name_or_id",
    "force": true
  }
}
```

#### 5. Run Image (Create and Start)
```json
{
  "RunImage": {
    "image": "nginx:latest",
    "name": "my-nginx-container"
  }
}
```

#### 6. Pull Image
```json
{
  "PullImage": {
    "image": "nginx:latest"
  }
}
```

#### 7. Pull Image with Progress Updates
```json
{
  "PullImageProgress": {
    "image": "nginx:latest"
  }
}
```

#### 8. Run Image with Progress Updates
```json
{
  "RunImageProgress": {
    "image": "nginx:latest",
    "name": "my-web-server"
  }
}
```

#### 9. List Containers
```json
{
  "ListContainers": {}
}
```

#### 10. List Images
```json
{
  "ListImages": {}
}
```

#### 11. Get Container Info
```json
{
  "GetInfo": {
    "container_id": "container_name_or_id"
  }
}
```

#### 12. Get Container Logs
```json
{
  "GetLogs": {
    "container_id": "container_name_or_id",
    "tail": "100"
  }
}
```

### Response Format

All commands return a JSON response with the following structure:

```json
{
  "success": true|false,
  "message": "Operation result description",
  "data": { ... } // Optional additional data
}
```

### Example Usage

Start a container:
```bash
mosquitto_pub -h localhost -t "commands/docker" -m '{"Start": {"container_id": "nginx"}}'
```

List all containers:
```bash
mosquitto_pub -h localhost -t "commands/docker" -m '{"ListContainers": {}}'
```

Run a new container from image:
```bash
mosquitto_pub -h localhost -t "commands/docker" -m '{"RunImage": {"image": "nginx:latest", "name": "web-server"}}'
```

#### Docker Image Pull Progress
When using `PullImageProgress` command, progress updates are published to `docker/pull/progress`:

```json
{
  "image": "nginx:latest",
  "status": "Pulling fs layer",
  "progress": {
    "current": 1048576,
    "total": 2097152
  },
  "progress_detail": {
    "current": 1048576,
    "total": 2097152
  },
  "id": "sha256:abcd1234",
  "timestamp": "2024-01-01T12:00:00Z"
}
```

Progress updates are sent:
- Every 2 seconds during download
- When status changes (e.g., "Pull complete", "Downloaded newer image")
- When errors occur

#### Docker Run Image Progress
When using `RunImageProgress` command, progress updates are published to `docker/run/progress`:

```json
{
  "operation": "run_image",
  "image": "nginx:latest",
  "phase": "pulling_image|container_created|starting_container|completed",
  "status": "Pulling fs layer",
  "progress": "[==================================================>] 2.38kB/2.38kB",
  "container_id": "abc123...",
  "name": "my-container",
  "timestamp": "2024-01-01T12:00:00Z"
}
```

Run image progress includes:
- **pulling_image**: Image download progress (only if image doesn't exist locally)
- **container_created**: Container creation completed
- **starting_container**: Container is being started
- **completed**: Container is running successfully

## Docker Deployment

### Building the Image
```bash
docker build -t edge-controller .
```

### Running with Docker
```bash
docker run -d \
  --name edge-controller \
  -v /var/run/docker.sock:/var/run/docker.sock:ro \
  -v $(pwd)/config.toml:/etc/edge-controller/config.toml:ro \
  --network host \
  edge-controller
```

## Development

### Prerequisites
- Rust 1.75+
- Docker (for container monitoring)
- MQTT broker (Mosquitto recommended)

### Building
```bash
cargo build
```

### Testing
```bash
cargo test
```

### Running in Development
```bash
cargo run
```

## Monitoring and Logs

### Viewing Logs
```bash
# Docker Compose
docker-compose logs -f edge-controller

# Docker
docker logs -f edge-controller

# Local
RUST_LOG=debug cargo run
```

### Health Checks
The container includes basic health check functionality. Monitor the logs for any errors or connection issues.

## Troubleshooting

### Common Issues

1. **Docker Socket Access**
   - Ensure the container has access to `/var/run/docker.sock`
   - Check Docker socket permissions

2. **MQTT Connection**
   - Verify MQTT broker is running and accessible
   - Check network connectivity and firewall rules

3. **GPU Monitoring**
   - Requires NVIDIA drivers and nvml library
   - May not work in containers without GPU passthrough

4. **Permission Issues**
   - Run as appropriate user or with necessary capabilities
   - Check file permissions for config and log directories

### Debug Mode
Enable debug logging:
```bash
RUST_LOG=debug ./target/release/edge-controller
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.
