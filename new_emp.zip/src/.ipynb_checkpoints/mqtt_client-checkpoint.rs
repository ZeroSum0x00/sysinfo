use crate::config::MqttConfig;
use crate::docker_manager::{DockerCommand, DockerManager, DockerResponse, OperatorPublisherConfig, ApplicationPublisherConfig};
use crate::types::{Alert, ContainerStats, SystemMetrics};
use anyhow::Result;
use rumqttc::{AsyncClient, Event, Incoming, MqttOptions, QoS, LastWill};
use serde_json;
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::Mutex;
use tokio::task;
use tracing::{debug, error, info, warn};
use crate::utils::convert_message::{convert_message_docker, convert_message_ssh};
use serde_json::Value;
use serde_json::json;
use crate::types::SSHResponse;

/// Simple MQTT publisher for progress updates
#[derive(Clone)]
pub struct MqttProgressPublisher {
    client: AsyncClient,
    qos: QoS,
}
use crate::reverse_ssh::ReverseSsh;

impl MqttProgressPublisher {
    pub async fn publish_to_topic(&self, topic: &str, payload: String) -> Result<()> {
        self.client.publish(topic, self.qos, false, payload).await?;
        Ok(())
    }
}


pub struct MqttClient {
    client: AsyncClient,
    default_topic: String,
    telemetry_topic: String,
    alert_topic: String,
    docker_info_topic: String,
    command_topic: String,
    ssh_topic: String,
    qos: QoS,
    docker_manager: Option<Arc<Mutex<DockerManager>>>,
    ssh_manager: Option<Arc<Mutex<ReverseSsh>>>,
}

impl MqttClient {
    pub async fn new(
        config: &MqttConfig,
        docker_manager: Option<Arc<Mutex<DockerManager>>>,
        local_ssh_port: u16,
        ssh_manager: Option<Arc<Mutex<ReverseSsh>>>,
    ) -> Result<Self> {
        info!(
            "Initializing MQTT client: {}@{}:{}",
            config.client_id, config.broker, config.port
        );
        let will_payload = serde_json::json!({
            "device_id": config.client_id.clone(),
            "status": "offline",
            "reason": "connection_lost"
        }).to_string();
        
        let mut mqtt_options = MqttOptions::new(&config.client_id, &config.broker, config.port);
        mqtt_options.set_keep_alive(Duration::from_secs(30));
        mqtt_options.set_last_will(LastWill::new(
            format!("{}/presence", config.default_topic.clone()),
            will_payload,
            QoS::AtLeastOnce,
            true,
        ));
        
        if let (Some(username), Some(password)) = (&config.username, &config.password) {
            info!("Using MQTT authentication with username: {}", username);
            mqtt_options.set_credentials(username, password);
        }

        let (client, mut eventloop) = AsyncClient::new(mqtt_options, 10);

        // Clone variables for event loop

        let default_base_topic = format!("{}/{}", config.default_topic.clone(), config.client_id.clone());
        let command_topic_sub = format!("{}/{}", default_base_topic.clone(), config.command_topic.clone());
        let command_topic_sub_clone = command_topic_sub.clone();
        let command_topic_pub = format!("{}/response", command_topic_sub.clone());
        let operator_topic_sub = format!("{}/{}", default_base_topic.clone(), config.operator_topic.clone());
        let operator_topic_sub_clone = operator_topic_sub.clone();
        let operator_topic_pub = format!("{}/response", operator_topic_sub.clone());
        let ssh_topic_sub = format!("{}/{}", default_base_topic.clone(), config.ssh_topic.clone());
        let ssh_topic_sub_clone = ssh_topic_sub.clone();
        let ssh_topic_pub = format!("{}/response", ssh_topic_sub.clone());
        
        let docker_manager_clone = docker_manager.clone();
        let config_clone = config.clone();
        let client_clone = client.clone();
        let ssh_manager_clone = ssh_manager.clone();
        
        // Spawn event loop handler
        task::spawn(async move {
            loop {
                match eventloop.poll().await {
                    Ok(Event::Incoming(Incoming::ConnAck(_))) => {
                        info!("MQTT connected successfully");
                    }
                    Ok(Event::Incoming(Incoming::Disconnect)) => {
                        warn!("MQTT disconnected");
                    }
                    Ok(Event::Incoming(Incoming::Publish(publish))) => {
                        debug!(
                            "MQTT message received on topic '{}': {} bytes",
                            publish.topic,
                            publish.payload.len()
                        );

                        println!("{}", publish.topic);
                        println!("DEBUG MQTT: Topic matches, docker_manager is_some: {}", docker_manager_clone.is_some());
                        // Handle Docker commands
                        if publish.topic == command_topic_sub {
                            if let Some(ref docker_mgr) = docker_manager_clone {
                                let qos_level = match config_clone.qos {
                                    0 => QoS::AtMostOnce,
                                    1 => QoS::AtLeastOnce,
                                    2 => QoS::ExactlyOnce,
                                    _ => QoS::AtMostOnce,
                                };

                                // Debug payload
                                let payload_str = String::from_utf8_lossy(&publish.payload);
                                println!("DEBUG MQTT: Received payload: {}", payload_str);
                                
                                let data_receive: Value = match serde_json::from_slice(&publish.payload) {
                                    Ok(v) => v,
                                    Err(e) => {
                                        error!("Invalid JSON payload: {:?}", e);
                                        return; // ⬅️ QUAN TRỌNG
                                    }
                                };

                                let command_convert = convert_message_docker(&publish.payload).await;

                                match command_convert {
                                    Ok(command) => {
                                        info!("Executing Docker command: {:?}", command);
                                        // Handle special case for PullImageProgress and RunImageProgress
                                        if let DockerCommand::RunImageProgress { id, image, name, envs, ports, volumes } = command {
                                            let docker_mgr_clone = docker_mgr.clone();
                                            let docker_inspect_clone = docker_mgr.clone();
                                            // Clone values for the closure
                                            let image_clone = image.clone();
                                            let name_clone = name.clone();
                                            let command_topic_pub_clone = command_topic_pub.clone();
                                            // Create a simple MQTT publisher for progress updates
                                            let progress_publisher = Arc::new(MqttProgressPublisher {
                                                client: client_clone.clone(),
                                                qos: qos_level,
                                            });
                                            let client_for_task = client_clone.clone();
                                            let command_topic_pub_for_task = command_topic_pub.clone();

                                    tokio::spawn(async move {
                                        let created_container_id =
                                            docker_mgr_clone.lock().await
                                                .run_image_with_progress_updates(
                                                    &command_topic_pub_for_task,
                                                    &id,
                                                    &image_clone,
                                                    name_clone.as_deref(),
                                                    envs,
                                                    ports,
                                                    volumes,
                                                    progress_publisher,
                                                )
                                                .await;
                                    
                                        let container_id = match created_container_id {
                                            Ok(id) => id,
                                            Err(e) => {
                                                error!("Failed to run container: {:?}", e);
                                                return;
                                            }
                                        };
                                    
                                        let state = docker_inspect_clone
                                            .lock()
                                            .await
                                            .inspect_container_status(&container_id)
                                            .await
                                            .unwrap_or_else(|_| "unknown".to_string());
                                    
                                        let payload = json!({
                                            "container_id": container_id,
                                            "status": state,
                                        });
                                    
                                        let data_publisher = ApplicationPublisherConfig {
                                            id,
                                            status: "successfully".to_string(),
                                            step: "run".to_string(),
                                            message: "".to_string(),
                                            payload,
                                        };
                                    
                                        if let Ok(json) = serde_json::to_string(&data_publisher) {
                                            let _ = client_for_task
                                                .publish(&command_topic_pub_for_task, qos_level, false, json)
                                                .await;
                                        }
                                    });
                                        } else {
                                            // Handle other commands normally
                                            let docker_mgr_locked = docker_mgr.lock().await;
                                            let response = docker_mgr_locked.execute_command(command).await;

                                            // Publish response
                                            if let Ok(response_json) = serde_json::to_string(&response) {
                                                let _ = client_clone.publish(&command_topic_pub, qos_level, false, response_json).await;
                                            }
                                        }
                                    }
                                    Err(e) => {
                                        error!("Failed to parse Docker command: {}", e);
                                        let error_response = DockerResponse {
                                            success: false,
                                            message: format!("Invalid command format: {}", e),
                                            data: None,
                                        };
                                        if let Ok(response_json) = serde_json::to_string(&error_response) {
                                            let _ = client_clone.publish(&command_topic_pub, qos_level, false, response_json).await;
                                        }
                                    }
                                }
                            }
                        } else if publish.topic == operator_topic_sub {
                            if let Some(ref docker_mgr) = docker_manager_clone {
                                let qos_level = match config_clone.qos {
                                    0 => QoS::AtMostOnce,
                                    1 => QoS::AtLeastOnce,
                                    2 => QoS::ExactlyOnce,
                                    _ => QoS::AtMostOnce,
                                };

                                let command_convert = convert_message_docker(&publish.payload).await;
                                match command_convert {
                                    Ok(command) => {
                                        info!("Executing Docker command: {:?}", command);
                                        // Handle special case for PullImageProgress and RunImageProgress
                                        if let DockerCommand::Start { container_id } = command {
                                            let docker_mgr_clone = docker_mgr.clone();
                                            let docker_inspect_clone = docker_mgr.clone();
                                            let container_id_clone = container_id.clone();
                                            let id_inspect_clone = container_id.clone();
                                            
                                            let pub_container_id = container_id.clone();
                                            
                                            let client = client_clone.clone();
                                            let topic_pub = operator_topic_pub.clone();
                                            
                                            tokio::spawn(async move {
                                                let res = docker_mgr_clone
                                                    .lock()
                                                    .await
                                                    .start_container(&container_id_clone)
                                                    .await;
                                            
                                                if let Err(e) = res {
                                                    error!("Failed to start container {}: {:?}", container_id_clone, e);
                                            
                                                    let response = OperatorPublisherConfig {
                                                        container_id: pub_container_id.clone(),
                                                        state: "error".to_string(),
                                                        status: "failed".to_string(),
                                                        message: e.to_string(),
                                                    };
                                            
                                                    if let Ok(json) = serde_json::to_string(&response) {
                                                        let _ = client.publish(&topic_pub, qos_level, false, json).await;
                                                    }
                                                    return;
                                                }
                                            
                                                info!("Container {} start requested", container_id_clone);
                                            
                                                tokio::time::sleep(std::time::Duration::from_millis(300)).await;
                                            
                                                let state = docker_inspect_clone
                                                    .lock()
                                                    .await
                                                    .inspect_container_status(&id_inspect_clone)
                                                    .await
                                                    .unwrap_or_else(|_| "unknown".to_string());
                                            
                                                let response = OperatorPublisherConfig {
                                                    container_id: pub_container_id,
                                                    state,
                                                    status: "successfully".to_string(),
                                                    message: "".to_string(),
                                                };
                                            
                                                if let Ok(json) = serde_json::to_string(&response) {
                                                    let _ = client.publish(&topic_pub, qos_level, false, json).await;
                                                }
                                            });
                                        } else if let DockerCommand::Stop { container_id } = command {
                                            let docker_mgr_clone = docker_mgr.clone();
                                            let docker_inspect_clone = docker_mgr.clone();
                                            let container_id_clone = container_id.clone();
                                            let id_inspect_clone = container_id.clone();
                                            
                                            let pub_container_id = container_id.clone();
                                            
                                            let client = client_clone.clone();
                                            let topic_pub = operator_topic_pub.clone();
                                            
                                            tokio::spawn(async move {
                                                let res = docker_mgr_clone
                                                    .lock()
                                                    .await
                                                    .stop_container(&container_id_clone)
                                                    .await;
                                            
                                                if let Err(e) = res {
                                                    error!("Failed to stop container {}: {:?}", container_id_clone, e);
                                            
                                                    let response = OperatorPublisherConfig {
                                                        container_id: pub_container_id.clone(),
                                                        state: "error".to_string(),
                                                        status: "failed".to_string(),
                                                        message: e.to_string(),
                                                    };
                                            
                                                    if let Ok(json) = serde_json::to_string(&response) {
                                                        let _ = client.publish(&topic_pub, qos_level, false, json).await;
                                                    }
                                                    return;
                                                }
                                            
                                                info!("Container {} stop requested", container_id_clone);
                                            
                                                tokio::time::sleep(std::time::Duration::from_millis(300)).await;
                                            
                                                let state = docker_inspect_clone
                                                    .lock()
                                                    .await
                                                    .inspect_container_status(&id_inspect_clone)
                                                    .await
                                                    .unwrap_or_else(|_| "unknown".to_string());
                                            
                                                let response = OperatorPublisherConfig {
                                                    container_id: pub_container_id,
                                                    state,
                                                    status: "successfully".to_string(),
                                                    message: "".to_string(),
                                                };
                                            
                                                if let Ok(json) = serde_json::to_string(&response) {
                                                    let _ = client.publish(&topic_pub, qos_level, false, json).await;
                                                }
                                            });
                                        } else if let DockerCommand::Restart { container_id } = command {
                                            let docker_mgr_clone = docker_mgr.clone();
                                            let docker_inspect_clone = docker_mgr.clone();
                                            let container_id_clone = container_id.clone();
                                            let id_inspect_clone = container_id.clone();
                                            
                                            let pub_container_id = container_id.clone();
                                            
                                            let client = client_clone.clone();
                                            let topic_pub = operator_topic_pub.clone();
                                            
                                            tokio::spawn(async move {
                                                let res = docker_mgr_clone
                                                    .lock()
                                                    .await
                                                    .restart_container(&container_id_clone)
                                                    .await;
                                            
                                                if let Err(e) = res {
                                                    error!("Failed to restart container {}: {:?}", container_id_clone, e);
                                            
                                                    let response = OperatorPublisherConfig {
                                                        container_id: pub_container_id.clone(),
                                                        state: "error".to_string(),
                                                        status: "failed".to_string(),
                                                        message: e.to_string(),
                                                    };
                                            
                                                    if let Ok(json) = serde_json::to_string(&response) {
                                                        let _ = client.publish(&topic_pub, qos_level, false, json).await;
                                                    }
                                                    return;
                                                }
                                            
                                                info!("Container {} restart requested", container_id_clone);
                                            
                                                tokio::time::sleep(std::time::Duration::from_millis(300)).await;
                                            
                                                let state = docker_inspect_clone
                                                    .lock()
                                                    .await
                                                    .inspect_container_status(&id_inspect_clone)
                                                    .await
                                                    .unwrap_or_else(|_| "unknown".to_string());
                                            
                                                let response = OperatorPublisherConfig {
                                                    container_id: pub_container_id,
                                                    state,
                                                    status: "successfully".to_string(),
                                                    message: "".to_string(),
                                                };
                                            
                                                if let Ok(json) = serde_json::to_string(&response) {
                                                    let _ = client.publish(&topic_pub, qos_level, false, json).await;
                                                }
                                            });
                                        } else if let DockerCommand::Delete { container_id, force } = command {
                                            let docker_mgr_clone = docker_mgr.clone();
                                            let docker_inspect_clone = docker_mgr.clone();
                                            let container_id_clone = container_id.clone();
                                            let force_clone = force.clone();
                                            let id_inspect_clone = container_id.clone();
                                            
                                            let pub_container_id = container_id.clone();
                                            
                                            let client = client_clone.clone();
                                            let topic_pub = operator_topic_pub.clone();
                                            
                                            tokio::spawn(async move {
                                                let res = docker_mgr_clone
                                                    .lock()
                                                    .await
                                                    .delete_container(&container_id_clone, force_clone)
                                                    .await;
                                            
                                                if let Err(e) = res {
                                                    error!("Failed to delete container {}: {:?}", container_id_clone, e);
                                            
                                                    let response = OperatorPublisherConfig {
                                                        container_id: pub_container_id.clone(),
                                                        state: "error".to_string(),
                                                        status: "failed".to_string(),
                                                        message: e.to_string(),
                                                    };
                                            
                                                    if let Ok(json) = serde_json::to_string(&response) {
                                                        let _ = client.publish(&topic_pub, qos_level, false, json).await;
                                                    }
                                                    return;
                                                }
                                            
                                                info!("Container {} delete requested", container_id_clone);
                                            
                                                tokio::time::sleep(std::time::Duration::from_millis(300)).await;
                                            
                                                let state = docker_inspect_clone
                                                    .lock()
                                                    .await
                                                    .inspect_container_status(&id_inspect_clone)
                                                    .await
                                                    .unwrap_or_else(|_| "unknown".to_string());
                                            
                                                let response = OperatorPublisherConfig {
                                                    container_id: pub_container_id,
                                                    state,
                                                    status: "successfully".to_string(),
                                                    message: "".to_string(),
                                                };
                                            
                                                if let Ok(json) = serde_json::to_string(&response) {
                                                    let _ = client.publish(&topic_pub, qos_level, false, json).await;
                                                }
                                            });
                                        } else {
                                            // Handle other commands normally
                                            let docker_mgr_locked = docker_mgr.lock().await;
                                            let response = docker_mgr_locked.execute_command(command).await;

                                            // Publish response
                                            if let Ok(response_json) = serde_json::to_string(&response) {
                                                let _ = client_clone.publish(&command_topic_pub, qos_level, false, response_json).await;
                                            }
                                        }
                                    }
                                    Err(e) => {
                                        error!("Failed to parse Docker command: {}", e);
                                        let error_response = DockerResponse {
                                            success: false,
                                            message: format!("Invalid command format: {}", e),
                                            data: None,
                                        };
                                        if let Ok(response_json) = serde_json::to_string(&error_response) {
                                            let _ = client_clone.publish(&command_topic_pub, qos_level, false, response_json).await;
                                        }
                                    }
                                }
                            }
                        } else if publish.topic == ssh_topic_sub {
                            let qos_level = match config_clone.qos {
                                0 => QoS::AtMostOnce,
                                1 => QoS::AtLeastOnce,
                                2 => QoS::ExactlyOnce,
                                _ => QoS::AtMostOnce,
                            };
                            let client = client_clone.clone();
                            
                            if let Some(ref ssh_manager_clone) = ssh_manager_clone {
                                let ssh_command_convert = convert_message_ssh(&publish.payload, local_ssh_port);
                                match ssh_command_convert {
                                    Ok(command) => {
                                        let command_clone = command.clone();
                                        let result = ssh_manager_clone.lock().await.execute_command(command);
                                        match result {
                                            Ok(_) => {
                                                let response = SSHResponse {
                                                    success: true,
                                                    message: format!("Executed SSH command: {:?}", command_clone),
                                                    data: None,
                                                };
                                                if let Ok(response_json) = serde_json::to_string(&response) {
                                                    let _ = client.publish(&ssh_topic_pub, qos_level, false, response_json).await;
                                                }
                                            }
                                            Err(e) => {
                                                error!("Failed to execute SSH command: {}", e);
                                                let error_response = SSHResponse {
                                                    success: false,
                                                    message: format!("Command execution failed: {}", e),
                                                    data: None,
                                                };
                                                if let Ok(error_json) = serde_json::to_string(&error_response) {
                                                    let _ = client.publish(&ssh_topic_pub, qos_level, false, error_json).await;
                                                }
                                            }
                                        }
                                    }
                                    Err(e) => {
                                        error!("Failed to parse SSH command: {}", e);
                                        let error_response = SSHResponse {
                                            success: false,
                                            message: format!("Invalid command format: {}", e),
                                            data: None,
                                        };
                                        if let Ok(error_json) = serde_json::to_string(&error_response) {
                                            let _ = client.publish(&ssh_topic_pub, qos_level, false, error_json).await;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    Ok(Event::Incoming(Incoming::SubAck(suback))) => {
                        info!("MQTT subscription acknowledged: {:?}", suback);
                    }
                    Ok(Event::Incoming(Incoming::PubAck(puback))) => {
                        debug!("MQTT publish acknowledged: packet_id={}", puback.pkid);
                    }
                    Ok(Event::Outgoing(outgoing)) => {
                        debug!("MQTT outgoing event: {:?}", outgoing);
                    }
                    Err(e) => {
                        error!("MQTT connection error: {:?}", e);
                        tokio::time::sleep(Duration::from_secs(1)).await;
                    }
                    _ => {
                        debug!("MQTT unhandled event");
                    }
                }
            }
        });

        let qos = match config.qos {
            0 => QoS::AtMostOnce,
            1 => QoS::AtLeastOnce,
            2 => QoS::ExactlyOnce,
            _ => QoS::AtMostOnce,
        };

        // Subscribe to command topic if Docker manager is available
        if docker_manager.is_some() {
            client.subscribe(&command_topic_sub_clone, qos).await?;
            client.subscribe(&operator_topic_sub_clone, qos).await?;
            client.subscribe(&ssh_topic_sub_clone, qos).await?;
            // info!(
            //     "Subscribed to Docker command topic: {}",
            //     command_topic_sub_clone.clone()
            // );
        }

        Ok(Self {
            client,
            default_topic: default_base_topic.clone(),
            telemetry_topic: config.telemetry_topic.clone(),
            alert_topic: config.alert_topic.clone(),
            docker_info_topic: config.docker_info_topic.clone(),
            command_topic: config.command_topic.clone(),
            ssh_topic: config.ssh_topic.clone(),
            qos,
            docker_manager,
            ssh_manager
        })
    }

    pub async fn publish_telemetry(&self, metrics: &SystemMetrics) -> Result<()> {
        let topic = format!("{}/{}", self.default_topic, self.telemetry_topic);
        let payload = serde_json::to_string(metrics)?;
        info!(
            "Publishing telemetry to topic '{}' ({} bytes)",
            topic,
            payload.len()
        );
        // debug!("Telemetry payload: {}", payload);
        self.client
            .publish(&topic, self.qos, false, payload)
            .await?;
        Ok(())
    }

    pub async fn publish_alert(&self, alert: &Alert) -> Result<()> {
        let payload = serde_json::to_string(alert)?;
        warn!(
            "Publishing alert to topic '{}' ({} bytes): {}",
            self.alert_topic,
            payload.len(),
            alert.message
        );
        debug!("Alert payload: {}", payload);
        self.client
            .publish(&self.alert_topic, self.qos, false, payload)
            .await?;
        Ok(())
    }
    
    pub async fn publish_container_stats2(
        &self,
        stats: &serde_json::Value,
        client_id_clone: &str,
    ) -> Result<()> {
        let mut payload_value = stats.clone();
    
        if let Value::Object(ref mut map) = payload_value {
            map.insert(
                "device_id".to_string(),
                Value::String(client_id_clone.to_string()),
            );
        }
    
        let payload = serde_json::to_string(&payload_value)?;
    
        let topic = format!("{}/{}", self.default_topic, self.docker_info_topic);
        self.client
            .publish(&topic, self.qos, false, payload)
            .await?;
    
        Ok(())
    }

    pub async fn publish_container_stats(&self, stats: &ContainerStats) -> Result<()> {
        let topic = format!("{}/{}", self.default_topic, self.docker_info_topic);
        let payload = serde_json::to_string(stats)?;
        info!(
            "Publishing container stats for '{}' to topic '{}' ({} bytes)",
            stats.name,
            topic,
            payload.len()
        );
        debug!("Container stats payload: {}", payload);
        self.client
            .publish(&topic, self.qos, false, payload)
            .await?;
        Ok(())
    }

    pub async fn subscribe_to_commands(&self, command_topic: &str) -> Result<()> {
        info!("Subscribing to command topic: '{}'", command_topic);
        self.client.subscribe(command_topic, self.qos).await?;
        Ok(())
    }

    pub async fn publish_log(&self, level: &str, message: &str) -> Result<()> {
        let log_entry = serde_json::json!({
            "timestamp": chrono::Utc::now().to_rfc3339(),
            "level": level,
            "message": message
        });

        let topic = "logs/edge-controller";
        let payload = log_entry.to_string();
        // info!(
        //     "Publishing log [{}] to topic '{}' ({} bytes): {}",
        //     level,
        //     topic,
        //     payload.len(),
        //     message
        // );
        // debug!("Log payload: {}", payload);
        self.client.publish(topic, self.qos, false, payload).await?;
        Ok(())
    }

    pub async fn publish_to_topic(&self, topic: &str, payload: String) -> Result<()> {
        if topic == "docker/pull/progress" || topic == "docker/run/progress" {
            debug!("Publishing to topic '{}' ({} bytes)", topic, payload.len());
        }

        self.client.publish(topic, self.qos, false, payload).await?;
        Ok(())
    }
}

