use std::process::{Child, Command, Stdio};
use std::io::{self, Write};
use std::fs;
use std::path::Path;

use serde::{Deserialize, Serialize};

/// SSH Reverse Tunnel Manager
///
/// Provides multiple methods for establishing SSH reverse tunnels with different authentication methods:
/// - SSH Key Authentication (recommended, most secure)
/// - Password Authentication (requires sshpass)
/// - Interactive Password Input (manual input)
///
/// # Security Notes:
/// - SSH key authentication is preferred over password authentication
/// - Consider the security implications of disabling host key checking in production
/// - Use strong passwords if password authentication is necessary
/// - Install sshpass for password authentication: `apt install sshpass` or `brew install hudochenkov/sshpass/sshpass`
///
/// 
/// 
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum SSHCommand {
    StartWithKey {
        vps_port: u16,
        vps_host: String,
        vps_user: String,
        vps_ssh_port: u16,
        local_ssh_port: u16,
    },
    StartWithPassword {
        vps_port: u16,
        vps_host: String,
        vps_user: String,
        vps_ssh_port: u16,
        local_ssh_port: u16,
        password: String,
    },
    Stop,
}

pub struct ReverseSsh {
    child: Option<Child>,
}

impl ReverseSsh {
    pub fn new() -> Self {
        Self { child: None }
    }

    /// Start SSH tunnel with SSH key authentication (recommended)
    pub fn start_with_key(
        &mut self,
        vps_port: u16,
        vps_host: String,
        vps_user: String,
        vps_ssh_port: u16,
        local_ssh_port: u16,
    ) -> anyhow::Result<()> {
        if self.child.is_some() {
            println!("SSH tunnel already running");
            return Err(anyhow::anyhow!("SSH tunnel is already running"));
        }

        let child = Command::new("ssh")
            .args([
                "-N",
                "-p", &vps_ssh_port.to_string().as_str(),
                "-o", "ServerAliveInterval=30",
                "-o", "ServerAliveCountMax=3",
                "-o", "ExitOnForwardFailure=yes",
                "-o", "StrictHostKeyChecking=no", // For automation, consider security implications
                format!("-R 0.0.0.0:{vps_port}:127.0.0.1:{local_ssh_port}").as_str(),
                format!("{}@{}", vps_user, vps_host).as_str(),
            ])
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .spawn()?;

        println!("SSH tunnel started with SSH key authentication (pid={})", child.id());
        self.child = Some(child);
        Ok(())
    }

    /// Start SSH tunnel with password using sshpass (requires sshpass installed)
    pub fn start_with_password(
        &mut self,
        vps_port: u16,
        vps_host: String,
        vps_user: String,
        vps_ssh_port: u16,
        local_ssh_port: u16,
        password: String,
    ) -> anyhow::Result<()> {
        if self.child.is_some() {
            println!("SSH tunnel already running");
            return Err(anyhow::anyhow!("SSH tunnel is already running"));
        }

        let child = Command::new("sshpass")
            .args([
                "-p", &password,
                "ssh",
                "-F", "/dev/null",          
                "-p", &vps_ssh_port.to_string(),
                "-N",
                "-o", "StrictHostKeyChecking=no",
                "-o", "UserKnownHostsFile=/dev/null",
                "-o", "LogLevel=ERROR",
                format!("-R 0.0.0.0:{vps_port}:10.2.5.113:{local_ssh_port}").as_str(),
                format!("{}@{}", vps_user, vps_host).as_str(),
            ])
            .stdout(Stdio::inherit())
.stderr(Stdio::inherit())
            .spawn()?;

        println!("SSH tunnel started with password authentication (pid={})", child.id());
        self.child = Some(child);
        Ok(())
    }


    pub fn stop(&mut self) -> anyhow::Result<()> {
        if let Some(mut child) = self.child.take() {
            println!("Stopping SSH tunnel...");
            child.kill()?; // SIGKILL
            child.wait()?; // reap zombie
            println!("SSH tunnel stopped");
        } else {
            println!("SSH tunnel not running");
        }
        Ok(())
    }

    pub fn execute_command(&mut self, command: SSHCommand) -> anyhow::Result<()> {
        match command {
            SSHCommand::StartWithKey { vps_port, vps_host, vps_user, vps_ssh_port, local_ssh_port } => {
                self.start_with_key(vps_port, vps_host, vps_user, vps_ssh_port, local_ssh_port)?;
            }
            SSHCommand::StartWithPassword { vps_port, vps_host, vps_user, vps_ssh_port, local_ssh_port, password } => {
                self.start_with_password(vps_port, vps_host, vps_user, vps_ssh_port, local_ssh_port, password)?;
            }
            SSHCommand::Stop => {
                self.stop()?;
            }
        }
        Ok(())
    }
}
