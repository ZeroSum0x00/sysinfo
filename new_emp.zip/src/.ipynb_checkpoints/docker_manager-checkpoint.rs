use bollard::container::{ListContainersOptions, StatsOptions, CreateContainerOptions, RemoveContainerOptions, LogsOptions, LogOutput};
use bollard::image::{CreateImageOptions, ListImagesOptions};
use bollard::Docker;
use chrono::Utc;
use futures_util::stream::{StreamExt, Stream};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::default::Default;
use std::sync::Arc;
use tokio::task;
use anyhow::Result;
use crate::types::ContainerStats;
use serde_json::Value;
use tracing::{debug, error, info, warn};
use serde_json::json;
use bollard::auth::DockerCredentials;
use std::time::Duration;
use bollard::container::Config;
use bollard::models::{HostConfig, PortBinding};


pub fn docker_connect(url: &str, timeout: u64) -> Docker {
    if url.starts_with("unix://") {
        let path = url.trim_start_matches("unix://");
        Docker::connect_with_unix(path, timeout, bollard::API_DEFAULT_VERSION)
            .expect("Failed to connect using unix socket")
    } else if url.starts_with("tcp://") {
        Docker::connect_with_http(url, timeout, bollard::API_DEFAULT_VERSION)
            .expect("Failed to connect using tcp")
    } else {
        panic!("Unknown docker endpoint: {}", url);
    }
}

#[derive(Debug, Clone, Serialize)]
pub enum DockerCommand {
    Start { container_id: String },
    Stop { container_id: String },
    Restart { container_id: String },
    Delete { container_id: String, force: bool },
    RunImage { image: String, name: Option<String> },
    RunImageProgress {
        id: String,
        image: String,
        name: Option<String>,
        envs: Option<HashMap<String, String>>,
        ports: Option<Value>,
        volumes: Option<Value>,
    },
    PullImage { image: String },
    PullImageProgress { image: String },
    ListContainers,
    ListImages,
    GetLogs { container_id: String, tail: Option<String> },
    GetInfo { container_id: String },
}


#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OperatorPublisherConfig {
    pub container_id: String,
    pub state: String,
    pub status: String,
    pub message: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ApplicationPublisherConfig {
    pub id: String,
    pub status: String,
    pub step: String,
    pub message: String,
    pub payload: Value,
}


#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DockerResponse {
    pub success: bool,
    pub message: String,
    pub data: Option<serde_json::Value>,
}

pub struct DockerManager {
    docker: Docker,
    credential: DockerCredentials
}

impl DockerManager {
    pub fn new_with_endpoint(endpoint: &str, docker_credential: DockerCredentials) -> Result<Self> {
        let docker = docker_connect(endpoint, 120);
        let credential = docker_credential.clone();
        Ok(Self { docker, credential })
    }

    pub fn new_default(docker_credential: DockerCredentials) -> Result<Self> {
        let docker = Docker::connect_with_socket_defaults()?;
        let credential = docker_credential.clone();
        Ok(Self { docker, credential })
    }

    pub async fn get_containers(&self) -> Result<Vec<bollard::models::ContainerSummary>> {
        let options = ListContainersOptions::<String> {
            all: true,
            ..Default::default()
        };

        let containers = self.docker.list_containers(Some(options)).await?;
        Ok(containers)
    }

    pub async fn get_container_stats2(&self) -> anyhow::Result<serde_json::Value> {
        let mut my_list_containers = Vec::new();
        let mut my_list_images = Vec::new();
        
        match self.list_all_containers2().await {
            Ok(containers) => {
                for container in containers {
                    let filtered = serde_json::json!({
                        "id": container.get("id").cloned().unwrap_or_default(),
                        "state": container.get("state").cloned().unwrap_or_default(),
                        "status": container.get("status").cloned().unwrap_or_default(),
                    });
                    my_list_containers.push(filtered);
                }
    
            }
            Err(e) => {
                error!("Running failed id {:?}", e);
            }
        }
            
        match self.list_images2().await {
            Ok(images) => {
                for image in images {
                    let filtered = serde_json::json!({
                        "id": image.get("id").cloned().unwrap_or_default(),
                        "tags": image.get("tags").cloned().unwrap_or_default(),
                    });
                    my_list_images.push(filtered);
                }
            }
            Err(e) => {
                error!("Running failed {:?}", e);
            }
        }
        
        let docker_info_payload = serde_json::json!({
            "containers": my_list_containers,
            "images": my_list_images,
        });
        
        Ok(docker_info_payload)
    }

    pub async fn get_container_stats(&self) -> Result<Vec<ContainerStats>> {
        let containers = self.get_containers().await?;
        let mut stats = Vec::new();

        for container in containers {
            if let Some(id) = &container.id {
                if let Ok(container_stat) = self.get_single_container_stats(id).await {
                    stats.push(container_stat);
                }
            }
        }

        Ok(stats)
    }

    async fn get_single_container_stats(&self, container_id: &str) -> Result<ContainerStats> {
        let options = StatsOptions {
            stream: false,
            one_shot: true,
        };

        let mut stream = self.docker.stats(container_id, Some(options));
        let stat = match stream.next().await {
            Some(Ok(stats)) => stats,
            Some(Err(e)) => return Err(e.into()),
            None => return Err(anyhow::anyhow!("No stats received")),
        };

        // Parse the stats - simplified version for basic functionality
        let cpu_percent = 0.0; // Placeholder - CPU stats parsing needs more work

        let memory_usage = 0; // Placeholder
        let memory_limit = 1; // Placeholder
        let memory_percent = 0.0; // Placeholder

        let network_rx = 0; // Placeholder
        let network_tx = 0; // Placeholder

        let block_read = 0; // Placeholder
        let block_write = 0; // Placeholder

        // Get container details
        let container_info = self.docker.inspect_container(container_id, None).await?;

        Ok(ContainerStats {
            id: container_id.to_string(),
            name: container_info.name.unwrap_or_else(|| "unknown".to_string()),
            image: container_info.config.and_then(|c| c.image).unwrap_or_else(|| "unknown".to_string()),
            status: container_info.state.and_then(|s| s.status.map(|status| status.to_string())).unwrap_or_else(|| "unknown".to_string()),
            cpu_percent,
            memory_usage,
            memory_limit,
            memory_percent,
            network_rx,
            network_tx,
            block_read,
            block_write,
            timestamp: Utc::now(),
        })
    }
    
    pub async fn inspect_container_status(
        &self,
        container_id: &str,
    ) -> Result<String, Box<dyn std::error::Error + Send + Sync>> {
    
        let info = self.docker.inspect_container(container_id, None).await?;
    
        let status = info
            .state
            .as_ref()
            .and_then(|s| s.status.as_ref())
            .map(|s| match s {
                bollard::models::ContainerStateStatusEnum::CREATED     => "created",
                bollard::models::ContainerStateStatusEnum::RUNNING     => "running",
                bollard::models::ContainerStateStatusEnum::PAUSED      => "paused",
                bollard::models::ContainerStateStatusEnum::RESTARTING  => "restarting",
                bollard::models::ContainerStateStatusEnum::REMOVING    => "removing",
                bollard::models::ContainerStateStatusEnum::EXITED      => "exited",
                bollard::models::ContainerStateStatusEnum::DEAD        => "dead",
                _                                                      => "unknown",
            })
            .unwrap_or("unknown");

        Ok(status.to_string())
    }
    
    pub async fn start_container(&self, container_id: &str) -> Result<()> {
        self.docker.start_container::<String>(container_id, None).await?;
        Ok(())
    }

    pub async fn stop_container(&self, container_id: &str) -> Result<()> {
        self.docker.stop_container(container_id, None).await?;
        Ok(())
    }

    pub async fn restart_container(&self, container_id: &str) -> Result<()> {
        self.docker.restart_container(container_id, None).await?;
        Ok(())
    }

    pub async fn delete_container(&self, container_id: &str, force: bool) -> Result<()> {
        let options = RemoveContainerOptions {
            force,
            ..Default::default()
        };
        self.docker.remove_container(container_id, Some(options)).await?;
        Ok(())
    }

    pub async fn create_container(&self, image: &str, name: Option<&str>, config: Option<bollard::container::Config<String>>) -> Result<String> {
        let create_options = CreateContainerOptions::<String> {
            name: name.map(|s| s.to_string()).unwrap_or_default(),
            ..Default::default()
        };

        let container_config = config.unwrap_or_else(|| {
            bollard::container::Config::<String> {
                image: Some(image.to_string()),
                ..Default::default()
            }
        });

        let result = self.docker.create_container(Some(create_options), container_config).await?;
        Ok(result.id)
    }

    pub async fn run_image(&self, image: &str, name: Option<&str>, config: Option<bollard::container::Config<String>>) -> Result<String> {
        // First ensure image exists
        self.pull_image(image).await?;

        // Create container
        let container_id = self.create_container(image, name, config).await?;

        // Start container
        self.start_container(&container_id).await?;

        Ok(container_id)
    }

    pub async fn pull_image(&self, image: &str) -> Result<()> {
        let options = CreateImageOptions {
            from_image: image,
            ..Default::default()
        };

        let mut stream = self.docker.create_image(Some(options), None, None);
        while let Some(result) = stream.next().await {
            match result {
                Ok(_) => continue,
                Err(e) => return Err(e.into()),
            }
        }
        Ok(())
    }

    pub fn pull_image_with_progress(&self, image: &str) -> impl Stream<Item = Result<bollard::models::CreateImageInfo, bollard::errors::Error>> {
        let options = CreateImageOptions {
            from_image: image.to_string(),
            ..Default::default()
        };

        self.docker.create_image(Some(options), None, None)
    }

    pub async fn pull_image_with_progress_updates(&self, image: &str, mqtt_client: Arc<crate::mqtt_client::MqttProgressPublisher>) {
        let image = image.to_string();
        let docker_manager = self.docker.clone();

        task::spawn(async move {
            let options = CreateImageOptions {
                from_image: image.clone(),
                ..Default::default()
            };

            let mut stream = docker_manager.create_image(Some(options), None, None);
            let mut last_update = std::time::Instant::now();

            while let Some(result) = stream.next().await {
                match result {
                    Ok(progress_info) => {
                        // Publish progress update every 2 seconds or on significant events
                        let now = std::time::Instant::now();
                        let should_publish = now.duration_since(last_update).as_secs() >= 2 ||
                            progress_info.status.as_deref() == Some("Pull complete") ||
                            progress_info.status.as_deref() == Some("Downloaded newer image") ||
                            progress_info.error.is_some();

                        if should_publish {
                            let progress_data = serde_json::json!({
                                "image": image,
                                "status": progress_info.status,
                                "progress": progress_info.progress,
                                "progress_detail": progress_info.progress_detail,
                                "id": progress_info.id,
                                "error": progress_info.error,
                                "timestamp": chrono::Utc::now().to_rfc3339()
                            });

                            let payload = serde_json::to_string(&progress_data).unwrap_or_default();
                            let topic = "docker/pull/progress";

                            // Publish to MQTT
                            if let Err(e) = mqtt_client.publish_to_topic(topic, payload).await {
                                eprintln!("Failed to publish pull progress: {}", e);
                            }

                            last_update = now;
                        }
                    }
                    Err(e) => {
                        eprintln!("Error during image pull: {}", e);
                        let error_data = serde_json::json!({
                            "image": image,
                            "error": e.to_string(),
                            "timestamp": chrono::Utc::now().to_rfc3339()
                        });

                        let payload = serde_json::to_string(&error_data).unwrap_or_default();
                        let topic = "docker/pull/progress";

                        let _ = mqtt_client.publish_to_topic(topic, payload).await;
                        break;
                    }
                }
            }

            // Send completion message
            let completion_data = serde_json::json!({
                "image": image,
                "status": "completed",
                "timestamp": chrono::Utc::now().to_rfc3339()
            });

            let payload = serde_json::to_string(&completion_data).unwrap_or_default();
            let topic = "docker/pull/progress";

            let _ = mqtt_client.publish_to_topic(topic, payload).await;
        });
    }

    /// Pull image with progress updates for run_image operation
    async fn pull_image_for_run(
        docker_manager: Docker,
        credential: DockerCredentials,
        topic: &str,
        id: &str,
        image: String,
        name: Option<String>,
        mqtt_client: Arc<crate::mqtt_client::MqttProgressPublisher>
    ) -> Result<(), anyhow::Error> {
        // Pull image with progress
        let options = CreateImageOptions {
            from_image: image.clone(),
            ..Default::default()
        };

        let mut stream = docker_manager.create_image(Some(options), None, Some(credential));
        let mut last_update = std::time::Instant::now();

        while let Some(result) = stream.next().await {
            match result {
                Ok(progress_info) => {
                    // Publish progress update every 2 seconds or on significant events
                    let now = std::time::Instant::now();
                    let should_publish = now.duration_since(last_update).as_secs() >= 2 ||
                        progress_info.status.as_deref() == Some("Pull complete") ||
                        progress_info.status.as_deref() == Some("Downloaded newer image") ||
                        progress_info.error.is_some();

                    if should_publish {
                        let payload = serde_json::json!({
                            "process_id": progress_info.id.as_deref().unwrap_or(""),
                            "status": progress_info.status.as_deref().unwrap_or(""),
                            "progress": progress_info.progress.as_deref().unwrap_or(""),
                            "error": progress_info.error.as_deref().unwrap_or(""),
                            "progress_detail": progress_info.progress_detail,
                            "timestamp": chrono::Utc::now().to_rfc3339()
                        });
                        
                        let data_publisher = ApplicationPublisherConfig {
                            id: id.to_string(),
                            status: "pulling".to_string(),
                            step: "pull".to_string(),
                            message: "".to_string(),
                            payload,
                        };
                        
                        let payload = serde_json::to_string(&data_publisher)?;

                        if let Err(e) = mqtt_client.publish_to_topic(topic, payload).await {
                            eprintln!("Failed to publish run progress: {}", e);
                        }

                        last_update = now;
                    }
                }
                Err(e) => {
                    eprintln!("Error during image pull for run_image: {}", e);
                    let data_publisher = ApplicationPublisherConfig {
                        id: id.to_string(),
                        status: "error".to_string(),
                        step: "pull".to_string(),
                        message: e.to_string(),
                        payload: json!({}),
                    };
                    
                    let payload = serde_json::to_string(&data_publisher)?;
                    let _ = mqtt_client.publish_to_topic(topic, payload).await;
                    return Err(e.into());
                }
            }
        }

        Ok(())
    }

    /// Create container with progress updates
    async fn create_container_for_run(
        docker_manager: Docker,
        image: String,
        name: Option<String>,
        envs: Option<HashMap<String, String>>,
        ports: Option<Value>,
        volumes: Option<Value>,
        mqtt_client: Arc<crate::mqtt_client::MqttProgressPublisher>
    ) -> Result<String, anyhow::Error> {
        let create_options = CreateContainerOptions::<String> {
            name: name.clone().unwrap_or_default(),
            ..Default::default()
        };

        let env_vars: Option<Vec<String>> = envs.map(|map| {
            map.into_iter()
                .map(|(k, v)| format!("{}={}", k, v))
                .collect()
        });
    
        let mut exposed_ports: HashMap<String, HashMap<(), ()>> = HashMap::new();
        let mut port_bindings: HashMap<String, Option<Vec<PortBinding>>> = HashMap::new();
            
        if let Some(port_list) = ports {
            if let Some(arr) = port_list.as_array() {
                for port_value in arr {
                    if let Some(port_str) = port_value.as_str() {
                        let parts: Vec<&str> = port_str.split(':').collect();
                        let (host_port, container_port) = match parts.as_slice() {
                            [host, container] => (*host, *container),
                            [single] => (*single, *single),
                            _ => continue,
                        };
        
                        let container_key = format!("{}/tcp", container_port);
        
                        exposed_ports.insert(container_key.clone(), HashMap::new());
                        port_bindings.insert(
                            container_key.clone(),
                            Some(vec![PortBinding {
                                host_ip: Some("0.0.0.0".to_string()),
                                host_port: Some(host_port.to_string()),
                            }]),
                        );
                    }
                }
            }
        }
                let mut binds: Vec<String> = vec![];
            
        if let Some(vol_list) = volumes {
            if let Some(arr) = vol_list.as_array() {
                for v in arr {
                    if let Some(v_str) = v.as_str() {
                        let trimmed = v_str.trim();
                        if trimmed.is_empty() {
                            continue;
                        }
        
                        if !trimmed.contains(':') {
                            // return Err(anyhow!(
                            //     "Invalid volume '{}': must contain ':'",
                            //     trimmed
                            // ));
                        }
        
                        let parts: Vec<&str> = trimmed.split(':').collect();
                        if parts.len() < 2 || parts[0].is_empty() || parts[1].is_empty() {
                            // return Err(anyhow!(
                            //     "Invalid volume '{}': missing host or container path",
                            //     trimmed
                            // ));
                        }
        
                        binds.push(trimmed.to_string());
                    }
                }
            }
        }
                
        let config: Config<String> = Config {
            image: Some(image.clone()),
            env: env_vars,
            exposed_ports: if exposed_ports.is_empty() {
                None
            } else {
                Some(exposed_ports)
            },
            host_config: Some(HostConfig {
                port_bindings: if port_bindings.is_empty() {
                    None
                } else {
                    Some(port_bindings)
                },
                binds: if binds.is_empty() {
                    None
                } else {
                    Some(binds)
                },
                ..Default::default()
            }),
            ..Default::default()
        };

        let container_result = docker_manager.create_container(Some(create_options), config).await;

        match container_result {
            Ok(result) => {
                // Publish container creation success
                let create_success_data = serde_json::json!({
                    "operation": "run_image",
                    "image": image,
                    "phase": "container_created",
                    "container_id": result.id,
                    "name": name,
                    "timestamp": chrono::Utc::now().to_rfc3339()
                });

                let payload = serde_json::to_string(&create_success_data).unwrap_or_default();
                let topic = "device/xzy/applications/response";
                let _ = mqtt_client.publish_to_topic(topic, payload).await;

                Ok(result.id)
            }
            Err(e) => {
                eprintln!("Error creating container: {}", e);
                let error_data = serde_json::json!({
                    "operation": "run_image",
                    "image": image,
                    "phase": "creating_container",
                    "error": e.to_string(),
                    "timestamp": chrono::Utc::now().to_rfc3339()
                });

                let payload = serde_json::to_string(&error_data).unwrap_or_default();
                let topic = "device/xzy/applications/response";
                let _ = mqtt_client.publish_to_topic(topic, payload).await;
                Err(e.into())
            }
        }
    }

    /// Start container with progress updates
    async fn start_container_for_run(
        docker_manager: Docker,
        container_id: String,
        image: String,
        name: Option<String>,
        mqtt_client: Arc<crate::mqtt_client::MqttProgressPublisher>
    ) -> Result<(), anyhow::Error> {
        if let Err(e) = docker_manager.start_container::<String>(&container_id, None).await {
            // eprintln!("Error starting container: {}", e);
            // let error_data = serde_json::json!({
            //     "operation": "run_image",
            //     "image": image,
            //     "phase": "starting_container",
            //     "container_id": container_id,
            //     "error": e.to_string(),
            //     "timestamp": chrono::Utc::now().to_rfc3339()
            // });

            // let payload = serde_json::to_string(&error_data).unwrap_or_default();
            // let topic = "device/xzy/applications/response";
            // let _ = mqtt_client.publish_to_topic(topic, payload).await;
            return Err(e.into());
        }

        Ok(())
    }

    // pub async fn run_image_with_progress_updates(
    //     &self,
    //     topic: &str,
    //     id: &str,
    //     image: &str,
    //     name: Option<&str>,
    //     env_vars: Option<Vec<String>>,
    //     ports: Option<HashMap<String, HashMap<(), ()>>>,
    //     volumes: Option<HashMap<String, HashMap<(), ()>>>,
    //     mqtt_client: Arc<crate::mqtt_client::MqttProgressPublisher>,
    // ) -> Result<String, anyhow::Error> {
    //     let topic = topic.to_string();
    //     let id = id.to_string();
    //     let image = image.to_string();
    //     let name = name.map(|s| s.to_string());
    //     let docker_manager = self.docker.clone();
    //     let mqtt_client_clone = mqtt_client.clone();

    //     task::spawn(async move {
    //         // Step 1: Pull image
    //         if let Err(_) = Self::pull_image_for_run(
    //             docker_manager.clone(),
    //             &topic,
    //             &id,
    //             image.clone(),
    //             name.clone(),
    //             mqtt_client_clone.clone()
    //         ).await {
    //             return; // Error already published
    //         }

    //         // Step 2: Create container
    //         let container_id = match Self::create_container_for_run(
    //             docker_manager.clone(),
    //             image.clone(),
    //             name.clone(),
    //             env_vars,
    //             ports,
    //             volumes,
    //             mqtt_client_clone.clone()
    //         ).await {
    //             Ok(id) => id,
    //             Err(_) => return, // Error already published
    //         };

    //         // Step 3: Start container
    //         if let Err(_) = Self::start_container_for_run(
    //             docker_manager,
    //             container_id.clone(),
    //             image.clone(),
    //             name.clone(),
    //             mqtt_client_clone.clone()
    //         ).await {
    //             return;
    //         }
    //     });

    //     Ok(container_id)
    // }
    pub async fn run_image_with_progress_updates(
        &self,
        topic: &str,
        id: &str,
        image: &str,
        name: Option<&str>,
        envs: Option<HashMap<String, String>>,
        ports: Option<Value>,
        volumes: Option<Value>,
        mqtt_client: Arc<crate::mqtt_client::MqttProgressPublisher>,
    ) -> Result<String, anyhow::Error> {

        let topic = topic.to_string();
        let id = id.to_string();
        let image = image.to_string();
        let name = name.map(|s| s.to_string());
        let docker = self.docker.clone();
        let credential = self.credential.clone();

        // Step 1: Pull image
        Self::pull_image_for_run(
            docker.clone(),
            credential,
            &topic,
            &id,
            image.clone(),
            name.clone(),
            mqtt_client.clone()
        ).await?;
    
        // Step 2: Create container
        let container_id = Self::create_container_for_run(
            docker.clone(),
            image.clone(),
            name.clone(),
            envs,
            ports,
            volumes,
            mqtt_client.clone()
        ).await?;
    
        // Step 3: Start container
        Self::start_container_for_run(
            docker,
            container_id.clone(),
            image,
            name,
            mqtt_client
        ).await?;
    
        // ✅ TRẢ VỀ ĐÚNG
        Ok(container_id)
    }

    pub async fn list_images(&self) -> Result<Vec<bollard::models::ImageSummary>> {
        let options = ListImagesOptions::<String> {
            all: true,
            ..Default::default()
        };

        let images = self.docker.list_images(Some(options)).await?;
        Ok(images)
    }

    pub async fn logs_container(&self, container_id: &str, follow: bool, tail: Option<&str>) -> Result<Vec<String>> {
        let options = LogsOptions::<String> {
            follow,
            tail: tail.map(|s| s.to_string()).unwrap_or_default(),
            stdout: true,
            stderr: true,
            ..Default::default()
        };

        let mut stream = self.docker.logs(container_id, Some(options));
        let mut logs = Vec::new();

        while let Some(result) = stream.next().await {
            match result {
                Ok(LogOutput::StdOut { message }) | Ok(LogOutput::StdErr { message }) => {
                    if let Ok(log_line) = String::from_utf8(message.to_vec()) {
                        logs.push(log_line.trim_end().to_string());
                    }
                }
                Err(e) => return Err(e.into()),
                _ => {}
            }
        }

        Ok(logs)
    }

    pub async fn get_container_info(&self, container_id: &str) -> Result<bollard::models::ContainerInspectResponse> {
        let info = self.docker.inspect_container(container_id, None).await?;
        Ok(info)
    }

    pub async fn list_running_containers(&self) -> Result<Vec<bollard::models::ContainerSummary>> {
        let options = ListContainersOptions::<String> {
            all: false, // Only running containers
            ..Default::default()
        };

        let containers = self.docker.list_containers(Some(options)).await?;
        Ok(containers)
    }

    pub async fn list_all_containers(&self) -> Result<Vec<bollard::models::ContainerSummary>> {
        let options = ListContainersOptions::<String> {
            all: true, // All containers
            ..Default::default()
        };

        let containers = self.docker.list_containers(Some(options)).await?;
        Ok(containers)
    }

    pub async fn list_all_containers2(&self) -> Result<Vec<Value>, Box<dyn std::error::Error + Send + Sync>> {

        let options = ListContainersOptions::<String> {
            all: true, // All containers
            ..Default::default()
        };

        let containers = self.docker.list_containers(Some(options)).await?;

        Ok(containers
            .into_iter()
            .map(|c| {
                serde_json::json!({
                    "id": c.id,
                    "names": c.names,
                    "image": c.image,
                    "image_id": c.image_id,
                    "command": c.command,
                    "created": c.created,
                    "state": c.state,
                    "status": c.status,
                    "ports": c.ports,
                    "labels": c.labels,
                    "size_rw": c.size_rw,
                    "size_root_fs": c.size_root_fs,
                    "host_config": c.host_config,
                    "network_settings": c.network_settings,
                    "mounts": c.mounts,
                })
            })
            .collect())
    }

    pub async fn list_images2(&self) -> Result<Vec<Value>, Box<dyn std::error::Error + Send + Sync>> {
        let options = ListImagesOptions::<String> {
            all: true,
            ..Default::default()
        };

        let images = self.docker.list_images(Some(options)).await?;
        Ok(images
            .into_iter()
            .map(|img| {
                serde_json::json!({
                    "id": img.id,
                    "tags": img.repo_tags,
                    "digests": img.repo_digests,
                    "created": img.created,
                    "size": img.size,
                    "virtual_size": img.virtual_size,
                    "shared_size": img.shared_size,
                    "labels": img.labels,
                    "containers": img.containers,
                    "parent_id": img.parent_id,
                })
            })
            .collect())
    }
    
    pub async fn execute_command(&self, command: DockerCommand) -> DockerResponse {
        match command {
            DockerCommand::Start { container_id } => {
                match self.start_container(&container_id).await {
                    Ok(_) => DockerResponse {
                        success: true,
                        message: format!("Container {} started successfully", container_id),
                        data: None,
                    },
                    Err(e) => DockerResponse {
                        success: false,
                        message: format!("Failed to start container {}: {}", container_id, e),
                        data: None,
                    },
                }
            }

            DockerCommand::Stop { container_id } => {
                match self.stop_container(&container_id).await {
                    Ok(_) => DockerResponse {
                        success: true,
                        message: format!("Container {} stopped successfully", container_id),
                        data: None,
                    },
                    Err(e) => DockerResponse {
                        success: false,
                        message: format!("Failed to stop container {}: {}", container_id, e),
                        data: None,
                    },
                }
            }

            DockerCommand::Restart { container_id } => {
                match self.restart_container(&container_id).await {
                    Ok(_) => DockerResponse {
                        success: true,
                        message: format!("Container {} restarted successfully", container_id),
                        data: None,
                    },
                    Err(e) => DockerResponse {
                        success: false,
                        message: format!("Failed to restart container {}: {}", container_id, e),
                        data: None,
                    },
                }
            }

            DockerCommand::Delete { container_id, force } => {
                match self.delete_container(&container_id, force).await {
                    Ok(_) => DockerResponse {
                        success: true,
                        message: format!("Container {} deleted successfully", container_id),
                        data: None,
                    },
                    Err(e) => DockerResponse {
                        success: false,
                        message: format!("Failed to delete container {}: {}", container_id, e),
                        data: None,
                    },
                }
            }

            DockerCommand::RunImage { image, name } => {
                match self.run_image(&image, name.as_deref(), None).await {
                    Ok(container_id) => DockerResponse {
                        success: true,
                        message: format!("Container {} started from image {}", container_id, image),
                        data: Some(serde_json::json!({ "container_id": container_id })),
                    },
                    Err(e) => DockerResponse {
                        success: false,
                        message: format!("Failed to run image {}: {}", image, e),
                        data: None,
                    },
                }
            }

            DockerCommand::RunImageProgress { id, image, name, envs: _, ports: _, volumes: _ } => {
                // Note: Progress updates will be handled in mqtt_client.rs where we have access to MQTT client
                DockerResponse {
                    success: true,
                    message: format!("Started running image {} with progress updates", image),
                    data: Some(serde_json::json!({ "status": "started", "image": image, "name": name })),
                }
            }

            DockerCommand::PullImage { image } => {
                match self.pull_image(&image).await {
                    Ok(_) => DockerResponse {
                        success: true,
                        message: format!("Image {} pulled successfully", image),
                        data: None,
                    },
                    Err(e) => DockerResponse {
                        success: false,
                        message: format!("Failed to pull image {}: {}", image, e),
                        data: None,
                    },
                }
            }

            DockerCommand::PullImageProgress { image } => {
                // Note: Progress updates will be handled in lib.rs where we have access to MQTT client
                DockerResponse {
                    success: true,
                    message: format!("Started pulling image {} with progress updates", image),
                    data: Some(serde_json::json!({ "status": "started", "image": image })),
                }
            }

            DockerCommand::ListContainers => {
                match self.list_all_containers().await {
                    Ok(containers) => {
                        let data = containers.into_iter()
                            .map(|c| serde_json::json!({
                                "id": c.id,
                                "names": c.names,
                                "image": c.image,
                                "status": c.status,
                                "state": c.state
                            }))
                            .collect::<Vec<_>>();
                        DockerResponse {
                            success: true,
                            message: format!("Found {} containers", data.len()),
                            data: Some(serde_json::Value::Array(data)),
                        }
                    }
                    Err(e) => DockerResponse {
                        success: false,
                        message: format!("Failed to list containers: {}", e),
                        data: None,
                    },
                }
            }

            DockerCommand::ListImages => {
                match self.list_images().await {
                    Ok(images) => {
                        let data = images.into_iter()
                            .map(|i| serde_json::json!({
                                "id": i.id,
                                "repo_tags": i.repo_tags,
                                "size": i.size
                            }))
                            .collect::<Vec<_>>();
                        DockerResponse {
                            success: true,
                            message: format!("Found {} images", data.len()),
                            data: Some(serde_json::Value::Array(data)),
                        }
                    }
                    Err(e) => DockerResponse {
                        success: false,
                        message: format!("Failed to list images: {}", e),
                        data: None,
                    },
                }
            }

            DockerCommand::GetLogs { container_id, tail: _ } => {
                DockerResponse {
                    success: false,
                    message: format!("Logs functionality temporarily disabled for container {}", container_id),
                    data: None,
                }
            }

            DockerCommand::GetInfo { container_id } => {
                match self.get_container_info(&container_id).await {
                    Ok(info) => DockerResponse {
                        success: true,
                        message: format!("Retrieved info for container {}", container_id),
                        data: Some(serde_json::to_value(info).unwrap_or_default()),
                    },
                    Err(e) => DockerResponse {
                        success: false,
                        message: format!("Failed to get info for container {}: {}", container_id, e),
                        data: None,
                    },
                }
            }
        }
    }
}
