#[tokio::main]
async fn main() -> anyhow::Result<()> {
    edge_controller::run().await
}
