use anyhow::Result;
use chrono::Local;
use serde_json::json;
use sysinfo::{System, Components, Disks, Networks};

use crate::hwinfo::get_cpu_info::get_all_cpu_info;
use crate::hwinfo::get_gpu_info::{get_gpu_vendor, get_all_gpu_info};
use crate::hwinfo::get_memory_info::get_all_memory_info;
use crate::hwinfo::get_disk_info::get_all_disk_info;
use crate::hwinfo::get_network_info::{get_primary_interface, get_network_stats};
use crate::hwinfo::get_power_info::get_all_power_info;
use crate::types::SystemMetrics;
use chrono::Utc;
use tokio::sync::Mutex;
use std::sync::Arc;


pub struct TelemetryCollector {
    system: Arc<Mutex<System>>,
    components: Arc<Mutex<Components>>,
    disks: Arc<Mutex<Disks>>,
    networks: Arc<Mutex<Networks>>,
    
}

impl TelemetryCollector {
    pub fn new() -> Result<Self> {
        let system = Arc::new(Mutex::new(System::new_all()));
        let components = Arc::new(Mutex::new(Components::new_with_refreshed_list()));
        let disks = Arc::new(Mutex::new(Disks::new_with_refreshed_list()));
        let mut networks = Arc::new(Mutex::new(Networks::new_with_refreshed_list()));

        Ok(Self {
            system,
            components,
            disks,
            networks
        })
    }

    pub async fn collect(&self) -> anyhow::Result<SystemMetrics> {
        let mut system_instance = self.system.lock().await;
        let mut component_instance = self.components.lock().await;
        let mut disk_instance = self.disks.lock().await;
        let mut network_instance = self.networks.lock().await;
        
        let uptime = System::uptime();
        let timestamp = Local::now();
    
        let cpus = get_all_cpu_info(&mut system_instance, &mut component_instance);
        let memories = get_all_memory_info(&mut system_instance);
        let disks = get_all_disk_info(&mut disk_instance);
    
        let iface = get_primary_interface().unwrap_or_default();
        let network = get_network_stats(&iface, &mut network_instance);
    
        let gpus_vendor = get_gpu_vendor();
        let vendor = gpus_vendor
            .first()
            .map(|v| match v.to_lowercase().as_str() {
                "jepack" => "tegrastats",
                "nvidia" => "nvidia",
                "amd" => "rocm",
                _ => "unknown",
            })
            .unwrap_or("unknown");
    
        let gpus = get_all_gpu_info(vendor);
        let power = get_all_power_info();
    
        Ok(SystemMetrics {
            cpus,
            gpus,
            memories,
            disks,
            network,
            power,
            uptime,
            timestamp: Utc::now(),
        })
    }

}
