use serde::{Deserialize, Serialize};
use std::path::Path;
use tokio::fs;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Config {
    pub monitoring: MonitoringConfig,
    pub mqtt: MqttConfig,
    pub alerting: AlertingConfig,
    pub docker: DockerConfig,
    pub ssh: SSHConfig,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SSHConfig {
    pub local_ssh_port: u16,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MonitoringConfig {
    pub interval_seconds: u64,
    pub enable_gpu: bool,
    pub enable_power: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MqttConfig {
    pub broker: String,
    pub port: u16,
    pub client_id: String,
    pub username: Option<String>,
    pub password: Option<String>,
    pub default_topic: String,
    pub telemetry_topic: String,
    pub alert_topic: String,
    pub docker_info_topic: String,
    pub command_topic: String,
    pub operator_topic: String,
    pub ssh_topic: String,
    pub qos: u8,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AlertingConfig {
    pub cpu_threshold_percent: f32,
    pub memory_threshold_percent: f32,
    pub alert_cooldown_seconds: u64,
    pub sustained_alert_seconds: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DockerConfig {
    pub socket_path: String,
    pub enable_container_monitoring: bool,
    pub username: String,
    pub password: String,
    pub store_url: String,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            monitoring: MonitoringConfig {
                interval_seconds: 30,
                enable_gpu: true,
                enable_power: true,
            },
            mqtt: MqttConfig {
                broker: "localhost".to_string(),
                port: 1883,
                client_id: "edge-controller".to_string(),
                username: None,
                password: None,
                default_topic: "device".to_string(),
                telemetry_topic: "telemetry/system".to_string(),
                alert_topic: "alerts/system".to_string(),
                docker_info_topic: "telemetry/containers".to_string(),
                command_topic: "commands/docker".to_string(),
                operator_topic: "operators".to_string(),
                ssh_topic: "commands/ssh".to_string(),
                qos: 1,
            },
            alerting: AlertingConfig {
                cpu_threshold_percent: 80.0,
                memory_threshold_percent: 85.0,
                alert_cooldown_seconds: 300, // 5 minutes
                sustained_alert_seconds: 60, // Alert after 60 seconds of sustained high usage
            },
            docker: DockerConfig {
                socket_path: "/var/run/docker.sock".to_string(),
                enable_container_monitoring: true,
                username: "".to_string(),
                password: "".to_string(),
                store_url: "".to_string(),
            },
            ssh: SSHConfig {
                local_ssh_port: 22,
            },
        }
    }
}

impl Config {
    pub async fn load<P: AsRef<Path>>(path: P) -> anyhow::Result<Self> {
        let path = path.as_ref();

        if path.exists() {
            let contents = fs::read_to_string(path).await?;
            let config: Config = toml::from_str(&contents)?;
            Ok(config)
        } else {
            let config = Self::default();
            let toml_string = toml::to_string_pretty(&config)?;
            fs::write(path, toml_string).await?;
            tracing::info!("Created default configuration file at {:?}", path);
            Ok(config)
        }
    }
}
