use crate::types::{Alert, AlertType, SystemMetrics};
use crate::config::{AlertingConfig, Config};
use chrono::{DateTime, Utc};
use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::Mutex;

#[derive(Debug, Clone)]
struct AlertState {
    last_alert_time: Option<DateTime<Utc>>,
    sustained_high_start: Option<DateTime<Utc>>,
    is_currently_high: bool,
}

pub struct AlertManager {
    config: AlertingConfig,
    alert_states: Arc<Mutex<HashMap<AlertType, AlertState>>>,
}

impl AlertManager {
    pub fn new(config: AlertingConfig) -> Self {
        Self {
            config,
            alert_states: Arc::new(Mutex::new(HashMap::new())),
        }
    }

    pub async fn check_alerts(&self, metrics: &SystemMetrics, config: &Config) -> Option<Alert> {
        let mut states = self.alert_states.lock().await;

        // Check CPU usage
        if let Some(cpu_alert) = self.check_cpu_alert(&mut states, metrics) {
            return Some(cpu_alert);
        }

        // Check memory usage
        if let Some(memory_alert) = self.check_memory_alert(&mut states, metrics) {
            return Some(memory_alert);
        }

        None
    }

    fn check_cpu_alert(
        &self,
        states: &mut HashMap<AlertType, AlertState>,
        metrics: &SystemMetrics
    ) -> Option<Alert> {
        let alert_type = AlertType::CpuUsage;
        let cpu = &metrics.cpus[0];
        let current_value = cpu.avg_usage;
        let threshold = self.config.cpu_threshold_percent;

        self.check_threshold_alert(
            states,
            alert_type,
            current_value,
            threshold,
            &format!("CPU usage is {:.1}% (threshold: {:.1}%)", current_value, threshold)
        )
    }

    fn check_memory_alert(
        &self,
        states: &mut HashMap<AlertType, AlertState>,
        metrics: &SystemMetrics
    ) -> Option<Alert> {
        let alert_type = AlertType::MemoryUsage;
        let current_value = metrics.memories.percent;
        let threshold = self.config.memory_threshold_percent;

        self.check_threshold_alert(
            states,
            alert_type,
            current_value,
            threshold,
            &format!("Memory usage is {:.1}% (threshold: {:.1}%)", current_value, threshold)
        )
    }

    fn check_threshold_alert(
        &self,
        states: &mut HashMap<AlertType, AlertState>,
        alert_type: AlertType,
        current_value: f32,
        threshold: f32,
        message: &str
    ) -> Option<Alert> {
        let now = Utc::now();
        let state = states.entry(alert_type.clone()).or_insert(AlertState {
            last_alert_time: None,
            sustained_high_start: None,
            is_currently_high: false,
        });

        let is_high = current_value >= threshold;

        if is_high {
            if !state.is_currently_high {
                // Just started being high
                state.sustained_high_start = Some(now);
                state.is_currently_high = true;
            } else if let Some(start_time) = state.sustained_high_start {
                // Check if sustained long enough
                let sustained_duration = now.signed_duration_since(start_time);
                let sustained_seconds = sustained_duration.num_seconds() as u64;

                if sustained_seconds >= self.config.sustained_alert_seconds {
                    // Check cooldown
                    let should_alert = if let Some(last_alert) = state.last_alert_time {
                        let cooldown_duration = now.signed_duration_since(last_alert);
                        let cooldown_seconds = cooldown_duration.num_seconds() as u64;
                        cooldown_seconds >= self.config.alert_cooldown_seconds
                    } else {
                        true // First alert
                    };

                    if should_alert {
                        state.last_alert_time = Some(now);
                        return Some(Alert {
                            alert_type,
                            message: message.to_string(),
                            value: current_value,
                            threshold,
                            timestamp: now,
                        });
                    }
                }
            }
        } else {
            // Reset state when no longer high
            state.is_currently_high = false;
            state.sustained_high_start = None;
        }

        None
    }

    pub async fn get_alert_states(&self) -> HashMap<AlertType, AlertState> {
        self.alert_states.lock().await.clone()
    }

    pub async fn reset_alert_state(&self, alert_type: &AlertType) {
        let mut states = self.alert_states.lock().await;
        states.remove(alert_type);
    }
}
