use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use crate::hwinfo::get_cpu_info::CpuInfo;
use crate::hwinfo::gpu::gpu_model::GpuInfo;
use crate::hwinfo::get_memory_info::MemoryInfo;
use crate::hwinfo::get_disk_info::DiskInfo;
use crate::hwinfo::get_network_info::NetworkInfo;
use crate::hwinfo::get_power_info::PowerInfo;


#[derive(Debug, Serialize)]
pub struct SystemMetrics {
    pub cpus: Vec<CpuInfo>,
    pub gpus: Vec<GpuInfo>,
    pub memories: MemoryInfo,
    pub disks: Vec<DiskInfo>,
    pub network: Vec<NetworkInfo>,
    pub power: PowerInfo,
    pub uptime: u64,
    pub timestamp: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Alert {
    pub alert_type: AlertType,
    pub message: String,
    pub value: f32,
    pub threshold: f32,
    pub timestamp: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Eq, Hash, PartialEq)]
pub enum AlertType {
    CpuUsage,
    MemoryUsage,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ContainerStats {
    pub id: String,
    pub name: String,
    pub image: String,
    pub status: String,
    pub cpu_percent: f64,
    pub memory_usage: u64,
    pub memory_limit: u64,
    pub memory_percent: f64,
    pub network_rx: u64,
    pub network_tx: u64,
    pub block_read: u64,
    pub block_write: u64,
    pub timestamp: DateTime<Utc>,
}


#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SSHResponse {
    pub success: bool,
    pub message: String,
    pub data: Option<serde_json::Value>,
}