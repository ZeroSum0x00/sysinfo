                                match serde_json::from_slice::<DockerCommand>(&publish.payload) {
                                    Ok(command) => {
                                        info!("Executing Docker command: {:?}", command);
                                        

                                        if let DockerCommand::PullImageProgress { ref image } = command {
                                            let image_clone = image.clone();
                                            // Create a MqttClient instance for progress updates
                                            let mqtt_client = Arc::new(Mutex::new(MqttClient {
                                                client: client_clone.clone(),
                                                default_topic: format!("{}/{}", config_clone.default_topic.clone(), client_id_clone),
                                                telemetry_topic: config_clone.telemetry_topic.clone(),
                                                alert_topic: config_clone.alert_topic.clone(),
                                                container_topic: config_clone.container_topic.clone(),
                                                command_topic: config_clone.command_topic.clone(),
                                                response_topic: config_clone.response_topic.clone(),
                                                qos: qos_clone,
                                                docker_manager: None, // Not needed for publishing
                                            }));

                                            let docker_mgr = docker_mgr.clone();
                                            let image_for_task = image.clone();
                                            tokio::spawn(async move {
                                                docker_mgr.lock().await.pull_image_with_progress_updates(&image_for_task, mqtt_client).await;
                                            });

                                            // Send immediate response
                                            let response = DockerResponse {
                                                success: true,
                                                message: format!("Started pulling image {} with progress updates", image),
                                                data: Some(serde_json::json!({ "status": "started", "image": image_clone })),
                                            };

                                            if let Ok(response_json) = serde_json::to_string(&response) {
                                                let _ = client_clone.publish(&response_topic_clone, qos_clone, false, response_json).await;
                                            }
                                        } else if let DockerCommand::RunImageProgress { ref image, ref name } = command {
                                            // For now, handle as regular RunImage command
                                            let docker_mgr_locked = docker_mgr.lock().await;
                                            let response = docker_mgr_locked.run_image(&image, name.as_deref(), None).await;

                                            // Convert response to serializable format
                                            let serializable_response = match &response {
                                                Ok(container_id) => DockerResponse {
                                                    success: true,
                                                    message: format!("Container {} started from image {}", container_id, image),
                                                    data: Some(serde_json::json!({ "container_id": container_id })),
                                                },
                                                Err(e) => DockerResponse {
                                                    success: false,
                                                    message: format!("Failed to run image {}: {}", image, e),
                                                    data: None,
                                                }
                                            };

                                            // Publish response
                                            if let Ok(response_json) = serde_json::to_string(&serializable_response) {
                                                let _ = client_clone.publish(&response_topic_clone, qos_clone, false, response_json).await;
                                            }
                                        } else {
                                            // Handle other commands normally
                                            let docker_mgr_locked = docker_mgr.lock().await;
                                            let response = docker_mgr_locked.execute_command(command).await;

                                            // Publish response
                                            if let Ok(response_json) = serde_json::to_string(&response) {
                                                let _ = client_clone.publish(&response_topic_clone, qos_clone, false, response_json).await;
                                            }
                                        }
                                    }
                                    Err(e) => {
                                        error!("Failed to parse Docker command: {}", e);
                                        let error_response = DockerResponse {
                                            success: false,
                                            message: format!("Invalid command format: {}", e),
                                            data: None,
                                        };
                                        if let Ok(response_json) = serde_json::to_string(&error_response) {
                                            let _ = client_clone.publish(&response_topic_clone, qos_clone, false, response_json).await;
                                        }
                                    }
                                }