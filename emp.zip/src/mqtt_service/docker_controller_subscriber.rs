use std::thread;
use std::time::Duration;
use serde_json::json;
use std::sync::{Arc, Mutex};
use serde_json::Value;

use crate::mqtt_service::mqtt_handler::MqttHandler;
use bollard::Docker;
use crate::docker_controller::image_action::{pull_image, run_image};
use crate::docker_controller::container_controller::{start_container, inspect_container_status, stop_container, delete_container};
use bollard::auth::DockerCredentials;


use std::collections::HashMap;
use log::{info, error};


struct MQTTDataOperatorPublisherConfig {
    _type: String,
    container_id: String,
    state: String,
    status: String,
    message: String,
}


async fn operator_publish(
    mqtt: &Arc<Mutex<MqttHandler>>,
    topic: &str,
    data_publisher: MQTTDataOperatorPublisherConfig,
    qos: u8,
) {
    let MQTTDataOperatorPublisherConfig {
        _type,
        container_id,
        state,
        status,
        message,
    } = data_publisher;

    let payload = json!({
        "type": _type,
        "container_id": container_id,
        "state": state,
        "status": status,
        "message": message
    });
    
    if let Ok(mut client) = mqtt.lock() {
        let _ = client.publisher(Some(topic), &payload, qos);
    }
}


struct MQTTDataApplicationPublisherConfig {
    container_id: String,
    status: String,
    step: String,
    message: String,
    payload: Value,
}
    

async fn application_publish(
    mqtt: &Arc<Mutex<MqttHandler>>,
    topic: &str,
    data_publisher: MQTTDataApplicationPublisherConfig,
    qos: u8,
) {
    
    let MQTTDataApplicationPublisherConfig {
        container_id,
        status,
        step,
        message,
        payload,
    } = data_publisher;

    let publish_payload = json!({
        "id": container_id,
        "status": status,
        "step": step,
        "message": message,
        "payload": payload,
    });
    
    if let Ok(mut client) = mqtt.lock() {
        let _ = client.publisher(Some(topic), &publish_payload, qos);
    }
}


pub struct DockerControllerSubscriberMQTTConfig {
    pub mqtt: Arc<Mutex<MqttHandler>>,
    pub topic_sub_applications: String,
    pub topic_pub_applications: String,
    pub topic_sub_operator: String,
    pub topic_pub_operator: String,
    pub qos: u8,
}


pub async fn docker_controller_subscriber(
    docker: &mut Docker,
    docker_credential: DockerCredentials,
    mqtt_config: DockerControllerSubscriberMQTTConfig,
    refresh_time: f32,
) {

    let DockerControllerSubscriberMQTTConfig {
        mqtt,
        topic_sub_applications,
        topic_pub_applications,
        topic_sub_operator,
        topic_pub_operator,
        qos,
    } = mqtt_config;

    {
        let mut client = mqtt.lock().unwrap();
        client.subscriber(&topic_sub_applications, 1).unwrap();
        client.subscriber(&topic_sub_operator, 1).unwrap();
    }
    
    loop {
        let messages = {
            let client = mqtt.lock().unwrap();
            client.drain_messages()
        };
        
        for (topic, payload) in messages {
            info!("Subscriber successfully with topic: {:?}", topic);
            
            let data_receive: Value = serde_json::from_str(&payload).unwrap();
            let receive_type = data_receive["type"].as_str().unwrap_or("");
            
            if topic == topic_sub_applications {
                
                if receive_type == "RUN_APPLICATION" || receive_type == "UPGRADE_APPLICATION" {
                    let payload_list: Vec<serde_json::Value> = data_receive
                        .get("payload")
                        .and_then(|v| v.as_array())
                        .cloned()
                        .unwrap_or_default();
                    
                    for payload in payload_list {
                        let session_id = payload
                            .get("id")
                            .and_then(|v| v.as_str())
                            .unwrap_or("")
                            .to_string();
                        
                        let resource_name = payload
                            .get("resource_name")
                            .and_then(|v| v.as_str())
                            .unwrap_or("")
                            .to_string();

                        let env_obj = payload.get("envs").and_then(|v| v.as_object());
                        let env_map: Option<HashMap<String, String>> = env_obj.map(|map| {
                            map.iter()
                                .map(|(key, val)| {
                                    let value = val.as_str()
                                        .map(|s| s.to_string())
                                        .unwrap_or_else(|| val.to_string());
                                    (key.clone(), value)
                                })
                                .collect::<HashMap<String, String>>()
                        });

                        let volume_list = payload.get("volumes").and_then(|v| v.as_array());
                        
                        let ports_list = payload.get("ports").and_then(|v| v.as_array());
                        
                        let mut rx = pull_image(docker, docker_credential.clone(), resource_name.clone()).await;
                        while let Some(info) = rx.recv().await {
                            let payload = json!({
                                "process_id": info.id.as_deref().unwrap_or(""),
                                "status": info.status.as_deref().unwrap_or(""),
                                "progress": info.progress.as_deref().unwrap_or(""),
                                "error": info.error.as_deref().unwrap_or(""),
                                "progress_detail": info.progress_detail
                            });

                            let data_publisher = MQTTDataApplicationPublisherConfig {
                                container_id: session_id.to_string(),
                                status: "pulling".to_string(),
                                step: "pull".to_string(),
                                message: "".to_string(),
                                payload,
                            };

                            application_publish(
                                &mqtt,
                                &topic_pub_applications,
                                data_publisher,
                                qos
                            ).await;
                            thread::sleep(Duration::from_secs_f32(0.2));
                        }
                        
                        if receive_type == "RUN_APPLICATION" {
                            match run_image(docker, "".to_string(), resource_name.clone(), "".to_string(), env_map, ports_list, volume_list).await {
                                Ok(result) => {
                                    let payload = json!({
                                        "container_id": result
                                            .get("current_id")
                                            .map(|s| s.as_str())
                                            .unwrap_or("unknown"),
                                        "status": result
                                            .get("status")
                                            .map(|s| s.as_str())
                                            .unwrap_or("unknown"),
                                    });
                                    
                                    let data_publisher = MQTTDataApplicationPublisherConfig {
                                        container_id: session_id.to_string(),
                                        status: "successfully".to_string(),
                                        step: "run".to_string(),
                                        message: "".to_string(),
                                        payload,
                                    };
                                    
                                    application_publish(
                                        &mqtt,
                                        &topic_pub_applications,
                                        data_publisher,
                                        qos
                                    ).await;
                                    info!("Container created and started: {:?}", result);
                                    
                                }
                                Err(e) => {
                                    let data_publisher = MQTTDataApplicationPublisherConfig {
                                        container_id: session_id.to_string(),
                                        status: "failed".to_string(),
                                        step: "run".to_string(),
                                        message: e.to_string(),
                                        payload: json!({}),
                                    };
                                    
                                    application_publish(
                                        &mqtt,
                                        &topic_pub_applications,
                                        data_publisher,
                                        qos
                                    ).await;
                                    error!("Failed to run resource_name: {:?}", e);
                                }
                            }
                        } 
                        else {
                            let container_id = payload
                                .get("container_id")
                                .and_then(|v| v.as_str())
                                .unwrap_or("")
                                .to_string();
                            
                            if container_id.trim().is_empty() {
                                error!("Cant'n find container_id fiel in payload");
                                continue;
                            }
                            
                            match run_image(docker, "".to_string(), resource_name.clone(), container_id.clone(), env_map, ports_list, volume_list).await {
                                Ok(result) => {
                                    info!("Container created and started: {:?}", result);
                                    let payload = json!({
                                        "container_id": result
                                            .get("current_id")
                                            .map(|s| s.as_str())
                                            .unwrap_or("unknown"),
                                        "status": result
                                            .get("status")
                                            .map(|s| s.as_str())
                                            .unwrap_or("unknown"),
                                    });

                                    let data_publisher = MQTTDataApplicationPublisherConfig {
                                        container_id: session_id.to_string(),
                                        status: "successfully".to_string(),
                                        step: "upgrade".to_string(),
                                        message: "".to_string(),
                                        payload,
                                    };
                                    
                                    application_publish(
                                        &mqtt,
                                        &topic_pub_applications,
                                        data_publisher,
                                        qos
                                    ).await;
                                }
                                Err(e) => {
                                    let data_publisher = MQTTDataApplicationPublisherConfig {
                                        container_id: session_id.to_string(),
                                        status: "failed".to_string(),
                                        step: "upgrade".to_string(),
                                        message: e.to_string(),
                                        payload: json!({}),
                                    };
                                    
                                    application_publish(
                                        &mqtt,
                                        &topic_pub_applications,
                                        data_publisher,
                                        qos
                                    ).await;
                                    error!("Failed to run resource_name: {:?}", e);
                                }
                            }
                        }
                    }
                }
            } else if topic == topic_sub_operator {
                let container_ids: Vec<serde_json::Value> = data_receive
                    .get("container_ids")
                    .and_then(|v| v.as_array())
                    .cloned()
                    .unwrap_or_default();
                
                if receive_type == "START_APPLICATION" {
                    for container_id in container_ids {
                        if let Some(container_id_value) = container_id.as_str() {
                            match inspect_container_status(docker, container_id_value).await {
                                Ok(_) => {
                                    match start_container(docker, container_id_value).await {
                                        Ok(_) => {
                                            let state = inspect_container_status(docker, container_id_value).await;
                                            let data_publisher = MQTTDataOperatorPublisherConfig {
                                                _type: receive_type.to_string(),
                                                container_id: container_id.as_str().unwrap_or_default().to_string(),
                                                state: state.unwrap().to_string(),
                                                status: "successfully".to_string(),
                                                message: "".to_string()
                                            };
                                            
                                            operator_publish(
                                                &mqtt,
                                                &topic_pub_operator,
                                                data_publisher,
                                                qos
                                            ).await;
                                            info!("Start success id {:?}", container_id_value);
                                        }
                                        Err(e) => {
                                            let state = inspect_container_status(docker, container_id_value).await;
                                            let data_publisher = MQTTDataOperatorPublisherConfig {
                                                _type: receive_type.to_string(),
                                                container_id: container_id.as_str().unwrap_or_default().to_string(),
                                                state: state.unwrap().to_string(),
                                                status: "failed".to_string(),
                                                message: e.to_string(),
                                            };
                                            
                                            operator_publish(
                                                &mqtt,
                                                &topic_pub_operator,
                                                data_publisher,
                                                qos
                                            ).await;
                                            error!("Start failed id {:?}", container_id_value);
                                        }
                                    }
                                }
                                Err(e) => {
                                    let data_publisher = MQTTDataOperatorPublisherConfig {
                                        _type: receive_type.to_string(),
                                        container_id: container_id.as_str().unwrap_or_default().to_string(),
                                        state: "".to_string(),
                                        status: "failed".to_string(),
                                        message: format!("Container with ID '{}' not found", container_id.as_str().unwrap_or_default()),
                                    };
                                    operator_publish(
                                        &mqtt,
                                        &topic_pub_operator,
                                        data_publisher,
                                        qos
                                    ).await;
                                    error!("❌ Failed to inspect container {}: {:?}", container_id_value, e);
                                }
                            }
                        }
                    }
                } else if receive_type == "STOP_APPLICATION" {
                    for container_id in container_ids {
                        if let Some(container_id_value) = container_id.as_str() {
                            match inspect_container_status(docker, container_id_value).await {
                                Ok(_) => {
                                    match stop_container(docker, container_id_value).await {
                                        Ok(_) => {
                                            let state = inspect_container_status(docker, container_id_value).await;
                                            let data_publisher = MQTTDataOperatorPublisherConfig {
                                                _type: receive_type.to_string(),
                                                container_id: container_id.as_str().unwrap_or_default().to_string(),
                                                state: state.unwrap().to_string(),
                                                status: "successfully".to_string(),
                                                message: "".to_string()
                                            };
                                            
                                            operator_publish(
                                                &mqtt,
                                                &topic_pub_operator,
                                                data_publisher,
                                                qos
                                            ).await;
                                            info!("Stop success id {:?}", container_id_value);
                                        }
                                        Err(e) => {
                                            let state = inspect_container_status(docker, container_id_value).await;
                                            let data_publisher = MQTTDataOperatorPublisherConfig {
                                                _type: receive_type.to_string(),
                                                container_id: container_id.as_str().unwrap_or_default().to_string(),
                                                state: state.unwrap().to_string(),
                                                status: "failed".to_string(),
                                                message: e.to_string(),
                                            };
                                            
                                            operator_publish(
                                                &mqtt,
                                                &topic_pub_operator,
                                                data_publisher,
                                                qos
                                            ).await;
                                            error!("Stop failed id {:?}", container_id_value);
                                        }
                                    }
                                }
                                Err(e) => {
                                    let data_publisher = MQTTDataOperatorPublisherConfig {
                                        _type: receive_type.to_string(),
                                        container_id: container_id.as_str().unwrap_or_default().to_string(),
                                        state: "".to_string(),
                                        status: "failed".to_string(),
                                        message: format!("Container with ID '{}' not found", container_id.as_str().unwrap_or_default()),
                                    };
                                    operator_publish(
                                        &mqtt,
                                        &topic_pub_operator,
                                        data_publisher,
                                        qos
                                    ).await;
                                    error!("Failed to inspect container {}: {:?}", container_id_value, e);
                                }
                            }
                        }
                    }
                } else if receive_type == "DELETE_APPLICATION" {
                    for container_id in container_ids {
                        if let Some(container_id_value) = container_id.as_str() {
                            match inspect_container_status(docker, container_id_value).await {
                                Ok(_) => {
                                    match delete_container(docker, container_id_value).await {
                                        Ok(_) => {
                                            let state = inspect_container_status(docker, container_id_value).await.unwrap_or_else(|_| "deleted".to_string());
                                            let data_publisher = MQTTDataOperatorPublisherConfig {
                                                _type: receive_type.to_string(),
                                                container_id: container_id_value.to_string(),
                                                state,
                                                status: "successfully".to_string(),
                                                message: "".to_string()
                                            };
                                            
                                            operator_publish(
                                                &mqtt,
                                                &topic_pub_operator,
                                                data_publisher,
                                                qos
                                            ).await;
                                        }
                                        Err(e) => {
                                            let state = inspect_container_status(docker, container_id_value).await.unwrap_or_else(|_| "not_found".to_string());

                                            let data_publisher = MQTTDataOperatorPublisherConfig {
                                                _type: receive_type.to_string(),
                                                container_id: container_id_value.to_string(),
                                                state,
                                                status: "failed".to_string(),
                                                message: e.to_string(),
                                            };
                                            
                                            operator_publish(
                                                &mqtt,
                                                &topic_pub_operator,
                                                data_publisher,
                                                qos
                                            ).await;
                                        }
                                    }
                                }
                                Err(e) => {
                                    let data_publisher = MQTTDataOperatorPublisherConfig {
                                        _type: receive_type.to_string(),
                                        container_id: container_id.as_str().unwrap_or_default().to_string(),
                                        state: "".to_string(),
                                        status: "failed".to_string(),
                                        message: format!("Container with ID '{}' not found", container_id.as_str().unwrap_or_default()),
                                    };
                                    operator_publish(
                                        &mqtt,
                                        &topic_pub_operator,
                                        data_publisher,
                                        qos
                                    ).await;
                                    error!("Failed to inspect container {}: {:?}", container_id_value, e);
                                }
                            }
                        }
                    }
                } else if receive_type == "RESTART_APPLICATION" {
                    for container_id in container_ids {
                        if let Some(container_id_value) = container_id.as_str() {
                            match inspect_container_status(docker, container_id_value).await {
                                Ok(_) => {
                                    match stop_container(docker, container_id_value).await {
                                        Ok(_) => {
                                            let state = inspect_container_status(docker, container_id_value).await;
                                            let data_publisher = MQTTDataOperatorPublisherConfig {
                                                _type: receive_type.to_string(),
                                                container_id: container_id.as_str().unwrap_or_default().to_string(),
                                                state: state.unwrap().to_string(),
                                                status: "successfully".to_string(),
                                                message: "".to_string()
                                            };
                                            
                                            operator_publish(
                                                &mqtt,
                                                &topic_pub_operator,
                                                data_publisher,
                                                qos
                                            ).await;
                                            info!("Stop success id {:?}", container_id_value);
                                        }
                                        Err(e) => {
                                            let state = inspect_container_status(docker, container_id_value).await;
                                            let data_publisher = MQTTDataOperatorPublisherConfig {
                                                _type: receive_type.to_string(),
                                                container_id: container_id.as_str().unwrap_or_default().to_string(),
                                                state: state.unwrap().to_string(),
                                                status: "failed".to_string(),
                                                message: e.to_string(),
                                            };
                                            operator_publish(
                                                &mqtt,
                                                &topic_pub_operator,
                                                data_publisher,
                                                qos
                                            ).await;
                                            error!("Stop failed id {:?}", container_id_value);
                                        }
                                    }

                                    match start_container(docker, container_id_value).await {
                                        Ok(_) => {
                                            let state = inspect_container_status(docker, container_id_value).await;
                                            let data_publisher = MQTTDataOperatorPublisherConfig {
                                                _type: receive_type.to_string(),
                                                container_id: container_id.as_str().unwrap_or_default().to_string(),
                                                state: state.unwrap().to_string(),
                                                status: "successfully".to_string(),
                                                message: "".to_string()
                                            };
                                            
                                            operator_publish(
                                                &mqtt,
                                                &topic_pub_operator,
                                                data_publisher,
                                                qos
                                            ).await;
                                            info!("Start success id {:?}", container_id_value);
                                        }
                                        Err(e) => {
                                            let state = inspect_container_status(docker, container_id_value).await;
                                            let data_publisher = MQTTDataOperatorPublisherConfig {
                                                _type: receive_type.to_string(),
                                                container_id: container_id.as_str().unwrap_or_default().to_string(),
                                                state: state.unwrap().to_string(),
                                                status: "failed".to_string(),
                                                message: e.to_string(),
                                            };
                                            operator_publish(
                                                &mqtt,
                                                &topic_pub_operator,
                                                data_publisher,
                                                qos
                                            ).await;
                                            error!("Start failed id {:?}", container_id_value);
                                        }
                                    }
                                }
                                Err(e) => {
                                    let data_publisher = MQTTDataOperatorPublisherConfig {
                                        _type: receive_type.to_string(),
                                        container_id: container_id.as_str().unwrap_or_default().to_string(),
                                        state: "".to_string(),
                                        status: "failed".to_string(),
                                        message: format!("Container with ID '{}' not found", container_id.as_str().unwrap_or_default()),
                                    };
                                    operator_publish(
                                        &mqtt,
                                        &topic_pub_operator,
                                        data_publisher,
                                        qos
                                    ).await;
                                    error!("Failed to inspect container {}: {:?}", container_id_value, e);
                                }
                            }
                        }
                    }                    
                }
            }
        }

        thread::sleep(Duration::from_secs_f32(refresh_time));
    }
}
