use serde_json::json;
use std::{
    sync::Arc,
};
use bollard::Docker;
use tokio::sync::Mutex;

use crate::mqtt_service::mqtt_handler::MqttHandler;
use crate::mqtt_service::telemetry_publisher::mqtt_publish;
use crate::docker_controller::container_controller::list_containers;
use crate::docker_controller::image_action::list_images;
use tracing::error;



pub struct DockerInfoPublisherConfig {
    pub mqtt: Arc<Mutex<MqttHandler>>,
    pub device_id: String,
    pub topic_pub_docker_info: String,
    pub qos: u8,
}


pub async fn docker_info_publisher(
    docker: &mut Docker,
    mqtt_config: &DockerInfoPublisherConfig,
) {
    let DockerInfoPublisherConfig {
        mqtt,
        device_id,
        topic_pub_docker_info,
        qos,
    } = mqtt_config;
    
    let mut my_list_containers = Vec::new();
    let mut my_list_images = Vec::new();
    
    match list_containers(docker).await {
        Ok(containers) => {
            for container in containers {
                let filtered = serde_json::json!({
                    "id": container.get("id").cloned().unwrap_or_default(),
                    "state": container.get("state").cloned().unwrap_or_default(),
                    "status": container.get("status").cloned().unwrap_or_default(),
                });
                my_list_containers.push(filtered);
            }

        }
        Err(e) => {
            error!("Running failed id {:?}", e);
        }
    }

    match list_images(docker).await {
        Ok(images) => {
            for image in images {
                let filtered = serde_json::json!({
                    "id": image.get("id").cloned().unwrap_or_default(),
                    "tags": image.get("tags").cloned().unwrap_or_default(),
                });
                my_list_images.push(filtered);
            }
        }
        Err(e) => {
            error!("Running failed {:?}", e);
        }
    }
    
    let docker_info_payload = json!({
        "device_id": device_id,
        "containers": my_list_containers,
        "images": my_list_images,
    });

    mqtt_publish(mqtt, topic_pub_docker_info, &docker_info_payload, *qos).await;
}
