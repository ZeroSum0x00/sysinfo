use std::thread;
use serde_json::json;
use std::{
    sync::{Arc, Mutex},
    time::Duration,
};
use bollard::Docker;

use crate::mqtt_service::mqtt_handler::MqttHandler;
use crate::docker_controller::container_controller::list_containers;
use crate::docker_controller::image_action::list_images;
use tracing::error;



pub async fn docker_info_publisher(
    mqtt: Arc<Mutex<MqttHandler>>,
    docker: &mut Docker,
    device_id: String,
    topic_pub_docker_info: String,
    refresh_time: f32,
) {

    loop {
        let mut my_list_containers = Vec::new();
        let mut my_list_images = Vec::new();
        
        match list_containers(docker).await {
            Ok(containers) => {
                for container in containers {
                    let filtered = serde_json::json!({
                        "id": container.get("id").cloned().unwrap_or_default(),
                        "state": container.get("state").cloned().unwrap_or_default(),
                        "status": container.get("status").cloned().unwrap_or_default(),
                    });
                    my_list_containers.push(filtered);
                }

            }
            Err(e) => {
                error!("Running failed id {:?}", e);
            }
        }

        match list_images(docker).await {
            Ok(images) => {
                for image in images {
                    let filtered = serde_json::json!({
                        "id": image.get("id").cloned().unwrap_or_default(),
                        "tags": image.get("tags").cloned().unwrap_or_default(),
                    });
                    my_list_images.push(filtered);
                }
            }
            Err(e) => {
                error!("Running failed {:?}", e);
            }
        }
        
        let docker_info_payload = json!({
            "device_id": device_id,
            "containers": my_list_containers,
            "images": my_list_images,
        });
        
        if let Ok(mut client) = mqtt.lock() {
            let _ = client.publisher(Some(&topic_pub_docker_info), &docker_info_payload, 1);
        }
        
        thread::sleep(Duration::from_secs_f32(refresh_time));
    }
}
