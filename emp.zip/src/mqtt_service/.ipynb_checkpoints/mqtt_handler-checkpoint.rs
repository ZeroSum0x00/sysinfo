use serde_json::Value;
use std::time::Duration;
use std::sync::{Arc, Mutex};
use rumqttc::{Client, Event, MqttOptions, Packet, QoS};
use log::error;

pub struct MqttHandler {
    client: Client,
    default_topic: String,
    messages: Arc<Mutex<Vec<(String, String)>>>,
}

impl MqttHandler {
    pub fn new(
        host: &str,
        port: u16,
        client_id: &str,
        default_topic: &str,
        username: Option<&str>,
        password: Option<&str>,
    ) -> Self {
        let mut options = MqttOptions::new(client_id, host, port);
        options.set_keep_alive(Duration::from_secs(30));

        if let (Some(user), Some(pass)) = (username, password) {
            options.set_credentials(user, pass);
        }

        let (client, mut connection) = Client::new(options, 10);
        let messages = Arc::new(Mutex::new(Vec::new()));
        let msg_ref = messages.clone();

        std::thread::spawn(move || {
            for notification in connection.iter() {
                match notification {
                    Ok(Event::Incoming(Packet::Publish(p))) => {
                        let payload = String::from_utf8_lossy(&p.payload).to_string();
                        if let Ok(mut msgs) = msg_ref.lock() {
                            msgs.push((p.topic, payload));
                        } else {
                            error!("Failed to lock MQTT message queue");
                        }
                    }
                    Err(e) => {
                        error!("MQTT connection error: {:?}", e);
                    }
                    _ => {}
                }
            }
        });

        Self {
            client,
            default_topic: default_topic.to_string(),
            messages,
        }
    }

    pub fn publisher(
        &mut self,
        topic: Option<&str>,
        payload: &Value,
        qos: u8,
    ) -> Result<(), Box<dyn std::error::Error>> {
        let json_str = serde_json::to_string(payload)?;
        let qos_enum = match qos {
            1 => QoS::AtLeastOnce,
            2 => QoS::ExactlyOnce,
            _ => QoS::AtMostOnce,
        };

        let topic_to_use = topic.unwrap_or(&self.default_topic);
        self.client.publish(topic_to_use, qos_enum, false, json_str)?;
        Ok(())
    }

    pub fn subscriber(
        &mut self,
        topic: &str,
        qos: u8,
    ) -> Result<(), Box<dyn std::error::Error>> {
        let qos_enum = match qos {
            1 => QoS::AtLeastOnce,
            2 => QoS::ExactlyOnce,
            _ => QoS::AtMostOnce,
        };

        self.client.subscribe(topic, qos_enum)?;
        Ok(())
    }

    pub fn drain_messages(&self) -> Vec<(String, String)> {
        match self.messages.lock() {
            Ok(mut msgs) => msgs.drain(..).collect(),
            Err(e) => {
                log::error!("Messages mutex poisoned: {}", e);
                vec![]
            }
        }
    }

}
