use chrono::Local;
use serde_json::json;
use tracing::{info, error};
use sysinfo::{Components, Disks, Networks, System};
use std::{
    sync::Arc,
};
use tokio::sync::Mutex;

use crate::mqtt_service::mqtt_handler::MqttHandler;
use crate::hwinfo::get_cpu_info::get_all_cpu_info;
use crate::hwinfo::get_gpu_info::{get_gpu_vendor, get_all_gpu_info};
use crate::hwinfo::get_memory_info::get_all_memory_info;
use crate::hwinfo::get_disk_info::get_all_disk_info;
use crate::hwinfo::get_network_info::{get_primary_interface, get_network_stats};
use crate::hwinfo::get_power_info::get_all_power_info;



pub async fn mqtt_publish(
    mqtt: &Arc<tokio::sync::Mutex<MqttHandler>>,
    topic: &str,
    payload: &serde_json::Value,
    qos: u8,
) {
    let mut client = mqtt.lock().await;

    if let Err(e) = client.publisher(
        Some(topic),
        payload,
        qos,
    ) {
        error!("MQTT publish failed: {:?}", e);
    } else {
        info!("MQTT publish success (topic={})", topic);
    }
}




pub struct TelemetryPublisherMQTTConfig {
    pub mqtt: Arc<Mutex<MqttHandler>>,
    pub device_id: String,
    pub topic_pub_telemetry: String,
    pub topic_pub_logs: String,
    pub telemetry_qos: u8,
    pub log_qos: u8,
}


pub async fn telemetry_publisher(
    sys: &mut System,
    components: &mut Components,
    disks: &mut Disks,
    networks: &mut Networks,
    mqtt_config: &TelemetryPublisherMQTTConfig,
) {
    let TelemetryPublisherMQTTConfig {
        mqtt,
        device_id,
        topic_pub_telemetry,
        topic_pub_logs,
        telemetry_qos,
        log_qos,
    } = mqtt_config;

    let uptime_str = System::uptime();

    let cpus = get_all_cpu_info(sys, components);
    let mem_metrics = get_all_memory_info(sys);
    let disk_metrics = get_all_disk_info(disks);

    let iface = get_primary_interface().unwrap_or_default();
    let network_metrics = get_network_stats(&iface, networks);

    let gpus_vendor = get_gpu_vendor();
    let vendor = gpus_vendor
        .first()
        .map(|v| match v.to_lowercase().as_str() {
            "jepack" => "tegrastats",
            "nvidia" => "nvidia",
            "amd" => "rocm",
            _ => "unknown",
        })
        .unwrap_or("unknown");

    let gpus = get_all_gpu_info(vendor);
    let power_metrics = get_all_power_info();

    let timestamp_str = Local::now().format("%Y-%m-%d %H:%M:%S").to_string();

    let telemetry_payload = json!({
        "timestamp": timestamp_str,
        "uptime": uptime_str,
        "device_id": device_id.clone(),
        "metrics": {
            "cpu": cpus,
            "gpu": gpus,
            "memory": mem_metrics,
            "disk": disk_metrics,
            "network_metrics": network_metrics,
            "power": power_metrics,
        }
    });
    mqtt_publish(mqtt, topic_pub_telemetry, &telemetry_payload, *telemetry_qos).await;
}
