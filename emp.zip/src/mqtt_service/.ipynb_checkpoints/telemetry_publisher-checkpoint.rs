use std::thread;
use chrono::Local;
use serde_json::json;
use log::{info, error, warn};
use sysinfo::{Components, Disks, Networks, System};
use std::{
    sync::{Arc, Mutex},
    time::{Duration, Instant},
};

use crate::mqtt_service::mqtt_handler::MqttHandler;
use crate::hwinfo::get_cpu_info::get_all_cpu_info;
use crate::hwinfo::get_gpu_info::{get_gpu_vendor, get_all_gpu_info};
use crate::hwinfo::get_memory_info::get_all_memory_info;
use crate::hwinfo::get_disk_info::get_all_disk_info;
use crate::hwinfo::get_network_info::{get_primary_interface, get_network_stats};
use crate::hwinfo::get_power_info::get_all_power_info;



fn mqtt_publish(
    mqtt: &Arc<Mutex<MqttHandler>>,
    topic: &str,
    payload: &serde_json::Value,
    qos: u8,
) {
    match mqtt.lock() {
        Ok(mut client) => {
            if let Err(e) = client.publisher(Some(topic), payload, qos) {
                error!("MQTT publish failed (topic={}): {:?}", topic, e);
            } else {
                info!("MQTT publish success (topic={})", topic);
            }
        }
        Err(e) => {
            error!("Failed to acquire MQTT client lock: {}", e);
        }
    }
}


pub struct TelemetryPublisherMQTTConfig {
    pub mqtt: Arc<Mutex<MqttHandler>>,
    pub device_id: String,
    pub topic_pub_telemetry: String,
    pub topic_pub_logs: String,
    pub telemetry_qos: u8,
    pub log_qos: u8,
}


pub fn telemetry_publisher(
    sys: &mut System,
    components: &mut Components,
    disks: &mut Disks,
    networks: &mut Networks,
    mqtt_config: TelemetryPublisherMQTTConfig,
    refresh_time: f32,
) {
    let TelemetryPublisherMQTTConfig {
        mqtt,
        device_id,
        topic_pub_telemetry,
        topic_pub_logs,
        telemetry_qos,
        log_qos,
    } = mqtt_config;
    
    let mut start_ = Instant::now();
    let mut check_solved = true;

    loop {
        let uptime_str = System::uptime();
        
        let cpus = get_all_cpu_info(sys, components);
        let mem_metrics = get_all_memory_info(sys);
        let disk_metrics = get_all_disk_info(disks);
        
        let iface = get_primary_interface().unwrap_or_default();
        let network_metrics = get_network_stats(&iface, networks);

        let gpus_vendor = get_gpu_vendor();
        let vendor = gpus_vendor
            .first()
            .map(|v| match v.to_lowercase().as_str() {
                "jepack" => "tegrastats",
                "nvidia" => "nvidia",
                "amd" => "rocm",
                _ => "unknown",
            })
            .unwrap_or("unknown");
        let gpus = get_all_gpu_info(vendor);

        let power_metrics = get_all_power_info();
        
        let timestamp_str = Local::now().format("%Y-%m-%d %H:%M:%S").to_string();

        let telemetry_payload = json!({
            "timestamp": timestamp_str,
            "uptime": uptime_str,
            "device_id": device_id.clone(),
            "metrics": {
                "cpu": cpus,
                "gpu": gpus,
                "memory": mem_metrics,
                "disk": disk_metrics,
                "network_metrics": network_metrics,
                "power": power_metrics,
            }
        });

        mqtt_publish(&mqtt, &topic_pub_telemetry, &telemetry_payload, telemetry_qos);
        
        let cpu = &cpus[0];
        let cpu_high = cpu.avg_usage > 45.0;
        let mem_high = mem_metrics.percent > 45.0;
        if (cpu_high || mem_high) && check_solved {
            let warning_value = if cpu_high {
                cpu.avg_usage
            } else {
                mem_metrics.percent
            };

            warn!("High CPU/RAM usage: {:?}", warning_value);
            
            let log_payload = json!({
                "device_id": device_id.clone(),
                "category": "System".to_string(),
                "level": "INFO".to_string(),
                "trigger": "CPU/RAM ussage baseline".to_string(),
                "message": format!("CPU/RAM usage stable at {:?}", warning_value),
                "purpose": "Trend analysis and baseline metrics".to_string(),
                "time": Local::now().to_rfc3339(),
            });
        
            mqtt_publish(&mqtt, &topic_pub_logs, &log_payload, log_qos);
            check_solved = false;
        }
    
        if !cpu_high && !mem_high && !check_solved {
            info!("CPU/RAM has returned to a stable level.");
            check_solved = true;
        }
        
        let stop_ = Instant::now();
        let delta = stop_.duration_since(start_);
        let sleep_time = refresh_time - delta.as_secs_f32();
        if sleep_time > 0.0 {
            thread::sleep(Duration::from_secs_f32(sleep_time));
        }
        start_ += Duration::from_secs_f32(refresh_time);
        
    }
}
