// use aes_gcm::{Aes256Gcm, Key, Nonce};
// use aes_gcm::aead::{Aead, KeyInit};
// use sha3::{Digest, Sha3_256};
// use rand::RngCore;
// use base64::{encode, decode};

// pub fn derive_key(shared_secret: &str) -> Key<Aes256Gcm> {
//     let mut hasher = Sha3_256::new();
//     hasher.update(shared_secret.as_bytes());
//     let result = hasher.finalize();
//     Key::<Aes256Gcm>::from_slice(&result).clone()
// }

// pub fn encrypt(shared_secret: &str, plaintext: &str) -> String {
//     let key = derive_key(shared_secret);
//     let cipher = Aes256Gcm::new(&key);

//     let mut nonce_bytes = [0u8; 12];
//     rand::thread_rng().fill_bytes(&mut nonce_bytes);
//     let nonce = Nonce::from_slice(&nonce_bytes);

//     let ciphertext = cipher.encrypt(nonce, plaintext.as_bytes())
//         .expect("encrypt failed");

//     let mut out = nonce_bytes.to_vec();
//     out.extend(ciphertext);

//     encode(out)
// }

// pub fn decrypt(shared_secret: &str, payload: &str) -> Option<String> {
//     let key = derive_key(shared_secret);
//     let cipher = Aes256Gcm::new(&key);

//     let raw = decode(payload).ok()?;
//     if raw.len() < 12 {
//         return None;
//     }

//     let (nonce_bytes, ciphertext) = raw.split_at(12);
//     let nonce = Nonce::from_slice(nonce_bytes);

//     let plaintext = cipher.decrypt(nonce, ciphertext).ok()?;
//     String::from_utf8(plaintext).ok()
// }



use aes_gcm::{Aes256Gcm, Key, Nonce};
use aes_gcm::aead::{Aead, KeyInit};
use rand::RngCore;
use base64::{engine::general_purpose, Engine};

fn key_from_str(key_str: &str) -> Key<Aes256Gcm> {
    let mut key_bytes = [0u8; 32];
    let input = key_str.as_bytes();

    let len = input.len().min(32);
    key_bytes[..len].copy_from_slice(&input[..len]);

    *Key::<Aes256Gcm>::from_slice(&key_bytes)

}

pub fn encrypt(shared_key: &str, plaintext: &str) -> String {
    let key = key_from_str(shared_key);
    let cipher = Aes256Gcm::new(&key);

    let mut nonce_bytes = [0u8; 12];
    rand::thread_rng().fill_bytes(&mut nonce_bytes);
    let nonce = Nonce::from_slice(&nonce_bytes);

    let ciphertext = cipher
        .encrypt(nonce, plaintext.as_bytes())
        .expect("encrypt failed");

    let mut out = nonce_bytes.to_vec();
    out.extend(ciphertext);

    general_purpose::STANDARD.encode(out)

}

pub fn decrypt(shared_key: &str, payload: &str) -> Option<String> {
    let key = key_from_str(shared_key);
    let cipher = Aes256Gcm::new(&key);

    let raw = general_purpose::STANDARD.decode(payload).ok()?;

    if raw.len() < 12 {
        return None;
    }

    let (nonce_bytes, ciphertext) = raw.split_at(12);
    let nonce = Nonce::from_slice(nonce_bytes);

    let plaintext = cipher.decrypt(nonce, ciphertext).ok()?;
    String::from_utf8(plaintext).ok()
}
