use std::process::Command;



pub fn cmd_exists(cmd: &str) -> bool {
    Command::new(cmd)
        .arg("--help")
        .output()
        .is_ok()
}


pub fn is_jetson() -> bool {
    cmd_exists("tegrastats") &&
    std::path::Path::new("/proc/device-tree/model").exists()
}