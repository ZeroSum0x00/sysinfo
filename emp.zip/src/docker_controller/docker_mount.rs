use bollard::Docker;



pub async fn docker_mount(url: &str, timeout: u64) -> Docker {
    if url.starts_with("unix://") {
        let path = url.trim_start_matches("unix://");
        Docker::connect_with_unix(path, timeout, bollard::API_DEFAULT_VERSION)
            .expect("Failed to connect using unix socket")
    } else if url.starts_with("tcp://") {
        Docker::connect_with_http(url, timeout, bollard::API_DEFAULT_VERSION)
            .expect("Failed to connect using tcp")
    } else {
        panic!("Unknown docker endpoint: {}", url);
    }
}
