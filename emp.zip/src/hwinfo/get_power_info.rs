use std::fs;
use glob::glob;



pub fn get_in_power() {
    for entry in glob("/sys/bus/i2c/drivers/ina*/1-0040/hwmon/hwmon*/in1_input").unwrap() {
        println!("{:?}", entry)
        // if let Ok(input_path) = entry {
        //     if let Ok(content) = fs::read_to_string(&input_path) {
        //         if let Ok(milli) = content.trim().parse::<f32>() {
        //             let temp_c = milli / 1000.0;

        //             let label_path = input_path.with_file_name(
        //                 input_path
        //                     .file_name()
        //                     .unwrap()
        //                     .to_string_lossy()
        //                     .replace("_input", "_label"),
        //             );

        //             let label = if label_path.exists() {
        //                 fs::read_to_string(label_path)
        //                     .unwrap_or_else(|_| "unknown".into())
        //                     .trim()
        //                     .to_string()
        //             } else {
        //                 input_path.file_name().unwrap().to_string_lossy().to_string()
        //             };

                    
        //             if label.contains("Package id") || label.contains("Core") {
        //                 if label.contains("Package id") {
        //                     let label = label.replace("Package id ", "mean");
        //                     temps.push(CpuTemp { label, temp: temp_c });
        //                 } else if label.contains("Core ") {
        //                     let label = format!("cpu{}", core_id);
        //                     temps.push(CpuTemp { label, temp: temp_c });
        //                     core_id += 1;
        //                 }
        //             }

        //         }
        //     }
        // }
    }

}
