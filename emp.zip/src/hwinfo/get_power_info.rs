use std::fs;
use std::path::Path;
use serde::Serialize;

fn read_number(path: &Path) -> Option<f64> {
    let content = fs::read_to_string(path).ok()?;
    content.trim().parse::<f64>().ok()
}


#[derive(Serialize, Debug)]
pub struct PowerInfo {
    pub power_in: f64,
    pub power_consum: f64,
}


pub fn get_all_power_info() -> PowerInfo {
    let power_in = get_in_power();
    PowerInfo {
        power_in,
        power_consum: 0.0,
    }
}


fn get_in_power() -> f64 {
    let mut total_power_watt = 0.0;

    let hwmon_root = Path::new("/sys/class/hwmon");
    let hwmons = match fs::read_dir(hwmon_root) {
        Ok(v) => v,
        Err(_) => {
            eprintln!("Cannot access /sys/class/hwmon");
            return 0.0;
        }
    };

    for hwmon in hwmons.flatten() {
        let hwmon_path = hwmon.path();
        let name_path = hwmon_path.join("name");

        let chip_name = match fs::read_to_string(&name_path) {
            Ok(v) => v.trim().to_string(),
            Err(_) => continue,
        };

        if !chip_name.contains("ina") {
            continue;
        }

        println!("Found power chip: {}", chip_name);

        let entries = match fs::read_dir(&hwmon_path) {
            Ok(v) => v,
            Err(_) => continue,
        };

        let mut voltages = Vec::new();
        let mut currents = Vec::new();

        for entry in entries.flatten() {
            let path = entry.path();
            let fname = match path.file_name().and_then(|v| v.to_str()) {
                Some(v) => v,
                None => continue,
            };

            if fname.starts_with("in") && fname.ends_with("_input") {
                if let Some(v) = read_number(&path) {
                    voltages.push(v / 1000.0); // mV → V
                }
            }

            if fname.starts_with("curr") && fname.ends_with("_input") {
                if let Some(i) = read_number(&path) {
                    currents.push(i / 1000.0); // mA → A
                }
            }
        }

        let count = voltages.len().min(currents.len());

        for i in 0..count {
            let power = voltages[i] * currents[i];
            total_power_watt += power;

            println!(
                "  Rail {}: {:.2} V × {:.2} A = {:.2} W",
                i + 1,
                voltages[i],
                currents[i],
                power
            );
        }
    }

    total_power_watt
}
