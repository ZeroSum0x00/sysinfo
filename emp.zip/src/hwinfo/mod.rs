pub mod gpu;
pub mod get_cpu_info;
pub mod get_gpu_info;
pub mod get_memory_info;
pub mod get_disk_info;
pub mod get_network_info;