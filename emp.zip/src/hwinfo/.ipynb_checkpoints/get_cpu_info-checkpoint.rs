use serde::Serialize;
use sysinfo::{System, Components};
use std::{thread, time::Duration};
use std::collections::HashMap;
use regex::Regex;
use std::process::Command;


#[derive(Serialize, Clone, Debug)]
pub struct CoreInfo {
    pub id: u32,
    pub name: String,
    pub usage: f32,
    pub frequency: u64,
    pub thermal: f32,
}

#[derive(Serialize, Debug)]
pub struct CpuInfo {
    pub id: u32,
    pub device: String,
    pub device_name: String,
    pub avg_usage: f32,
    pub avg_thermal: f32,
    pub power: f32,
    pub core_info: Vec<CoreInfo>,
}

fn has_tegrastats() -> bool {
    Command::new("tegrastats")
        .arg("--help")
        .output()
        .is_ok()
}

pub fn get_all_cpu_info(
    sys: &mut System,
    components: &mut Components,
) -> Vec<CpuInfo> {
    if has_tegrastats() {
        get_cpu_info_tegrastats()
    } else {
        get_cpu_info_sysinfo(sys, components)
    }
}

fn get_cpu_info_tegrastats() -> Vec<CpuInfo> {
    let output = Command::new("tegrastats")
        .arg("--interval")
        .arg("1000")
        .output();

    let output = match output {
        Ok(o) => String::from_utf8_lossy(&o.stdout).to_string(),
        Err(_) => return vec![],
    };

    let re_cpu = Regex::new(r"CPU\s*\[(.*?)\]").unwrap();
    let re_core = Regex::new(r"(\d+)%@(\d+)").unwrap();

    let mut core_info = Vec::new();
    let mut total_usage = 0.0;

    if let Some(cap) = re_cpu.captures(&output) {
        for (i, c) in re_core.captures_iter(&cap[1]).enumerate() {
            let usage: f32 = c[1].parse().unwrap_or(0.0);
            let freq: u64 = c[2].parse().unwrap_or(0);

            total_usage += usage;

            core_info.push(CoreInfo {
                id: i as u32,
                name: format!("core_{}", i),
                usage,
                frequency: freq,
                thermal: 0.0, // tegrastats không có per-core temp
            });
        }
    }

    let avg_usage = if !core_info.is_empty() {
        total_usage / core_info.len() as f32
    } else {
        0.0
    };

    vec![CpuInfo {
        id: 0,
        device: "cpu_0".to_string(),
        device_name: "Carmel".to_string(), // Jetson
        avg_usage,
        avg_thermal: 0.0,
        power: 0.0,
        core_info,
    }]
}

fn get_cpu_info_sysinfo(
    sys: &mut System,
    components: &mut Components,
) -> Vec<CpuInfo> {
    sys.refresh_cpu_all();
    std::thread::sleep(std::time::Duration::from_millis(250));
    sys.refresh_cpu_all();
    components.refresh(true);

    let mut total_usage = 0.0;
    let mut cpu_name = "";

    let mut usage_metrics = Vec::new();
    for (i, cpu) in sys.cpus().iter().enumerate() {
        let usage = cpu.cpu_usage();
        let freq = cpu.frequency();

        total_usage += usage;
        cpu_name = cpu.brand();

        usage_metrics.push((i as u32, usage, freq));
    }

    let re_core = Regex::new(r"core\s+(\d+)").unwrap();
    let re_pkg = Regex::new(r"package id\s+(\d+)").unwrap();

    let mut core_temp = HashMap::new();
    let mut cpu_pkg_temp = HashMap::new();

    for component in components.iter() {
        let label = component.label().to_lowercase();
        if let Some(temp) = component.temperature() {
            if let Some(c) = re_core.captures(&label) {
                if let Ok(id) = c[1].parse::<u32>() {
                    core_temp.insert(id, temp);
                }
            } else if let Some(c) = re_pkg.captures(&label) {
                if let Ok(id) = c[1].parse::<u32>() {
                    cpu_pkg_temp.insert(id, temp);
                }
            }
        }
    }

    let mut core_info = Vec::new();
    for (id, usage, freq) in usage_metrics {
        core_info.push(CoreInfo {
            id,
            name: format!("core_{}", id),
            usage,
            frequency: freq,
            thermal: *core_temp.get(&id).unwrap_or(&0.0),
        });
    }

    let avg_usage = if !core_info.is_empty() {
        total_usage / core_info.len() as f32
    } else {
        0.0
    };

    let avg_thermal = if !cpu_pkg_temp.is_empty() {
        cpu_pkg_temp.values().sum::<f32>() / cpu_pkg_temp.len() as f32
    } else {
        0.0
    };

    vec![CpuInfo {
        id: 0,
        device: "cpu_0".to_string(),
        device_name: cpu_name.to_string(),
        avg_usage,
        avg_thermal,
        power: 0.0,
        core_info,
    }]
}