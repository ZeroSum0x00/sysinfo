use serde::Serialize;
use sysinfo::{System, Components};
use std::{thread, time::Duration};
use std::collections::HashMap;
use regex::Regex;
use crate::utils::helper::is_jetson;
use std::process::{Command, Stdio};
use std::io::{BufRead, BufReader};



#[derive(Serialize, Clone, Debug)]
pub struct CoreInfo {
    pub id: u32,
    pub name: String,
    pub usage: f32,
    pub frequency: u64,
    pub thermal: f32,
}

#[derive(Serialize, Debug)]
pub struct CpuInfo {
    pub id: u32,
    pub device: String,
    pub device_name: String,
    pub avg_usage: f32,
    pub avg_thermal: f32,
    pub power: f32,
    pub core_info: Vec<CoreInfo>,
}


pub fn get_all_cpu_info(sys: &mut System, components: &mut Components) -> Vec<CpuInfo> {
    if is_jetson() {
        get_jetpack_cpu_info()
    } else {
        get_server_cpu_info(sys, components)
    }
}


fn get_jetpack_cpu_info() -> Vec<CpuInfo> {
    let mut child = match Command::new("tegrastats")
        .stdout(Stdio::piped())
        .spawn()
    {
        Ok(c) => c,
        Err(_) => return vec![],
    };

    let stdout = match child.stdout.take() {
        Some(s) => s,
        None => return vec![],
    };

    let mut reader = BufReader::new(stdout);
    let mut line = String::new();

    if reader.read_line(&mut line).is_err() || line.is_empty() {
        let _ = child.kill();
        return vec![];
    }

    let _ = child.kill();

    let mut core_info = Vec::new();
    let mut total_usage = 0.0;
    let mut cpu_temp = 0.0;

    if let Some(start) = line.find("CPU [") && let Some(end) = line[start..].find(']') {
        let cores = &line[start + 5..start + end];

        for (i, core) in cores.split(',').enumerate() {
            let mut usage = 0.0;
            let mut freq = 0;

            if let Some((u, f)) = core.split_once("%@") {
                usage = u.trim().parse().unwrap_or(0.0);
                freq = f.trim().parse().unwrap_or(0);
            }

            total_usage += usage;

            core_info.push(CoreInfo {
                id: i as u32,
                name: format!("core_{}", i),
                usage,
                frequency: freq,
                thermal: 0.0,
            });
        }
    }

    if let Some(pos) = line.find("CPU@") {
        let part = &line[pos + 4..];
        if let Some(t) = part.split('C').next() {
            cpu_temp = t.parse().unwrap_or(0.0);
        }
    }

    for core in core_info.iter_mut() {
        core.thermal = cpu_temp;
    }

    let core_count = core_info.len() as f32;
    let avg_usage = if core_count > 0.0 {
        total_usage / core_count
    } else {
        0.0
    };

    vec![CpuInfo {
        id: 0,
        device: "cpu_0".to_string(),
        device_name: "NVIDIA Jetson CPU".to_string(),
        avg_usage,
        avg_thermal: cpu_temp,
        power: 0.0,
        core_info,
    }]
}



fn get_server_cpu_info(sys: &mut System, components: &mut Components) -> Vec<CpuInfo> {
    sys.refresh_cpu_all();
    thread::sleep(Duration::from_millis(250));
    sys.refresh_cpu_all();
    components.refresh(true);

    let mut total_usage = 0.0;
    let mut cpu_name = "";

    let mut usage_metrics = Vec::new();
    for (i, cpu) in sys.cpus().iter().enumerate() {
        let name = format!("core_{}", i);
        let usage = cpu.cpu_usage();
        let freq = cpu.frequency();

        total_usage += usage;
        cpu_name = cpu.brand();

        usage_metrics.push((i as u32, name, usage, freq));
    }

    let re_core = Regex::new(r"core\s+(\d+)").unwrap();
    let re_pkg = Regex::new(r"package id\s+(\d+)").unwrap();
    
    let mut core_temp = HashMap::new();
    let mut cpu_pkg_temp = HashMap::new();

    for component in components.iter() {
        let Some(temp_val) = component.temperature() else {
            continue;
        };
    
        let label = component.label().to_lowercase();
    
        if let Some(cap) = re_core.captures(&label)
            && let Ok(core_id) = cap[1].parse::<u32>()
        {
            core_temp.insert(core_id, temp_val);
        }
    
        if let Some(cap) = re_pkg.captures(&label)
            && let Ok(pkg_id) = cap[1].parse::<u32>()
        {
            cpu_pkg_temp.insert(pkg_id, temp_val);
        }
    }

    let mut core_info = Vec::new();
    for (id, name, usage, freq) in usage_metrics.into_iter() {
        let thermal = core_temp.get(&id).cloned().unwrap_or(0.0);
    
        core_info.push(CoreInfo {
            id,
            name,
            usage,
            frequency: freq,
            thermal,
        });
    }

    let core_count = core_info.len() as f32;
    let avg_usage = if core_count > 0.0 {
        total_usage / core_count
    } else {
        0.0
    };

    let avg_thermal = if !cpu_pkg_temp.is_empty() {
        cpu_pkg_temp.values().sum::<f32>() / cpu_pkg_temp.len() as f32
    } else {
        0.0
    };
    
    vec![CpuInfo {
        id: 0,
        device: "cpu_0".to_string(),
        device_name: cpu_name.to_string(),
        avg_usage,
        avg_thermal,
        power: 0.0,
        core_info,
    }]
}
