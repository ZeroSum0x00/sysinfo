use serde::Serialize;
use sysinfo::{System, Components};
use std::{thread, time::Duration};
use std::collections::HashMap;
use regex::Regex;


#[derive(Serialize, Clone, Debug)]
pub struct CoreInfo {
    pub id: u32,
    pub name: String,
    pub usage: f32,
    pub frequency: u64,
    pub thermal: f32,
}

#[derive(Serialize, Debug)]
pub struct CpuInfo {
    pub id: u32,
    pub device: String,
    pub device_name: String,
    pub avg_usage: f32,
    pub avg_thermal: f32,
    pub power: f32,
    pub core_info: Vec<CoreInfo>,
}

pub fn get_all_cpu_info(sys: &mut System, components: &mut Components) -> Vec<CpuInfo> {
    sys.refresh_cpu_all();
    thread::sleep(Duration::from_millis(250));
    sys.refresh_cpu_all();
    components.refresh(true);

    let mut total_usage = 0.0;
    let mut cpu_name = "";

    let mut usage_metrics = Vec::new();
    for (i, cpu) in sys.cpus().iter().enumerate() {
        let name = format!("core_{}", i);
        let usage = cpu.cpu_usage();
        let freq = cpu.frequency();

        total_usage += usage;
        cpu_name = cpu.brand();

        usage_metrics.push((i as u32, name, usage, freq));
    }

    let re_core = Regex::new(r"core\s+(\d+)").unwrap();
    let re_pkg = Regex::new(r"package id\s+(\d+)").unwrap();
    
    let mut core_temp = HashMap::new();
    let mut cpu_pkg_temp = HashMap::new();
        
    for component in components.iter() {
        let label = component.label().to_lowercase();
        if let Some(temp_val) = component.temperature() {
            if let Some(cap) = re_core.captures(&label) {
                if let Ok(core_id) = cap[1].parse::<u32>() {
                    core_temp.insert(core_id, temp_val);
                }
            } else if let Some(cap) = re_pkg.captures(&label) {
                if let Ok(pkg_id) = cap[1].parse::<u32>() {
                    cpu_pkg_temp.insert(pkg_id, temp_val);
                }
            }
        }
    }
    
    let mut core_info = Vec::new();
    for (id, name, usage, freq) in usage_metrics.into_iter() {
        let thermal = core_temp.get(&id).cloned().unwrap_or(0.0);
    
        core_info.push(CoreInfo {
            id,
            name,
            usage,
            frequency: freq,
            thermal,
        });
    }

    let core_count = core_info.len() as f32;
    let avg_usage = if core_count > 0.0 {
        total_usage / core_count
    } else {
        0.0
    };

    let avg_thermal = if !cpu_pkg_temp.is_empty() {
        cpu_pkg_temp.values().sum::<f32>() / cpu_pkg_temp.len() as f32
    } else {
        0.0
    };
    
    vec![CpuInfo {
        id: 0,
        device: "cpu_0".to_string(),
        device_name: cpu_name.to_string(),
        avg_usage,
        avg_thermal,
        power: 0.0,
        core_info,
    }]
}
