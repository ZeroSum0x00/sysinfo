use serde::Serialize;
use sysinfo::System;



#[derive(Serialize, Debug)]
pub struct MemoryInfo {
    pub percent: f32,
    pub used_mb: u64,
    pub available_mb: u64,
}


pub fn get_all_memory_info(sys: &mut System) -> MemoryInfo {
    let total = sys.total_memory() / 1_000;
    let available_mb = sys.available_memory() / 1_000;
    let used_mb = sys.used_memory() / 1_000;
    let percent = if total > 0 { (used_mb as f32 / total as f32) * 100.0 } else { 0.0 };

    MemoryInfo {
        percent,
        used_mb,
        available_mb,
    }
}
