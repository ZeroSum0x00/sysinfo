use sysinfo::Disks;
use serde::Serialize;

#[derive(Serialize, Clone, Debug)]
pub struct DiskInfo {
    pub id: usize,
    pub name: String,
    pub read_bps: u64,
    pub write_bps: u64,
    pub used_space: u64,
    pub free_space: u64,
    pub total_space: u64,
    pub percent: f32,
}

pub fn get_all_disk_info(disks: &mut Disks) -> Vec<DiskInfo> {
    disks.refresh(true);
    let skip_fs = ["overlay", "tmpfs", "shm", "proc", "sysfs", "devtmpfs"];

    let mut disk_metrics = Vec::new();

    for (i, disk) in disks.iter().enumerate() {
        let name = disk.name().to_string_lossy();

        if skip_fs.iter().any(|fs| name.contains(fs)) {
            continue;
        }

        let total_space = disk.total_space();
        let free_space = disk.available_space();
        let used_space = total_space.saturating_sub(free_space);
        let write_bps = disk.written_bytes();
        let read_bps = disk.read_bytes();

        let percent = if total_space > 0 {
            (used_space as f32 / total_space as f32) * 100.0
        } else {
            0.0
        };

        disk_metrics.push(DiskInfo {
            id: i,
            name: name.to_string(),
            read_bps,
            write_bps,
            used_space,
            free_space,
            total_space,
            percent,
        });
    }

    disk_metrics
}
