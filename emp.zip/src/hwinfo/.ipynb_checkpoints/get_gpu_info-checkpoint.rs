use std::process::Command;
use crate::hwinfo::gpu::gpu_model::GpuInfo;
use crate::hwinfo::gpu::jepack_gpu_collector::get_tegrastats_gpu_infomation;
use crate::hwinfo::gpu::nvidia_gpu_collector::get_nvidia_gpu_infomation;
use crate::hwinfo::gpu::amd_gpu_collector::get_amd_gpu_infomation;


fn cmd_exists(cmd: &str) -> bool {
    Command::new(cmd)
        .arg("--help")
        .output()
        .is_ok()
}


pub fn get_gpu_vendor() -> Vec<String> {
    let mut vendors = Vec::new();

    if cmd_exists("tegrastats") {
        vendors.push("jepack".to_string());
    }
    
    if cmd_exists("nvidia-smi") {
        vendors.push("nvidia".to_string());
    }

    if cmd_exists("rocm-smi") || cmd_exists("/opt/rocm/bin/rocm-smi") {
        vendors.push("amd".to_string());
    }

    if vendors.is_empty() {
        vendors.push("".to_string());
    }

    vendors
}



pub fn get_all_gpu_info(gpu_type: &str) -> Vec<GpuInfo> {
    match gpu_type {
        "tegrastats" => get_tegrastats_gpu_infomation(),
        "nvidia" => get_nvidia_gpu_infomation(),
        "amd" => get_amd_gpu_infomation(),
        _ => vec![GpuInfo::empty()],
    }
}


