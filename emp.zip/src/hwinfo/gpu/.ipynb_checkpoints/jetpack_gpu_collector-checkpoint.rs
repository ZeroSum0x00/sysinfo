use std::process::{Command, Stdio};
use std::io::{BufRead, BufReader};
use crate::hwinfo::gpu::gpu_model::GpuInfo;

pub fn get_tegrastats_gpu_infomation() -> Vec<GpuInfo> {
    let mut child = match Command::new("tegrastats")
        .stdout(Stdio::piped())
        .spawn()
    {
        Ok(c) => c,
        Err(_) => return vec![GpuInfo::empty()],
    };

    let stdout = match child.stdout.take() {
        Some(s) => s,
        None => return vec![GpuInfo::empty()],
    };

    let mut reader = BufReader::new(stdout);
    let mut line = String::new();

    if reader.read_line(&mut line).is_err() || line.is_empty() {
        let _ = child.kill();
        return vec![GpuInfo::empty()];
    }

    let _ = child.kill();

    let mut util = 0.0;
    let mut vram_used = 0.0;
    let mut vram_total = 0.0;
    let mut thermal = 0.0;

    if let Some(pos) = line.find("GR3D_FREQ") {
        let part = &line[pos..];
        if let Some(pct) = part.split('%').next() {
            util = pct
                .replace("GR3D_FREQ", "")
                .trim()
                .parse()
                .unwrap_or(0.0);
        }
    }

    if let Some(pos) = line.find("RAM") {
        let part = &line[pos..];
        if let Some(ram) = part.split_whitespace().nth(1) && let Some((used, total)) = ram.replace("MB", "").split_once('/') {
            vram_used = used.parse().unwrap_or(0.0);
            vram_total = total.parse().unwrap_or(0.0);
        }
    }

    if let Some(pos) = line.find("GPU@") {
        let part = &line[pos + 4..];
        if let Some(pct) = part.split('C').next() {
            println!("{}", pct);
            thermal = pct.parse().unwrap_or(0.0);
            println!("{}", thermal);
        }
    }
    vec![GpuInfo {
        id: 0,
        device_name: "NVIDIA Jetson GPU".to_string(),
        util,
        vram_used,
        vram_total,
        thermal,
        power_used: 0.0,
        power_limit: 0.0,
    }]
}
