pub mod gpu_model;
pub mod nvidia_gpu_collector;
pub mod amd_gpu_collector;
pub mod jepack_gpu_collector;