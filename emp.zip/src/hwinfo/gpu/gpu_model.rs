use serde::Serialize;



#[derive(Serialize, Debug)]
pub struct GpuInfo {
    pub id: u32,
    pub device_name: String,
    pub util: f32,
    pub vram_used: f32,
    pub vram_total: f32,
    pub thermal: f32,
    pub power_used: f32,
    pub power_limit: f32
}


impl GpuInfo {
    pub fn empty() -> Self {
        GpuInfo {
            id: 0,
            device_name: "".to_string(),
            util: 0.,
            vram_used: 0.,
            vram_total: 0.,
            thermal: 0.,
            power_used: 0.,
            power_limit: 0.
        }
    }
}