use crate::types::SystemMetrics;
use crate::mqtt_client::MqttClient;

use chrono::{DateTime, Utc};
use std::sync::Arc;
use serde::{Deserialize, Serialize};
use regex::Regex;
use std::error::Error;
use std::process::Command;
use std::collections::HashSet;


#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UserSession {
    user: String,
    ip: String,
}


#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct AlertMetrics {
    pub cpu_use: f32,
    pub memory: f32,
    pub gpu: f32,
    pub gpu_mem: f32,
    pub temperature: f32,
    pub capacity: f32,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct AlertEvent {
    pub ssh_sessions: Vec<UserSession>
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct AlertPayload {
    pub device_id: String,
    pub trigger_at: DateTime<Utc>,
    #[serde(default)]
    pub metrics: Option<AlertMetrics>,
    #[serde(default)]
    pub events: Option<AlertEvent>,
}


pub struct AlertManager {
    device_id: String,
    mqtt_client: Arc<MqttClient>,
}

impl AlertManager {
    pub fn new(
        device_id: String,
        mqtt_client: Arc<MqttClient>
    ) -> Self {
        Self {
            device_id,
            mqtt_client,
        }
    }

    pub async fn check_alerts(&self, metrics: SystemMetrics) {
        let cpu = &metrics.metrics.cpu[0];
        let cpu_usage = cpu.avg_usage;
        let cpu_thermal = cpu.avg_thermal;
        let cpu_ram = metrics.metrics.memory.percent;
        
        let gpu_usage: f32 = metrics
            .metrics
            .gpu
            .iter()
            .map(|gpu| gpu.util)
            .fold(0.0_f32, f32::max);
        
        let gpu_thermal: f32 = metrics
            .metrics
            .gpu
            .iter()
            .map(|gpu| gpu.thermal)
            .fold(0.0_f32, f32::max);
        
        let gpu_ram: f32 = metrics
            .metrics
            .gpu
            .iter()
            .map(|gpu| gpu.vram_percent)
            .fold(0.0_f32, f32::max);

        let thermal = gpu_thermal.max(cpu_thermal);

        let capacity: f32 = metrics
            .metrics
            .disk
            .iter()
            .map(|disk| disk.percent)
            .fold(0.0_f32, f32::max);

        let ssh_sessions = get_logged_in_users().unwrap_or_default();
        
        let payload = AlertPayload{
            device_id: self.device_id.clone(),
            trigger_at: Utc::now(),
            metrics: Some(AlertMetrics{
                cpu_use: cpu_usage,
                memory: cpu_ram,
                gpu: gpu_usage,
                gpu_mem: gpu_ram,
                temperature: thermal,
                capacity,
            }),
            events: Some(AlertEvent{
                ssh_sessions
            })
        };
        let _ = self.mqtt_client.publish_alert(&payload).await;
    }
}

fn get_logged_in_users() -> Result<Vec<UserSession>, Box<dyn Error + Send + Sync>> {
    let output = Command::new("who").output()?;

    if !output.status.success() {
        return Err("Failed to execute who command".into());
    }

    let stdout = String::from_utf8(output.stdout)?;

    let ip_re = Regex::new(
        r"\b((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b"
    )?;

    let mut unique_sessions = HashSet::new();

    for line in stdout.lines() {
        let parts: Vec<&str> = line.split_whitespace().collect();

        if parts.len() >= 5 {
            let user = parts[0];

            if let Some(mat) = ip_re.find(line) {
                let ip = mat.as_str();

                if ip != "127.0.0.1" {
                    unique_sessions.insert((user.to_string(), ip.to_string()));
                }
            }
        }
    }

    // Convert HashSet → Vec<UserSession>
    let sessions = unique_sessions
        .into_iter()
        .map(|(user, ip)| UserSession { user, ip })
        .collect();

    Ok(sessions)
}