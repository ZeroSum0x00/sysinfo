use tracing::error;
use serde_yaml::Value;
use rusqlite::Connection;
use anyhow::{anyhow, Result};
use serde::{Serialize, Deserialize};

use std::{
    fs,
    path::{Path, PathBuf},
    sync::Arc,
    sync::atomic::Ordering,
    time::Duration,
};

use tokio::{
    time::sleep,
    sync::Mutex,
    process::Command
};

use crate::docker_manager::DockerManager;
use crate::minio_downloader::FileZipMemory;
use crate::mqtt_client::{GLOBAL_ACTION_FLAG, MqttProgressPublisher, ShadowMessage, pub_shadow_aws, DesiredState, ReportState};
use crate::minio_downloader::MinIODownloader;
use crate::db_manager::{load_db_state, save_db_state};



#[derive(Debug, Deserialize, Serialize, Clone)]
pub struct DeploymentState {
    pub stable_stack: Option<Stack>,
    pub desire_stack: Option<Stack>,
}

#[derive(Debug, Deserialize, Serialize, Clone, PartialEq, Eq)]
pub struct Stack {
    pub stack_name: String,
    pub revision: Option<String>,
    pub services: Vec<String>,
    pub action: Option<String>,
    pub zip_result: Option<FileZipMemory>,
}

#[derive(Debug, Deserialize, Serialize, Clone, PartialEq, Eq)]
pub struct RunDeployState {
    pub names: Vec<String>,
    pub images: Vec<String>,
    pub path: PathBuf,
    pub yaml_name: Option<String>,
    pub is_deploy: Option<bool>,
}

// #[derive(Debug, Deserialize, Serialize, Clone, PartialEq, Eq)]
// struct VolumeSpec {
//     source: String,
//     target: String,
//     mode: Option<String>,
//     kind: Option<String>,
// }

// #[derive(Debug, Deserialize, Serialize)]
// struct NetworkInfo {
//     name: String,

//     #[serde(default)]
//     external: bool,
// }

#[derive(Debug, Clone, Copy)]
pub enum ComposeCmd {
    V2, // docker compose
    V1, // docker-compose
}

#[derive(Debug, Deserialize, Serialize)]
struct ProcessPayload {
    operation_id: String,
    action: String,
    progress: f32,
}

pub async fn detect_compose() -> Option<ComposeCmd> {
    // docker compose (v2)
    if let Ok(output) = Command::new("docker")
        .args(["compose", "version"])
        .output()
        .await
    {
        if output.status.success() {
            return Some(ComposeCmd::V2);
        }
    }

    // docker-compose (v1)
    if let Ok(output) = Command::new("docker-compose")
        .arg("version")
        .output()
        .await
    {
        if output.status.success() {
            return Some(ComposeCmd::V1);
        }
    }

    None
}

fn build_compose_cmd(cmd_type: ComposeCmd) -> Command {
    match cmd_type {
        ComposeCmd::V2 => {
            let mut cmd = Command::new("docker");
            cmd.arg("compose");
            cmd
        }
        ComposeCmd::V1 => Command::new("docker-compose"),
    }
}


pub async fn run_compose_up(
    cmd_type: ComposeCmd,
    software_folder_path: &Path,
    compose_file: Option<String>,
) -> Result<()> {

    let mut cmd = build_compose_cmd(cmd_type);

    if let Some(file) = compose_file {
        cmd.arg("-f").arg(file);
    }

    cmd.arg("up").arg("-d");

    let output = cmd
        .current_dir(software_folder_path)
        .output()
        .await?;

    if !output.status.success() {
        return Err(anyhow!(
            "compose up failed: {}",
            String::from_utf8_lossy(&output.stderr)
        ));
    }

    Ok(())
}

pub async fn run_compose_down(
    cmd_type: ComposeCmd,
    software_folder_path: &Path,
    compose_file: Option<String>,
) -> Result<()> {

    let mut cmd = build_compose_cmd(cmd_type);

    if let Some(file) = compose_file {
        cmd.arg("-f").arg(file);
    }

    cmd.arg("down");

    let output = cmd
        .current_dir(software_folder_path)
        .output()
        .await?;

    if !output.status.success() {
        return Err(anyhow!(
            "compose down failed: {}",
            String::from_utf8_lossy(&output.stderr)
        ));
    }

    Ok(())
}

// async fn create_network(network: NetworkInfo) -> Result<()> {

//     if !network.external {
//         return Ok(());
//     }

//     let check = Command::new("docker")
//         .args(["network", "inspect", &network.name])
//         .output()
//         .await?;

//     if check.status.success() {
//         println!("Network {} already exists", network.name);
//         return Ok(());
//     }

//     let output = Command::new("docker")
//         .args(["network", "create", &network.name])
//         .output()
//         .await?;

//     if !output.status.success() {
//         return Err(anyhow!(
//             "docker network create failed: {}",
//             String::from_utf8_lossy(&output.stderr)
//         ));
//     }

//     println!("Network created: {}", network.name);

//     Ok(())
// }


pub async fn compose_extract(
    stack: Stack
) -> Result<Vec<RunDeployState>> {
    let mut list_compose = Vec::new();
    let services = stack.services;
    let zip_result = stack.zip_result;
    
    for service in services {
        let software_folder_path = Path::new(&zip_result.clone().unwrap().unzip_to_folder).join(&service);
    
        if !software_folder_path.exists() {
            return Err(anyhow!("Folder {:?} không tồn tại", software_folder_path));
        }
    
        let compose_file = ["docker-compose.yml", "docker-compose.yaml"]
            .iter()
            .map(|f| software_folder_path.join(f))
            .find(|p| p.is_file());
        
        let compose_path = match compose_file {
            Some(p) => p,
            None => {
                return Err(anyhow!("Không tìm thấy docker compose file cho {}", service));
            }
        };
        
        let compose_filename = compose_path
            .file_name()
            .and_then(|s| s.to_str())
            .unwrap();

        let content = fs::read_to_string(&compose_path)?;
        let yaml: Value = serde_yaml::from_str(&content)?;
    
        let mut images: Vec<String> = Vec::new();
        let mut container_names = Vec::new();
        // let mut networks: Vec<NetworkInfo> = Vec::new();
    
        if let Some(svcs) = yaml["services"].as_mapping() {
            for (_, svc) in svcs {
                if let Some(name) = svc["container_name"].as_str() {
                    container_names.push(name.to_string());
                }
        
                if let Some(img) = svc["image"].as_str() {
                    images.push(img.to_string());
                }
            }
        }
        
        // if let Some(nets) = yaml.get("networks").and_then(|n| n.as_mapping()) {    
        //     for (name, config) in nets {
        
        //         let parent_name = name.as_str().unwrap_or("");
    
        //         let net_name = config
        //             .get("name")
        //             .and_then(|v| v.as_str())
        //             .unwrap_or(parent_name)
        //             .to_string();
        
        //         let external = config
        //             .get("external")
        //             .and_then(|v| v.as_bool())
        //             .unwrap_or(false);
        
        //         networks.push(NetworkInfo {
        //             name: net_name,
        //             external,
        //         });
        //     }
        // }
    
        // for network in networks {
        //     create_network(network).await?;
        // }
    
        list_compose.push(RunDeployState{
            names: container_names,
            images,
            path: software_folder_path,
            yaml_name: Some(compose_filename.to_string()),
            is_deploy: None
        });
    }

    Ok(list_compose)
}


pub async fn check_container_health(container: &str) -> Result<String> {

    let output = Command::new("docker")
        .arg("inspect")
        .arg("--format")
        .arg("{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}")
        .arg(container)
        .output()
        .await?;

    if !output.status.success() {
        return Err(anyhow!("docker inspect failed"));
    }

    let status = String::from_utf8_lossy(&output.stdout)
        .trim()
        .to_string();

    Ok(status)
}


pub async fn wait_container_healthy(container: &str, loop_iter: usize) -> Result<String> {

    for _ in 0..loop_iter {

        let status = check_container_health(container).await?;

        if status == "healthy" || status == "running" {
            return Ok(status);
        }

        sleep(Duration::from_secs(2)).await;
    }

    Err(anyhow!("healthcheck timeout"))
}


pub async fn wait_container_status(
    docker: &Arc<Mutex<DockerManager>>,
    container: &str,
    loop_iter: usize
) -> Result<String> {

    let mut not_running_seen = false;
    let mut restart_count = 0;
    
    for _ in 0..loop_iter {

        let status = {
            let docker_lock = docker.lock().await;
            docker_lock.inspect_container_status(container).await
        };

        match status {
            Ok(s) => {
                match s.as_str() {
                    "running" => {}
                    "exited" => return Err(anyhow!("container exited")),
                    "restarting" => {
                        restart_count += 1;
                        if restart_count >= 3 {
                            return Err(anyhow!("container restarting too much"));
                        }
                    }
                    _ => {
                        not_running_seen = true;
                    }
                }
            }

            Err(e) => {
                println!("inspect error: {}", e);
                not_running_seen = true;
            }
        }

        sleep(Duration::from_secs(2)).await;
    }

    if not_running_seen {
        Err(anyhow!("container was not always running"))
    } else {
        Ok("running".to_string())
    }
}


#[derive(Debug)]
pub struct ComposeMQTTConfig {
    pub mqtt: Arc<MqttProgressPublisher>,
    pub topic: String,
    pub operation_id: String,
    pub action: String,
    
}

pub async fn exec_all_compose(
    mqtt_config: Option<&ComposeMQTTConfig>,
    docker: &Arc<Mutex<DockerManager>>,
    compose: ComposeCmd,
    deploy_state: Vec<RunDeployState>,
    mode: &str
) -> Result<f32> {

    let mqtt = mqtt_config.map(|c| &c.mqtt);
    let topic = mqtt_config.map(|c| &c.topic);
    let operation_id = mqtt_config.map(|c| &c.operation_id);
    let action = mqtt_config.map(|c| &c.action);
    let total: usize = deploy_state.iter().map(|s| s.names.len()).sum();
    let mut success = 0;

    for (i, state) in deploy_state.iter().enumerate() {
        match mode {

            "start" => {

                run_compose_up(compose, &state.path, state.yaml_name.clone()).await?;

                for name in &state.names {
                    
                    let status_ok = wait_container_status(docker, name, 10).await.is_ok();
                    let health_ok = wait_container_healthy(name, 10).await.is_ok();
                
                    if status_ok && health_ok {
                        success += 1;
                    } else {
                        return Err(anyhow!(
                            "failed to check status container"
                        ));
                    }
                }

                if let (Some(mqtt), Some(topic)) = (mqtt, topic) {
                    let process_payload = ProcessPayload {
                        operation_id: operation_id.unwrap().to_string(),
                        action: action.unwrap().to_string(),
                        progress: ((i + 1) * 100 / total) as f32,
                    };
                
                    let payload = serde_json::to_string(&process_payload)?;

                    if let Err(e) = mqtt.publish_to_topic(&topic, payload).await {
                        error!("mqtt publish error: {}", e);
                    }
                }
            }

            "stop" => {
                run_compose_down(compose, &state.path, state.yaml_name.clone()).await?;
            }

            _ => return Err(anyhow::anyhow!("invalid mode")),
        }
    }

    let percent = (success * 100 / total) as f32;
    Ok(percent)
}


pub async fn handle_shadow_command(
    publish_payload: Vec<u8>,
    docker_mgr: Arc<Mutex<DockerManager>>,
    db_client_clone: Arc<Mutex<Connection>>,
    deployment_state: &mut DeploymentState,
    bucker_manager_clone: Option<Arc<Mutex<MinIODownloader>>>,
    reserve_mqtt_client: Arc<MqttProgressPublisher>,
    stack_progess_topic_pub: String,
    aws_shadow_update: String,
) -> Result<()> {

    GLOBAL_ACTION_FLAG.store(false, Ordering::Relaxed);
    let mut percen_success: f32 = 0.0;
    let mut error_message: Option<String> = None;
    
    let loaded = load_db_state(db_client_clone.clone(), 1).await;
    if let Ok(stack) = loaded {
        deployment_state.stable_stack = stack;
    }

    println!("=================================================================================");
    println!("deployment_state stable: {:?}", deployment_state.stable_stack);
    println!("deployment_state desire: {:?}", deployment_state.desire_stack);

    let payload = String::from_utf8_lossy(&publish_payload);

    let msg: ShadowMessage = match serde_json::from_str(&payload) {
        Ok(v) => v,
        Err(e) => {
            eprintln!("JSON parse error: {}", e);
            GLOBAL_ACTION_FLAG.store(true, Ordering::Relaxed);
            return Ok(());
        }
    };
    println!("msg: {:?}", msg);

    let status = msg
        .state
        .as_ref()
        .and_then(|s| s.desired.as_ref())
        .and_then(|d| d.status.clone());
    
    if status == Some("done".to_string()) {
        GLOBAL_ACTION_FLAG.store(true, Ordering::Relaxed);
        return Ok(());
    }

    let action = msg
        .state
        .as_ref()
        .and_then(|s| s.desired.as_ref())
        .and_then(|d| d.action.clone());
    
    if action.is_none() {
        GLOBAL_ACTION_FLAG.store(true, Ordering::Relaxed);
        return Ok(());
    }
    
    let operation_id = msg
        .state
        .as_ref()
        .and_then(|s| s.desired.as_ref())
        .map(|d| d.operation_id.clone());

    let stable_version = msg
        .state
        .as_ref()
        .and_then(|s| s.desired.as_ref())
        .and_then(|d| d.stable_version.clone());

    let desire_version = msg
        .state
        .as_ref()
        .and_then(|s| s.desired.as_ref())
        .and_then(|d| d.desire_version.clone());

    let version_changed = match &deployment_state.stable_stack {
        None => true,
        Some(stable) => stable.revision != desire_version,
    };

    // if !version_changed {
    //     GLOBAL_ACTION_FLAG.store(true, Ordering::Relaxed);
    //     return Ok(());
    // }
    
    let stable_url = msg
        .state
        .as_ref()
        .and_then(|s| s.desired.as_ref())
        .and_then(|d| d.stable_url.clone());

    let desire_url = msg
        .state
        .as_ref()
        .and_then(|s| s.desired.as_ref())
        .and_then(|d| d.desire_url.clone());

    let compose_mqtt_config = ComposeMQTTConfig {
        mqtt: reserve_mqtt_client.clone(),
        topic: stack_progess_topic_pub.clone(),
        operation_id: operation_id.clone().unwrap(),
        action: action.clone().unwrap(),
    };

    let compose = detect_compose()
        .await
        .ok_or_else(|| anyhow!("No docker compose found"))?;
    

    if action.as_deref() == Some("restart") {
        if let Some(stable) = &deployment_state.stable_stack {

            let info = match compose_extract(stable.clone()).await {
                Ok(v) => v,
                Err(e) => {
                    eprintln!("compose_extract error: {:?}", e);
                    GLOBAL_ACTION_FLAG.store(true, Ordering::Relaxed);
                    return Err(e);
                }
            };

            let rev_info: Vec<_> = info.iter().rev().cloned().collect();

            if let Err(e) = exec_all_compose(None, &docker_mgr, compose, rev_info, "stop").await {
                eprintln!("stop error: {:?}", e);
                GLOBAL_ACTION_FLAG.store(true, Ordering::Relaxed);
                return Err(e);
            }

            percen_success = match exec_all_compose(None, &docker_mgr, compose, info, "start").await {
                Ok(v) => v,
                Err(e) => {
                    eprintln!("start error: {:?}", e);
                    GLOBAL_ACTION_FLAG.store(true, Ordering::Relaxed);
                    return Err(e);
                }
            };
        }
    }
    
    if let (Some(downloader_manager), Some(url)) = (bucker_manager_clone.clone(), desire_url.clone()) {
        if let Err(e) = async {
            let result_path = downloader_manager
                .lock()
                .await
                .download_to_link(url.clone())
                .await?;
    
            let mut zip_result = downloader_manager
                .lock()
                .await
                .unzip_file(result_path)
                .await?;
    
            let mut stack_json_file: Option<PathBuf> = None;
    
            zip_result.files.retain(|k| {
                if k.file_name()
                    .map(|name| name == "stack.json")
                    .unwrap_or(false)
                {
                    stack_json_file = Some(k.clone());
                    false
                } else {
                    true
                }
            });
            
            
            if let Some(stack_path) = &stack_json_file {
                let json_str = fs::read_to_string(stack_path)?;
                let mut stack: Stack = serde_json::from_str(&json_str)?;
                stack.revision = desire_version.clone();
                stack.action = action.clone();
                stack.zip_result = Some(zip_result.clone());
                
                deployment_state.desire_stack = Some(stack.clone());
                
                let desire_compose_info = compose_extract(deployment_state.desire_stack.clone().unwrap()).await;

                if let Some(stable) = &deployment_state.stable_stack {
                    match compose_extract(stable.clone()).await {
                        Ok(info) => {            
                            let rev_info: Vec<_> = info.iter().rev().cloned().collect();
                            exec_all_compose(None, &docker_mgr, compose, rev_info, "stop").await?;
                            println!("{}", "stop stable stack");
                        }
            
                        Err(e) => {
                            println!("error: {}", e);
                            GLOBAL_ACTION_FLAG.store(true, Ordering::Relaxed);
                            return Err(e);
                        }
                    }
                }
                
                if action.as_deref() == Some("canary") {
                    match desire_compose_info {
                        Ok(info) => {
                            percen_success = exec_all_compose(Some(&compose_mqtt_config), &docker_mgr, compose, info.clone(), "start").await?;

                            let rev_info: Vec<_> = info.clone().iter().rev().cloned().collect();
                            exec_all_compose(None, &docker_mgr, compose, rev_info, "stop").await?;
                        },
                        Err(e) => {
                            println!("error: {}", e);
                            GLOBAL_ACTION_FLAG.store(true, Ordering::Relaxed);
                            return Err(e);
                        }
                    }
                    
                    if let Some(stable) = &deployment_state.stable_stack {
                        let info = compose_extract(stable.clone()).await?;
                        exec_all_compose(None, &docker_mgr, compose, info, "start").await?;
                        println!("start stable stack");
                    }
                    
                } else if action.as_deref() == Some("deploy") || action.as_deref() == Some("rollback") {                                            
                    match desire_compose_info {
                        Ok(info) => {
                            percen_success = exec_all_compose(Some(&compose_mqtt_config), &docker_mgr, compose, info.clone(), "start").await?;

                            if percen_success == 100.0 {
                                save_db_state(
                                    db_client_clone.clone(),
                                    &stack
                                ).await?;
                                
                            } else if action.as_deref() != Some("rollback") {
                                let rev_info: Vec<_> = info.clone().iter().rev().cloned().collect();
                                exec_all_compose(None, &docker_mgr, compose, rev_info, "stop").await?;
                                
                                if let Some(stable) = &deployment_state.stable_stack {
                                    let info = compose_extract(stable.clone()).await?;
                                    exec_all_compose(None, &docker_mgr, compose, info, "start").await?;
                                    println!("start stable stack");
                                }
                            }
                        },
                        Err(e) => {
                            println!("error: {}", e);
                            GLOBAL_ACTION_FLAG.store(true, Ordering::Relaxed);
                            return Err(e);
                        }
                    }
                } else {
                    GLOBAL_ACTION_FLAG.store(true, Ordering::Relaxed);
                    tokio::time::sleep(Duration::from_secs(1)).await;
                    return Err(anyhow::anyhow!("action much in ['canary', 'deploy']"));
                }

            } else {
                GLOBAL_ACTION_FLAG.store(true, Ordering::Relaxed);
                tokio::time::sleep(Duration::from_secs(1)).await;
                return Err(anyhow::anyhow!("stack.json not found"));
            }
    
            Ok::<(), anyhow::Error>(())
    
        }.await {
            println!("task error: {}", e);
            GLOBAL_ACTION_FLAG.store(true, Ordering::Relaxed);
            return Err(e);
        }
    }

    if let Err(e) = pub_shadow_aws(
        reserve_mqtt_client.clone(),
        aws_shadow_update.clone(),
        DesiredState{
            operation_id: operation_id.clone().unwrap(),
            stable_version: stable_version.clone(),
            desire_version: desire_version.clone(),
            stable_url: stable_url.clone(),
            desire_url: desire_url.clone(),
            action: action.clone(),
            status: Some("done".to_string())
        },
        ReportState {
            operation_id: operation_id.clone().unwrap(),
            action: action.clone(),
            desire_version: desire_url.clone(),
            progress: Some(percen_success),
            message: Some("abc".to_string())
        }
    ).await{
        error!("❌ pub_shadow_aws failed: {:?}", e);
    }
    
    GLOBAL_ACTION_FLAG.store(true, Ordering::Relaxed);
    Ok(())
}