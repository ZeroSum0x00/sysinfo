mod hwinfo;
mod mqtt_service;
mod docker_controller;
use std::str::FromStr;
mod utils;
use std::{
    env,
    fs,
    path::Path,
    sync::{Arc, Mutex},
};

use dotenvy::dotenv;
use serde_json::json;
use chrono::Local;
use log::{info, error};

use sysinfo::{Components, Disks, Networks, System};

use mqtt_service::{
    mqtt_handler::MqttHandler,
    telemetry_publisher::{TelemetryPublisherMQTTConfig, telemetry_publisher},
    docker_info_publisher::docker_info_publisher,
    docker_controller_subscriber::{DockerControllerSubscriberMQTTConfig, docker_controller_subscriber},
};

use docker_controller::docker_mount::docker_mount;
use bollard::auth::DockerCredentials;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    dotenv().ok();
    env_logger::init();

    let telemetry_refresh_time: f32 = env_parse("TELEMETRY_REFRESH_TIME", "15")?;
    let docker_info_refresh_time: f32 = env_parse("DOCKER_INFO_REFRESH_TIME", "3")?;
    let command_refresh_time: f32 = env_parse("COMMAND_INFO_REFRESH_TIME", "1")?;

    let device_id = env::var("DEVICE_ID").expect("DEVICE_ID not set in .env");
    let mqtt_host = env::var("MQTT_HOST").unwrap_or("127.0.0.1".to_string());
    let mqtt_port: u16 = env_parse("MQTT_PORT", "1883")?;

    let mqtt_username = env::var("MQTT_USERNAME").expect("USERNAME's mqtt not set");
    let mqtt_password = env::var("MQTT_PASSWORD").expect("PASSWORD's mqtt not set");

    let store_url = env::var("STORE_URL").expect("USERNAME's store not set");
    let store_username = env::var("STORE_USERNAME").expect("USERNAME's store not set");
    let store_password = env::var("STORE_PASSWORD").expect("PASSWORD's store not set");
    let store_credential = DockerCredentials {
        username: Some(store_username.to_string()),
        password: Some(store_password.to_string()),
        serveraddress: Some(store_url.to_string()),
        ..Default::default()
    };

    let docker_controller = docker_mount("unix:///var/run/docker.sock", 120).await;

    let topic_base = env::var("TOPIC_BASE").unwrap_or("device".to_string());
    let topic_default = format!("{}/{}", topic_base, device_id);
    let topic_pub_telemetry = format!("{}/{}", topic_default, "telemetry");
    let topic_pub_logs = format!("{}/{}", topic_default, "logs");
    let topic_sub_applications = format!("{}/{}", topic_default, "applications");
    let topic_pub_applications = format!("{}/{}", topic_sub_applications, "response");
    let topic_sub_operator = format!("{}/{}", topic_default, "operator");
    let topic_pub_operator = format!("{}/{}", topic_sub_operator, "response");
    let topic_pub_docker_info = format!("{}/{}", topic_default, "docker-info");
    
    let mqtt = Arc::new(Mutex::new(MqttHandler::new(
        &mqtt_host,
        mqtt_port,
        &device_id.clone(),
        &topic_default,
        Some(&mqtt_username),
        Some(&mqtt_password),
    )));
    
    let state_dir = ".temp";
    let first_run_flag = format!("{}/first_run_done", state_dir);
    
    if !Path::new(state_dir).exists() {
        fs::create_dir_all(state_dir)?;
    }

    if !Path::new(&first_run_flag).exists() {
        let host_ip = env::var("HOST_IP").unwrap_or("127.0.0.1".to_string());
        let host_ssh_port: u16 = env_parse("HOST_SSH_PORT", "22")?;
        let host_os_name = env::var("HOST_OS_NAME").unwrap_or("unknow".to_string());
        let host_user = env::var("HOST_USER").unwrap_or("".to_string());
        let host_mac = env::var("HOST_MAC").unwrap_or("".to_string());
        
        let init_agent_payload = json!({
            "device_id": device_id.clone(),
            "category": "System".to_string(),
            "level": "INFO".to_string(),
            "trigger": "Device connected to platform".to_string(),
            "message": "Device successfully connected to management platform.".to_string(),
            "purpose": "Confirm successful communication & connectivity.".to_string(),
            "system_os": host_os_name,
            "user": host_user,
            "mac": host_mac,
            "ip": host_ip,
            "port": host_ssh_port,
            "time": Local::now().to_rfc3339(),
        });

        match mqtt.lock() {
            Ok(mut client) => {
                if let Err(e) = client.publisher(Some(&topic_pub_logs), &init_agent_payload, 1) {
                    error!("MQTT publish failed (topic={}): {:?}", topic_pub_logs, e);
                } else {
                    fs::write(&first_run_flag, "done")?;
                    info!("First run initialized for device {}", device_id);
                }
            }
            Err(e) => {
                error!("Failed to lock MQTT client: {}", e);
            }
        }
    }

    info!("Agent started | device_id={}", device_id);

    tokio::task::spawn_blocking({
        let mqtt = mqtt.clone();
        let device_id = device_id.clone();
        let topic_pub_telemetry = topic_pub_telemetry.clone();
        let topic_pub_logs = topic_pub_logs.clone();

        move || {
            let mut system = System::new_all();
            let mut components = Components::new_with_refreshed_list();
            let mut disks = Disks::new_with_refreshed_list();
            let mut networks = Networks::new_with_refreshed_list();
            
            let mqtt_config = TelemetryPublisherMQTTConfig {
                mqtt: mqtt.clone(),
                device_id,
                topic_pub_telemetry,
                topic_pub_logs,
                telemetry_qos: 1,
                log_qos: 1,
            };
                
            telemetry_publisher(
                &mut system,
                &mut components,
                &mut disks,
                &mut networks,
                mqtt_config,
                telemetry_refresh_time,
            );
        }
    });

    let docker_handle = tokio::spawn({
        let mut docker = docker_controller.clone();
        let store_credential = store_credential.clone();

        let mqtt_config = DockerControllerSubscriberMQTTConfig {
            mqtt: mqtt.clone(),
            topic_sub_applications,
            topic_pub_applications,
            topic_sub_operator,
            topic_pub_operator,
            qos: 1,
        };
        
        async move {
            docker_controller_subscriber(
                &mut docker,
                store_credential,
                mqtt_config,
                command_refresh_time,
            )
            .await;
        }
    });

    tokio::spawn({
        let mqtt = mqtt.clone();
        let mut docker = docker_controller.clone();
        let device_id = device_id.clone();

        async move {
            docker_info_publisher(
                mqtt,
                &mut docker,
                device_id,
                topic_pub_docker_info,
                docker_info_refresh_time,
            )
            .await;
        }
    });

    docker_handle.await?;
    Ok(())
}



fn env_parse<T>(key: &str, default: &str) -> Result<T, Box<dyn std::error::Error>>
where
    T: FromStr,
    T::Err: std::fmt::Display,
{
    let raw = env::var(key).unwrap_or_else(|_| default.to_string());

    raw.parse::<T>().map_err(|e| {
        error!("Invalid {} value '{}': {}", key, raw, e);
        format!("Invalid {} value '{}'", key, raw).into()
    })
}