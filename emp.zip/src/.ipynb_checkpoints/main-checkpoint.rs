mod hwinfo;
mod mqtt_service;
mod docker_controller;
use std::str::FromStr;
mod utils;
use std::{
    env,
    fs,
    path::Path,
};

use dotenvy::dotenv;
use serde_json::json;
use chrono::Local;
use tracing_subscriber::{fmt, EnvFilter};
use tracing::{info, error};

use sysinfo::{Components, Disks, Networks, System};

use mqtt_service::{
    mqtt_handler::MqttHandler,
    telemetry_publisher::{TelemetryPublisherMQTTConfig, telemetry_publisher},
    docker_info_publisher::{DockerInfoPublisherConfig, docker_info_publisher},
    docker_controller_subscriber::{DockerControllerSubscriberMQTTConfig, docker_controller_subscriber},
};

use docker_controller::docker_mount::docker_mount;
use bollard::auth::DockerCredentials;
use tokio::sync::Mutex;
use std::sync::Arc;
use tokio::signal::unix::{signal, SignalKind};
use tokio::sync::broadcast;


#[tokio::main(flavor = "multi_thread", worker_threads = 2)]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    dotenv().ok();
    fmt().with_env_filter(EnvFilter::from_default_env()).init();
    let (shutdown_tx, _) = broadcast::channel::<()>(1);

    let telemetry_refresh_time: f32 = env_parse("TELEMETRY_REFRESH_TIME", "15")?;
    let docker_info_refresh_time: f32 = env_parse("DOCKER_INFO_REFRESH_TIME", "3")?;
    let command_refresh_time: f32 = env_parse("COMMAND_INFO_REFRESH_TIME", "1")?;

    let device_id = env::var("DEVICE_ID").expect("DEVICE_ID not set in .env");
    let mqtt_host = env::var("MQTT_HOST").unwrap_or("127.0.0.1".to_string());
    let mqtt_port: u16 = env_parse("MQTT_PORT", "1883")?;

    let mqtt_username = env::var("MQTT_USERNAME").expect("USERNAME's mqtt not set");
    let mqtt_password = env::var("MQTT_PASSWORD").expect("PASSWORD's mqtt not set");

    let store_url = env::var("STORE_URL").expect("USERNAME's store not set");
    let store_username = env::var("STORE_USERNAME").expect("USERNAME's store not set");
    let store_password = env::var("STORE_PASSWORD").expect("PASSWORD's store not set");
    let store_credential = DockerCredentials {
        username: Some(store_username.to_string()),
        password: Some(store_password.to_string()),
        serveraddress: Some(store_url.to_string()),
        ..Default::default()
    };

    let docker_controller = docker_mount("unix:///var/run/docker.sock", 120).await;

    let topic_base = env::var("TOPIC_BASE").unwrap_or("device".to_string());
    let topic_default = format!("{}/{}", topic_base, device_id);
    let topic_pub_telemetry = format!("{}/{}", topic_default, "telemetry");
    let topic_pub_logs = format!("{}/{}", topic_default, "logs");
    let topic_sub_applications = format!("{}/{}", topic_default, "applications");
    let topic_pub_applications = format!("{}/{}", topic_sub_applications, "response");
    let topic_sub_operator = format!("{}/{}", topic_default, "operator");
    let topic_pub_operator = format!("{}/{}", topic_sub_operator, "response");
    let topic_pub_docker_info = format!("{}/{}", topic_default, "docker-info");
    
    let mqtt = Arc::new(Mutex::new(
        MqttHandler::new(
            &mqtt_host,
            mqtt_port,
            &device_id,
            &topic_default,
            Some(&mqtt_username),
            Some(&mqtt_password),
        )
    ));

    
    let state_dir = ".temp";
    let first_run_flag = format!("{}/first_run_done", state_dir);
    
    if !Path::new(state_dir).exists() {
        fs::create_dir_all(state_dir)?;
    }

    if !Path::new(&first_run_flag).exists() {
        let host_ip = env::var("HOST_IP").unwrap_or("127.0.0.1".to_string());
        let host_ssh_port: u16 = env_parse("HOST_SSH_PORT", "22")?;
        let host_os_name = env::var("HOST_OS_NAME").unwrap_or("unknow".to_string());
        let host_user = env::var("HOST_USER").unwrap_or("".to_string());
        let host_mac = env::var("HOST_MAC").unwrap_or("".to_string());
        
        let init_agent_payload = json!({
            "device_id": device_id.clone(),
            "category": "System".to_string(),
            "level": "INFO".to_string(),
            "trigger": "Device connected to platform".to_string(),
            "message": "Device successfully connected to management platform.".to_string(),
            "purpose": "Confirm successful communication & connectivity.".to_string(),
            "system_os": host_os_name,
            "user": host_user,
            "mac": host_mac,
            "ip": host_ip,
            "port": host_ssh_port,
            "time": Local::now().to_rfc3339(),
        });
        
        {
            let mut client = mqtt.lock().await;
        
            if let Err(e) = client.publisher(
                Some(&topic_pub_logs),
                &init_agent_payload,
                1,
            ) {
                error!("MQTT publish failed (topic={}): {:?}", topic_pub_logs, e);
            } else {
                fs::write(&first_run_flag, "done")?;
                info!("First run initialized for device {}", device_id);
            }
        }
        
    }

    info!("Agent started | device_id={}", device_id);

    let mut shutdown_rx = shutdown_tx.subscribe();
    tokio::spawn({
        let mqtt = mqtt.clone();
        let device_id = device_id.clone();
        let topic_pub_telemetry = topic_pub_telemetry.clone();
        let topic_pub_logs = topic_pub_logs.clone();
    
        async move {
            let mut system = System::new_all();
            let mut components = Components::new_with_refreshed_list();
            let mut disks = Disks::new_with_refreshed_list();
            let mut networks = Networks::new_with_refreshed_list();
    
            let mqtt_config = TelemetryPublisherMQTTConfig {
                mqtt,
                device_id,
                topic_pub_telemetry,
                topic_pub_logs,
                telemetry_qos: 1,
                log_qos: 1,
            };
    
            let mut interval =
                tokio::time::interval(std::time::Duration::from_secs_f32(
                    telemetry_refresh_time,
                ));
    
            loop {
                tokio::select! {
                    _ = shutdown_rx.recv() => {
                        info!("Telemetry task shutting down");
                        break;
                    }
                    _ = interval.tick() => {
                        telemetry_publisher(
                            &mut system,
                            &mut components,
                            &mut disks,
                            &mut networks,
                            &mqtt_config,
                        ).await;
                    }
                }
            }
            info!("Telemetry task exited");
        }
    });

    let mut shutdown_rx = shutdown_tx.subscribe();
    tokio::spawn({
        let mqtt = mqtt.clone();
        let mut docker = docker_controller.clone();
        let device_id = device_id.clone();
        let topic_pub_docker_info = topic_pub_docker_info.clone();
    
        async move {
            let docker_config = DockerInfoPublisherConfig {
                mqtt,
                device_id,
                topic_pub_docker_info,
                qos: 1,
            };
    
            let mut interval = tokio::time::interval(
                std::time::Duration::from_secs_f32(docker_info_refresh_time),
            );
    
            loop {
                tokio::select! {
                    _ = shutdown_rx.recv() => {
                        info!("Docker info task shutting down");
                        break;
                    }
                    _ = interval.tick() => {
                        docker_info_publisher(
                            &mut docker,
                            &docker_config,
                        ).await;
                    }
                }
            }
            info!("Docker info task exited");
        }
    });

    let mut shutdown_rx = shutdown_tx.subscribe();
    tokio::spawn({
        let mqtt = mqtt.clone();
        let mut docker = docker_controller.clone();
        // let store_credential = store_credential.clone();
        
        async move {
            let mqtt_config = DockerControllerSubscriberMQTTConfig {
                mqtt,
                topic_sub_applications,
                topic_pub_applications,
                topic_sub_operator,
                topic_pub_operator,
                qos: 1,
            };
            
            let mut interval = tokio::time::interval(
                std::time::Duration::from_secs_f32(command_refresh_time),
            );

            loop {
                tokio::select! {
                    _ = shutdown_rx.recv() => {
                        info!("Docker controller subscriber shutting down");
                        break;
                    }
                    _ = interval.tick() => {
                        docker_controller_subscriber(
                            &mut docker,
                            store_credential.clone(),
                            &mqtt_config,
                        ).await;
                    }
                }
            }
    
            info!("Docker controller subscriber exited");
        }        
    });
    
    let mut sigterm = signal(SignalKind::terminate())?;
    let mut sigint  = signal(SignalKind::interrupt())?;
    
    tokio::select! {
        _ = sigterm.recv() => {
            info!("Received SIGTERM (docker stop)");
        }
        _ = sigint.recv() => {
            info!("Received SIGINT (Ctrl+C)");
        }
    }
    
    info!("Sending shutdown signal to all tasks");
    let _ = shutdown_tx.send(());
    
    tokio::time::sleep(std::time::Duration::from_secs(1)).await;
    info!("Agent exited cleanly");
    Ok(())

}



fn env_parse<T>(key: &str, default: &str) -> Result<T, Box<dyn std::error::Error>>
where
    T: FromStr,
    T::Err: std::fmt::Display,
{
    let raw = env::var(key).unwrap_or_else(|_| default.to_string());

    raw.parse::<T>().map_err(|e| {
        error!("Invalid {} value '{}': {}", key, raw, e);
        format!("Invalid {} value '{}'", key, raw).into()
    })
}