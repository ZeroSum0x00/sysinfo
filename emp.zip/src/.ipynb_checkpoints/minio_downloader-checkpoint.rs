use anyhow::{Result, anyhow};
use url::Url;
use tokio::fs;
use reqwest::Client;
use quick_xml::Reader;
use quick_xml::events::Event;
use tokio::io::AsyncWriteExt;
use serde::{Deserialize, Serialize};
use zip::ZipArchive;
use std::fs::File;
use std::io;
use std::path::{Path, PathBuf};



#[derive(Debug, Clone, Deserialize, Serialize, PartialEq, Eq)]
pub struct FileZipMemory {
    pub files: Vec<PathBuf>,
    pub unzip_to_folder: PathBuf
}


#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct MinIOBuckerInfo {
    pub link: String,
    pub endpoint: Option<String>,
    pub bucket: Option<String>,
    pub prefix: Option<String>,
}


#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct MinIODownloader {
    pub save_path: String,

    #[serde(skip, default = "create_client")]
    pub bucker_client: Client,

    pub bucker_info: Option<MinIOBuckerInfo>,
}

fn create_client() -> Client {
    Client::new()
}

impl MinIODownloader {
    pub async fn new(
        save_path: String,
    ) -> Result<Self> {
        let bucker_client = Client::new();
        fs::create_dir_all(save_path.clone()).await?;

        Ok(Self {
            save_path,
            bucker_client,
            bucker_info: None,
        })
    }

    pub async fn get_files_to_url(&mut self, url: &str) -> Result<Vec<String>> {
        let (endpoint, bucket, prefix) = split_s3_link(url)?;
        
        self.bucker_info = Some(MinIOBuckerInfo{
            link: url.to_string(),
            endpoint: Some(endpoint.clone()),
            bucket: Some(bucket.clone()),
            prefix: Some(prefix.clone())
        });
        
        let list_url = format!(
            "{}/{}/?list-type=2&prefix={}",
            endpoint, bucket, prefix
        );
    
        let xml = self.bucker_client.get(&list_url).send().await?.text().await?;
    
        let keys = parse_s3_keys(&xml)?;
        Ok(keys)
    }

    pub async fn download_all(&self, path: String) -> Result<()> {
        let info = self
            .bucker_info
            .as_ref()
            .ok_or_else(|| anyhow::anyhow!("Bucket info not initialized"))?;
    
        let endpoint = info.endpoint.as_deref().ok_or_else(|| anyhow::anyhow!("endpoint missing"))?;
        let bucket = info.bucket.as_deref().ok_or_else(|| anyhow::anyhow!("bucket missing"))?;
        let prefix = info.prefix.as_deref().ok_or_else(|| anyhow::anyhow!("prefix missing"))?;
    
        download_all(
            &self.bucker_client,
            endpoint,
            bucket,
            &path,
            prefix,
            &self.save_path,
        )
        .await
    }

    pub async fn download_to_link(&mut self, path: String) -> Result<PathBuf> {
        self.bucker_info = Some(MinIOBuckerInfo{
            link: path.clone(),
            endpoint: None,
            bucket: None,
            prefix: None
        });

        download_file(
            &self.bucker_client,
            &path.clone(),
            &self.save_path,
        )
        .await
    }

    pub async fn unzip_file(&mut self, path: PathBuf) -> Result<FileZipMemory> {
        Ok(unzip_file(&path, Path::new(&self.save_path))?)
    }
}
    
pub fn split_s3_link(link: &str) -> Result<(String, String, String)> {
    let url = Url::parse(link)?;

    // endpoint = scheme + host
    let endpoint = format!(
        "{}://{}",
        url.scheme(),
        url.host_str().ok_or_else(|| anyhow!("Missing host"))?
    );

    // path: /bucket/prefix/...
    let mut segments = url
        .path_segments()
        .ok_or_else(|| anyhow!("Invalid path"))?;

    let bucket = segments
        .next()
        .ok_or_else(|| anyhow!("Missing bucket"))?
        .to_string();

    let prefix = segments.collect::<Vec<_>>().join("/");

    Ok((endpoint, bucket, prefix))
}

pub async fn download_all(
    client: &Client,
    endpoint: &str,
    bucket: &str,
    key: &str,
    prefix: &str,
    download_dir: &str,
) -> Result<()> {
    let file_url = format!("{}/{}/{}", endpoint, bucket, key);

    let relative = key.strip_prefix(prefix).unwrap();
    let local_path = format!("{}/{}", download_dir, relative);

    if let Some(parent) = Path::new(&local_path).parent() {
        fs::create_dir_all(parent).await?;
    }

    println!("Downloading {}", key);

    let bytes = client.get(file_url).send().await?.bytes().await?;

    let mut file = fs::File::create(&local_path).await?;
    file.write_all(&bytes).await?;

    Ok(())
}

pub async fn download_file(
    client: &Client,
    file_url: &str,
    download_dir: &str,
) -> Result<PathBuf> {

    let filename = file_url
        .split('/')
        .last()
        .ok_or_else(|| anyhow::anyhow!("Invalid URL"))?;

    let filepath = Path::new(download_dir).join(filename);

    println!("download to {:?}", filepath);

    let bytes = client.get(file_url).send().await?.bytes().await?;

    let mut file = fs::File::create(&filepath).await?;
    file.write_all(&bytes).await?;
    file.flush().await?;   // quan trọng

    drop(file);            // đảm bảo đóng file

    Ok(filepath)
}

pub fn unzip_file(zip_path: &Path, output_dir: &Path) -> Result<FileZipMemory> {

    let file = File::open(zip_path)?;
    let mut archive = ZipArchive::new(file)?;

    let mut unzip_files: Vec<PathBuf> = Vec::new();
    let mut unzip_to_folder: Option<PathBuf> = None;

    for i in 0..archive.len() {

        let mut zipped_file = archive.by_index(i)?;
        let outpath = output_dir.join(zipped_file.name());

        if zipped_file.name().ends_with('/') {

            std::fs::create_dir_all(&outpath)?;

            if unzip_to_folder.is_none() {
                unzip_to_folder = Some(outpath.clone());
            }

        } else {

            if let Some(parent) = outpath.parent() {
                std::fs::create_dir_all(parent)?;
            }

            let mut outfile = File::create(&outpath)?;
            io::copy(&mut zipped_file, &mut outfile)?;

            unzip_files.push(outpath.clone());
        }
    }

    let unzip_to_folder = unzip_to_folder.unwrap_or_else(|| output_dir.to_path_buf());

    Ok(FileZipMemory {
        files: unzip_files,
        unzip_to_folder,
    })
}

fn parse_s3_keys(xml: &str) -> Result<Vec<String>> {
    let mut reader = Reader::from_str(xml);
    reader.trim_text(true);
    let mut buf = Vec::new();
    let mut keys = Vec::new();
    let mut inside_key = false;

    loop {
        match reader.read_event_into(&mut buf) {
            Ok(Event::Start(e)) if e.name().as_ref() == b"Key" => {
                inside_key = true;
            }
            Ok(Event::Text(e)) if inside_key => {
                keys.push(e.unescape()?.to_string());
                inside_key = false;
            }
            Ok(Event::Eof) => break,
            Err(e) => return Err(e.into()),
            _ => {}
        }
        buf.clear();
    }

    Ok(keys)
}