use anyhow::Result;
use rusqlite::Connection;
use tracing::{debug, error, info, warn};
use serde::{Serialize, Deserialize};
use serde_json::{Value, json, to_string};
use rustls_pemfile::{certs, pkcs8_private_keys, rsa_private_keys};

use std::{
    fs,
    sync::Arc,
    collections::HashMap,
    sync::atomic::{AtomicBool, Ordering},
    time::Duration,
};

use futures_util::{
    future::{Abortable, AbortHandle}
};

use tokio::{
    task,
    sync::{Mutex, mpsc},
};

use rumqttc::{
    AsyncClient, Event, Incoming, 
    MqttOptions, QoS, LastWill, 
    Transport, TlsConfiguration,
    tokio_rustls::rustls::{
        ClientConfig, RootCertStore,
        pki_types::PrivateKeyDer,
    }
};

use crate::alerting::AlertPayload;
use crate::types::{SystemMetrics, SSHResponse, ApplicationLogResponse};
use crate::config::MqttConfig;
use crate::docker_manager::{
    DockerCommand, DockerManager, DockerResponse,
};
use crate::utils::convert_message::{convert_message_docker, convert_message_ssh};
use crate::reverse_ssh::ReverseSsh;
use crate::minio_downloader::MinIODownloader;

use crate::deployment_stack::{
    DeploymentState,
    handle_shadow_command,
};


#[derive(Debug, Serialize, Deserialize)]
pub struct ShadowMessage {
    pub state: Option<ShadowState>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct ShadowState {
    pub desired: Option<DesiredState>,
    pub reported: Option<ReportState>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct DesiredState {
    pub operation_id: String,
    pub stable_version: Option<String>,
    pub desire_version: Option<String>,
    pub stable_url: Option<String>,
    pub desire_url: Option<String>,
    pub action: Option<String>,
    pub status: Option<String>,
}


#[derive(Debug, Serialize, Deserialize)]
pub struct ReportState {
    pub operation_id: String,
    pub action: Option<String>,
    pub progress: Option<f32>,
    pub message: Option<String>,
}

pub static GLOBAL_ACTION_FLAG: AtomicBool = AtomicBool::new(true);

fn build_tls_config(
    ca_path: &str,
    cert_path: &str,
    key_path: &str,
) -> ClientConfig {

    // ---------- CA ----------
    let mut root_store = RootCertStore::empty();
    let ca_bytes = fs::read(ca_path).expect("Cannot read CA file");

    for cert in certs(&mut &ca_bytes[..]) {
        let cert = cert.expect("Invalid CA cert");
        root_store.add(cert).unwrap();
    }

    // ---------- Client cert ----------
    let cert_bytes = fs::read(cert_path).expect("Cannot read device cert");

    let mut client_certs = Vec::new();
    for cert in certs(&mut &cert_bytes[..]) {
        let cert = cert.expect("Invalid device cert");
        client_certs.push(cert);
    }

    // ---------- Private key ----------
    let key_bytes = fs::read(key_path).expect("Cannot read private key");

    let private_key = pkcs8_private_keys(&mut &key_bytes[..])
        .next()
        .map(|key| {
            PrivateKeyDer::Pkcs8(key.expect("Invalid PKCS8 key"))
        })
        .or_else(|| {
            rsa_private_keys(&mut &key_bytes[..])
                .next()
                .map(|key| {
                    PrivateKeyDer::Pkcs1(key.expect("Invalid RSA key"))
                })
        })
        .expect("❌ No valid private key found");


    // ---------- Build config ----------
    ClientConfig::builder()
        .with_root_certificates(root_store)
        .with_client_auth_cert(client_certs, private_key)
        .expect("Failed to build TLS config")
}


async fn docker_command_error_handle(
    mqtt_client: AsyncClient,
    topic: String,
    error: String,
    qos: QoS,
) {
    error!("Failed to parse Docker command: {}", error);
    let error_response = DockerResponse {
        success: false,
        message: format!("Invalid command format: {}", error),
        data: None,
    };
    if let Ok(response_json) = to_string(&error_response) {
        let _ = mqtt_client.publish(&topic, qos, false, response_json).await;
    }
}


pub async fn pub_shadow_aws(
    mqtt_client: Arc<MqttProgressPublisher>,
    topic: String,
    desired_state: DesiredState,
    report_state: ReportState,
) -> Result<()> {

    let report_payload = ShadowMessage {
        state: Some(ShadowState {
            desired: Some(desired_state),
            reported: Some(report_state),
        }),
    };

    let payload = serde_json::to_string(&report_payload)?;

    info!("🚀 Publishing shadow to topic: {}", topic);
    info!("Payload: {}", payload);

    mqtt_client.publish_to_topic(&topic, payload).await?;

    Ok(())
}


#[derive(Clone, Debug)]
pub struct MqttProgressPublisher {
    client: AsyncClient,
    qos: QoS,
}

impl MqttProgressPublisher {
    pub async fn publish_to_topic(&self, topic: &str, payload: String) -> Result<()> {
        self.client.publish(topic, self.qos, false, payload).await?;
        Ok(())
    }
}

#[derive(Clone, Debug)]
#[allow(dead_code)]
pub struct MqttClient {
    client: AsyncClient,
    default_topic: String,
    telemetry_topic: String,
    log_topic: String,
    docker_info_topic: String,
    command_topic: String,
    ssh_topic: String,
    aws_shadow_get: String,
    qos: QoS,
    docker_manager: Option<Arc<Mutex<DockerManager>>>,
    db_client: Arc<Mutex<Connection>>,
    ssh_manager: Option<Arc<Mutex<ReverseSsh>>>,
    bucker_manager: Option<Arc<Mutex<MinIODownloader>>>,
    log_tasks: Arc<Mutex<HashMap<String, AbortHandle>>>,
}

impl MqttClient {
    pub async fn new(
        config: &MqttConfig,
        docker_manager: Option<Arc<Mutex<DockerManager>>>,
        db_client: Arc<Mutex<Connection>>,
        local_ssh_port: u16,
        ssh_manager: Option<Arc<Mutex<ReverseSsh>>>,
        bucker_manager: Option<Arc<Mutex<MinIODownloader>>>,
    ) -> Result<Self> {
        let device_id = config.client_id.clone();
        
        info!(
            "Initializing MQTT client: {}@{}:{}",
            device_id, config.broker, config.port
        );
        let will_payload = json!({
            "device_id": device_id,
            "status": "offline",
            "reason": "connection_lost"
        }).to_string();
        
        let qos = match config.qos {
            0 => QoS::AtMostOnce,
            1 => QoS::AtLeastOnce,
            2 => QoS::ExactlyOnce,
            _ => QoS::AtMostOnce,
        };
        let log_qos = QoS::AtMostOnce;
        let mut mqtt_options = MqttOptions::new(&device_id, &config.broker, config.port);

        mqtt_options.set_keep_alive(Duration::from_secs(300));
        mqtt_options.set_clean_session(false);
        
        mqtt_options.set_inflight(200);
        mqtt_options.set_request_channel_capacity(1000);
        
        if config.broker_type == "aws" && !config.ca_path.is_empty() && !config.cert_path.is_empty() && !config.key_path.is_empty() {
            let tls_config = build_tls_config(
                &config.ca_path,
                &config.cert_path,
                &config.key_path,
            );
            
            mqtt_options.set_transport(
                Transport::Tls(
                    TlsConfiguration::Rustls(Arc::new(tls_config))
                )
            );
        }

        // Clone variables for event loop
        let default_base_topic = format!("{}/{}", config.default_topic.clone(), device_id);
        let telemetry_topic_pub = format!("{}/{}", default_base_topic.clone(), config.telemetry_topic.clone());
        let docker_info_topic_pub = format!("{}/{}", default_base_topic.clone(), config.docker_info_topic.clone());
        let log_topic_pub = format!("{}/{}", default_base_topic.clone(), config.log_topic.clone());
        let stack_progess_topic_pub = format!("{}/{}", default_base_topic.clone(), "stack-progess");

        let containers_topic_sub = format!("{}/{}", default_base_topic.clone(), config.docker_info_topic.clone());
        let containers_topic_clone = containers_topic_sub.clone();
        // let containers_topic_pub = format!("{}/response", containers_topic_clone.clone());
        
        let command_topic_sub = format!("{}/{}", default_base_topic.clone(), config.command_topic.clone());
        let command_topic_sub_clone = command_topic_sub.clone();
        let command_topic_pub = format!("{}/response", command_topic_sub.clone());
        
        let operator_topic_sub = format!("{}/{}", default_base_topic.clone(), config.operator_topic.clone());
        let operator_topic_sub_clone = operator_topic_sub.clone();
        // let operator_topic_pub = format!("{}/response", operator_topic_sub.clone());
        
        let ssh_topic_sub = format!("{}/{}", default_base_topic.clone(), config.ssh_topic.clone());
        let ssh_topic_sub_clone = ssh_topic_sub.clone();
        let ssh_topic_pub = format!("{}/response", ssh_topic_sub.clone());

        let application_log_topic_sub = format!("{}/{}", default_base_topic.clone(), config.application_log_topic.clone());
        let application_log_topic_sub_clone = application_log_topic_sub.clone();
        let application_log_topic_pub = format!("{}/response", application_log_topic_sub.clone());

        
        let aws_shadow_get = format!("$aws/things/{}/shadow/get", device_id);
        let aws_shadow_get_accepted = format!("{}/accepted", aws_shadow_get);
        let aws_shadow_get_accepted_clone = aws_shadow_get_accepted.clone();
        let aws_shadow_get_rejected = format!("{}/rejected", aws_shadow_get);
        let aws_shadow_get_rejected_clone = aws_shadow_get_rejected.clone();
        let aws_shadow_update = format!("$aws/things/{}/shadow/update", device_id);
        
        mqtt_options.set_last_will(LastWill::new(
            format!("{}/presence", default_base_topic.clone()),
            will_payload,
            qos,
            false,
        ));

        let (client, mut eventloop) = AsyncClient::new(mqtt_options, 1000);
    
        let log_tasks: Arc<Mutex<HashMap<String, AbortHandle>>> = Arc::new(Mutex::new(HashMap::new()));

        let (mqtt_tx, mut mqtt_rx) = mpsc::channel::<(String, String)>(100);
        let client_pub = client.clone();
        task::spawn(async move {
            while let Some((topic, payload)) = mqtt_rx.recv().await {
                if let Err(e) = client_pub.publish(&topic, log_qos, false, payload).await {
                    error!("MQTT publish failed: {}", e);
                }
            }
        });
        
        let docker_controller_manager = docker_manager.clone();
        let client_clone = client.clone();
        let ssh_manager_clone = ssh_manager.clone();
        let bucker_manager_clone = bucker_manager.clone();
        let db_client_clone = db_client.clone();
        let log_tasks_clone = log_tasks.clone();
        let mqtt_tx_clone = mqtt_tx.clone();

        let reserve_mqtt_client = Arc::new(MqttProgressPublisher {
            client: client_clone.clone(),
            qos,
        });
        let shadow_state = Arc::new(Mutex::new(None::<Vec<u8>>));
        let shadow_notify = Arc::new(tokio::sync::Notify::new());
        let worker_state = shadow_state.clone();
        let worker_notify = shadow_notify.clone();

        let docker_mgr_clone = docker_controller_manager.clone();
        let db_clone = db_client_clone.clone();
        let bucket_clone = bucker_manager_clone.clone();
        let mqtt_clone = reserve_mqtt_client.clone();
        let topic_clone = stack_progess_topic_pub.clone();
        let shadow_update_clone = aws_shadow_update.clone();

        tokio::spawn(async move {

            let mut deployment_state = DeploymentState {
                stable_stack: None,
                desire_stack: None,
            };

            loop {
                worker_notify.notified().await;

                let payload_opt = {
                    let mut guard = worker_state.lock().await;
                    guard.take()
                };

                let Some(payload) = payload_opt else { continue };

                let Some(ref docker_mgr) = docker_mgr_clone else {
                    continue;
                };

                if let Err(e) = handle_shadow_command(
                    payload,
                    docker_mgr.clone(),
                    db_clone.clone(),
                    &mut deployment_state,
                    bucket_clone.clone(),
                    mqtt_clone.clone(),
                    topic_clone.clone(),
                    shadow_update_clone.clone(),
                ).await {
                    error!("Shadow handler error: {:?}", e);
                }
            }
        });
        
        // Spawn event loop handler
        task::spawn(async move {
            loop {
                match eventloop.poll().await {
                    Ok(Event::Incoming(Incoming::ConnAck(connack))) => {
                        info!(
                            "MQTT connected successfully. session_present={}",
                            connack.session_present
                        );
                        
                        // Nếu broker không giữ session → phải subscribe lại
                        if !connack.session_present {
                            info!("Session not present → re-subscribing topics");

                            
                            if let Err(e) = client_clone.subscribe(&containers_topic_clone, qos).await {
                                error!("Resubscribe containers error: {:?}", e);
                            }

                            if let Err(e) = client_clone.subscribe(&command_topic_sub_clone, qos).await {
                                error!("Resubscribe command error: {:?}", e);
                            }

                            if let Err(e) = client_clone.subscribe(&operator_topic_sub_clone, qos).await {
                                error!("Resubscribe operator error: {:?}", e);
                            }

                            if let Err(e) = client_clone.subscribe(&ssh_topic_sub_clone, qos).await {
                                error!("Resubscribe ssh error: {:?}", e);
                            }

                            if let Err(e) = client_clone.subscribe(&application_log_topic_sub_clone, qos).await {
                                error!("Resubscribe application-log error: {:?}", e);
                            }
                            
                            if let Err(e) = client_clone.subscribe(&aws_shadow_get_accepted_clone, qos).await {
                                error!("Resubscribe error: {:?}", e);
                            }

                            if let Err(e) = client_clone.subscribe(&aws_shadow_get_rejected_clone, qos).await {
                                error!("Resubscribe error: {:?}", e);
                            }
                        }
                    }
                    Ok(Event::Incoming(Incoming::Disconnect)) => {
                        warn!("MQTT disconnected");
                    }
                    Ok(Event::Incoming(Incoming::Publish(publish))) => {
                        debug!(
                            "MQTT message received on topic '{}': {} bytes",
                            publish.topic,
                            publish.payload.len()
                        );

                        let client_for_task = client_clone.clone();

                        if publish.topic == aws_shadow_get_accepted {
                            if GLOBAL_ACTION_FLAG.load(Ordering::Relaxed) == false {
                                continue;
                            }
                                let mut guard = shadow_state.lock().await;
                                *guard = Some(publish.payload.to_vec());
                            

                            shadow_notify.notify_one();

                            continue;
                        }
                        // Handle Docker commands
                        else if publish.topic == ssh_topic_sub && let Some(ref ssh_manager_clone) = ssh_manager_clone{
                            match convert_message_ssh(&publish.payload, local_ssh_port) {
                                Ok(command) => {
                                    let command_clone = command.clone();
                                    let result = ssh_manager_clone.lock().await.execute_command(command);
                                    match result {
                                        Ok(_) => {
                                            let response = SSHResponse {
                                                success: true,
                                                message: format!("Executed SSH command: {:?}", command_clone),
                                                data: None,
                                            };
                                            if let Ok(response_json) = to_string(&response) {
                                                let _ = client_for_task.publish(&ssh_topic_pub, qos, false, response_json).await;
                                            }
                                        }
                                        Err(e) => {                                           
                                            let error_response = SSHResponse {
                                                success: false,
                                                message: format!("Command execution failed: {}", e),
                                                data: None,
                                            };
                                            
                                            if let Ok(error_json) = to_string(&error_response) {
                                                let _ = client_for_task.publish(&ssh_topic_pub, qos, false, error_json).await;
                                            }
                                            
                                            error!("Failed to execute SSH command: {}", e);
                                        }
                                    }
                                }
                                Err(e) => {
                                    error!("Failed to parse SSH command: {}", e);
                                    let error_response = SSHResponse {
                                        success: false,
                                        message: format!("Invalid command format: {}", e),
                                        data: None,
                                    };
                                    if let Ok(error_json) = to_string(&error_response) {
                                        let _ = client_for_task.publish(&ssh_topic_pub, qos, false, error_json).await;
                                    }
                                }
                            }
                        } else if publish.topic == application_log_topic_sub && let Some(ref docker_mgr) = docker_controller_manager {
                            
                            match convert_message_docker(&publish.payload).await {
                                Ok(command) => {
                                    info!("Executing Docker command: {:?}", command);
                                    if let DockerCommand::GetLogs { stream_id, container_id, flag } = command {
                                        let mut tasks = log_tasks_clone.lock().await;

                                        if !flag {
                                            if let Some(h) = tasks.remove(&stream_id) {
                                                h.abort();
                                                info!("Stopped log stream for {}", stream_id);
                                            }
                                            continue;
                                        }

                                        if tasks.contains_key(&stream_id) {
                                            debug!("Log stream already running for {}", stream_id);
                                            continue;
                                        }
                                        let sid = stream_id.clone();
                                        let cid = container_id.clone();
                                        let docker_mgr = docker_mgr.clone();
                                        let tx = mqtt_tx_clone.clone();
                                        let topic = application_log_topic_pub.clone();

                                        let (abort_handle, abort_reg) = AbortHandle::new_pair();
                                        
                                        
                                        task::spawn(Abortable::new(
                                            async move {
                                                let mut first = true;
                                                let mut last_log = String::new();

                                                loop {
                                                    let mut is_failed = false;
                                                    let tail = if first {
                                                        first = false;
                                                        20
                                                    } else {
                                                        1
                                                    };

                                                    let res = docker_mgr
                                                        .lock()
                                                        .await
                                                        .get_logs_container(&cid, tail)
                                                        .await;

                                                    let msg = match res {
                                                        Ok(log) if log != last_log => {
                                                            is_failed = false;
                                                            last_log = log.clone();
                                                            Some(ApplicationLogResponse {
                                                                stream_id: sid.clone(),
                                                                container_id: cid.clone(),
                                                                status: "success".into(),
                                                                message: log,
                                                            })
                                                        }
                                                        Err(e) => {
                                                            is_failed = true;
                                                            Some(ApplicationLogResponse {
                                                                stream_id: sid.clone(),
                                                                container_id: cid.clone(),
                                                                status: "failed".into(),
                                                                message: e.to_string(),
                                                            })
                                                        },
                                                        _ => None,
                                                    };
                                                    
                                                    if let Some(m) = msg && let Ok(json) = to_string(&m) {
                                                        let _ = tx.send((topic.clone(), json)).await;
                                                        info!("MQTT send application-log");
                                                    }
                                                    
                                                    tokio::time::sleep(Duration::from_secs(2)).await;
                                                    if is_failed {
                                                        break;
                                                    }
                                                }
                                            },
                                            abort_reg,
                                        ));

                                        tasks.insert(stream_id, abort_handle);
                                    }
                                }
                                Err(e) => {
                                    docker_command_error_handle(client_clone.clone(), command_topic_pub.clone(), e.to_string(), qos).await;
                                }
                            }
                        }
                    }
                    Ok(Event::Incoming(Incoming::SubAck(suback))) => {
                        info!("MQTT subscription acknowledged: {:?}", suback);
                    }
                    Ok(Event::Incoming(Incoming::PubAck(puback))) => {
                        debug!("MQTT publish acknowledged: packet_id={}", puback.pkid);
                    }
                    Ok(Event::Outgoing(outgoing)) => {
                        debug!("MQTT outgoing event: {:?}", outgoing);
                    }
                    Err(e) => {
                        error!("MQTT connection error: {:?}", e);
                        tokio::time::sleep(Duration::from_secs(1)).await;
                    }
                    _ => {
                        debug!("MQTT unhandled event");
                    }
                }
            }
        });

        Ok(Self {
            client,
            default_topic: default_base_topic.clone(),
            telemetry_topic: telemetry_topic_pub.clone(),
            log_topic: log_topic_pub.clone(),
            docker_info_topic: docker_info_topic_pub.clone(),
            command_topic: config.command_topic.clone(),
            ssh_topic: config.ssh_topic.clone(),
            aws_shadow_get,
            qos,
            docker_manager,
            db_client,
            ssh_manager,
            bucker_manager,
            log_tasks,
        })
    }

    pub async fn publish_telemetry(&self, metrics: &SystemMetrics, qos: QoS) -> Result<()> {
        let payload = to_string(metrics)?;
        self.client
            .publish(&self.telemetry_topic, qos, false, payload.clone())
            .await?;        
        info!(
            "Publishing telemetry to topic '{}' at qos {:?} ({} bytes)",
            self.telemetry_topic,
            qos,
            payload.len()
        );
        Ok(())
    }

    pub async fn pub_to_shadow(&self) -> Result<()> {
        info!("Pub to command shadow topic");
        self.client
            .publish(self.aws_shadow_get.clone(), self.qos, false, "")
            .await?;
        Ok(())
    }

    pub async fn publish_alert(&self, alert: &AlertPayload) -> Result<()> {
        let payload = to_string(alert)?;
        debug!("Alert payload: {}", payload);
        self.client
            .publish(&self.log_topic, self.qos, false, payload)
            .await?;
        Ok(())
    }
    
    pub async fn publish_container_stats2(
        &self,
        stats: &Value,
        client_id_clone: &str,
    ) -> Result<()> {
        let mut payload_value = stats.clone();
    
        if let Value::Object(ref mut map) = payload_value {
            map.insert(
                "device_id".to_string(),
                Value::String(client_id_clone.to_string()),
            );
        }
    
        let payload = to_string(&payload_value)?;
        self.client
            .publish(&self.docker_info_topic, self.qos, false, payload)
            .await?;
    
        Ok(())
    }

    pub async fn subscribe_to_commands(&self, command_topic: &str) -> Result<()> {
        info!("Subscribing to command topic: '{}'", command_topic);
        self.client.subscribe(command_topic, self.qos).await?;
        Ok(())
    }

    pub async fn publish_log(&self, level: &str, message: &str) -> Result<()> {
        let log_entry = json!({
            "timestamp": chrono::Utc::now().to_rfc3339(),
            "level": level,
            "message": message
        });

        let topic = "logs/edge-controller";
        let payload = log_entry.to_string();
        self.client.publish(topic, self.qos, false, payload).await?;
        Ok(())
    }

pub async fn publish_to_topic(&self, topic: &str, payload: String) -> Result<()> {
    match self.client.publish(topic, self.qos, false, payload.clone()).await {
        Ok(_) => {
            info!("✅ MQTT published to {}", topic);
        }
        Err(e) => {
            error!("❌ MQTT publish FAILED to {}: {:?}", topic, e);
            return Err(e.into());
        }
    }
    Ok(())
}
}

