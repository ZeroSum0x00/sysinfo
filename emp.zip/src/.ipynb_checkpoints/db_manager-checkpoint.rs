use rusqlite::Connection;
use serde_json;
use crate::deployment_stack::Stack;
use std::sync::Arc;
use tokio::sync::Mutex;
use anyhow::Result;
use rusqlite::OptionalExtension;


pub async fn save_db_state(
    conn: Arc<Mutex<Connection>>,
    state: &Stack,
) -> Result<()> {

    let json = serde_json::to_string(state)?;

    let conn = conn.lock().await;

    conn.execute(
        "INSERT INTO deployment_state (id, data)
         VALUES (1, ?1)
         ON CONFLICT(id) DO UPDATE SET data = excluded.data",
        [json],
    )?;

    Ok(())
}


pub async fn load_db_state(
    conn: Arc<Mutex<Connection>>,
    id: i64,
) -> anyhow::Result<Option<Stack>> {

    let conn = conn.lock().await;

    let mut stmt = conn.prepare(
        "SELECT data FROM deployment_state WHERE id=?1"
    )?;

    let json: Option<String> = stmt
        .query_row([id], |row| row.get(0))
        .optional()?;

    let stack = match json {
        Some(j) => Some(serde_json::from_str(&j)?),
        None => None,
    };

    Ok(stack)
}